using System.Net;
using System.Net.Http.Json;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection;
using RaceDay.Api.Data;
using RaceDay.Api.Models.DTOs;

namespace RaceDay.Tests;

public class AuthTests : IClassFixture<ApiFactory>
{
    private readonly ApiFactory _factory;

    public AuthTests(ApiFactory factory) => _factory = factory;

    private object RegisterBody(string email, string role = "Participant", string password = ApiHelpers.Password) => new
    {
        fullName = "Test User",
        email,
        password,
        contactNumber = "0820000000",
        role
    };

    // ---------- Registration ----------

    [Theory]
    [InlineData("Participant")]
    [InlineData("Organiser")]
    public async Task Register_WithValidDetails_ReturnsCreated(string role)
    {
        var client = _factory.CreateClient();
        var response = await client.PostAsJsonAsync("/api/auth/register", RegisterBody(ApiHelpers.UniqueEmail("reg"), role));

        Assert.Equal(HttpStatusCode.Created, response.StatusCode);
        var body = await response.Content.ReadFromJsonAsync<AuthResponse>();
        Assert.Equal(role, body!.Role);
        Assert.True(body.UserId > 0);
    }

    [Fact]
    public async Task Register_WithExistingEmail_ReturnsConflict()
    {
        var client = _factory.CreateClient();
        var email = ApiHelpers.UniqueEmail("dup");
        await client.PostAsJsonAsync("/api/auth/register", RegisterBody(email));

        // Same email again, even under the other role, must be rejected.
        var response = await client.PostAsJsonAsync("/api/auth/register", RegisterBody(email, "Organiser"));

        Assert.Equal(HttpStatusCode.Conflict, response.StatusCode);
    }

    [Fact]
    public async Task Register_WithInvalidRole_ReturnsBadRequest()
    {
        var client = _factory.CreateClient();
        var response = await client.PostAsJsonAsync("/api/auth/register", RegisterBody(ApiHelpers.UniqueEmail("role"), "Admin"));

        Assert.Equal(HttpStatusCode.BadRequest, response.StatusCode);
    }

    [Fact]
    public async Task Register_WithShortPassword_ReturnsBadRequest()
    {
        var client = _factory.CreateClient();
        var response = await client.PostAsJsonAsync("/api/auth/register", RegisterBody(ApiHelpers.UniqueEmail("short"), "Participant", "abc"));

        Assert.Equal(HttpStatusCode.BadRequest, response.StatusCode);
    }

    [Fact]
    public async Task Register_WithInvalidEmail_ReturnsBadRequest()
    {
        var client = _factory.CreateClient();
        var response = await client.PostAsJsonAsync("/api/auth/register", RegisterBody("not-an-email"));

        Assert.Equal(HttpStatusCode.BadRequest, response.StatusCode);
    }

    [Fact]
    public async Task Register_StoresPasswordAsHash_NotPlainText()
    {
        var client = _factory.CreateClient();
        var email = ApiHelpers.UniqueEmail("hash");
        await client.PostAsJsonAsync("/api/auth/register", RegisterBody(email));

        using var scope = _factory.Services.CreateScope();
        var db = scope.ServiceProvider.GetRequiredService<AppDbContext>();
        var saved = await db.Participants.SingleAsync(p => p.Email == email);

        Assert.NotEqual(ApiHelpers.Password, saved.PasswordHash);
        Assert.StartsWith("$2", saved.PasswordHash);                       // BCrypt hashes start with $2
        Assert.True(BCrypt.Net.BCrypt.Verify(ApiHelpers.Password, saved.PasswordHash));
    }

    // ---------- Login ----------

    [Theory]
    [InlineData("Participant")]
    [InlineData("Organiser")]
    public async Task Login_WithCorrectCredentials_ReturnsOkAndRole(string role)
    {
        var client = _factory.CreateClient();
        var email = ApiHelpers.UniqueEmail("login");
        await client.PostAsJsonAsync("/api/auth/register", RegisterBody(email, role));

        var response = await client.PostAsJsonAsync("/api/auth/login", new { email, password = ApiHelpers.Password });

        Assert.Equal(HttpStatusCode.OK, response.StatusCode);
        var body = await response.Content.ReadFromJsonAsync<AuthResponse>();
        Assert.Equal(role, body!.Role);
    }

    [Fact]
    public async Task Login_WithWrongPassword_ReturnsUnauthorized()
    {
        var client = _factory.CreateClient();
        var email = ApiHelpers.UniqueEmail("wrongpw");
        await client.PostAsJsonAsync("/api/auth/register", RegisterBody(email));

        var response = await client.PostAsJsonAsync("/api/auth/login", new { email, password = "WrongPassword1!" });

        Assert.Equal(HttpStatusCode.Unauthorized, response.StatusCode);
    }

    [Fact]
    public async Task Login_WithUnknownEmail_ReturnsUnauthorized()
    {
        var client = _factory.CreateClient();
        var response = await client.PostAsJsonAsync("/api/auth/login",
            new { email = ApiHelpers.UniqueEmail("ghost"), password = ApiHelpers.Password });

        Assert.Equal(HttpStatusCode.Unauthorized, response.StatusCode);
    }

    [Fact]
    public async Task Logout_EndsTheSession()
    {
        var (client, _, _) = await ApiHelpers.RegisterAndLoginAsync(_factory, "Participant");
        Assert.Equal(HttpStatusCode.OK, (await client.GetAsync("/api/profile")).StatusCode);

        var logout = await client.PostAsync("/api/auth/logout", null);
        Assert.Equal(HttpStatusCode.OK, logout.StatusCode);

        Assert.Equal(HttpStatusCode.Unauthorized, (await client.GetAsync("/api/profile")).StatusCode);
    }

    // ---------- Profile (protected area) ----------

    [Fact]
    public async Task Profile_WithoutLogin_ReturnsUnauthorized()
    {
        var client = _factory.CreateClient();

        var response = await client.GetAsync("/api/profile");

        Assert.Equal(HttpStatusCode.Unauthorized, response.StatusCode);
    }

    [Theory]
    [InlineData("Participant")]
    [InlineData("Organiser")]
    public async Task Profile_AfterLogin_ReturnsOwnProfile(string role)
    {
        var (client, email, userId) = await ApiHelpers.RegisterAndLoginAsync(_factory, role);

        var response = await client.GetAsync("/api/profile");

        Assert.Equal(HttpStatusCode.OK, response.StatusCode);
        var profile = await response.Content.ReadFromJsonAsync<ProfileResponse>();
        Assert.Equal(email, profile!.Email);
        Assert.Equal(role, profile.Role);
        Assert.Equal(userId, profile.UserId);
    }

    [Fact]
    public async Task Profile_Update_ChangesDetails()
    {
        var (client, _, _) = await ApiHelpers.RegisterAndLoginAsync(_factory, "Participant");
        var newEmail = ApiHelpers.UniqueEmail("updated");

        var response = await client.PutAsJsonAsync("/api/profile",
            new { fullName = "New Name", email = newEmail, contactNumber = "0831112222" });

        Assert.Equal(HttpStatusCode.OK, response.StatusCode);
        var profile = await (await client.GetAsync("/api/profile")).Content.ReadFromJsonAsync<ProfileResponse>();
        Assert.Equal("New Name", profile!.FullName);
        Assert.Equal(newEmail, profile.Email);
    }

    [Fact]
    public async Task Profile_Update_WithEmailOfAnotherUser_ReturnsConflict()
    {
        var (_, otherEmail, _) = await ApiHelpers.RegisterAndLoginAsync(_factory, "Organiser");
        var (client, _, _) = await ApiHelpers.RegisterAndLoginAsync(_factory, "Participant");

        var response = await client.PutAsJsonAsync("/api/profile",
            new { fullName = "Someone", email = otherEmail, contactNumber = "0831112222" });

        Assert.Equal(HttpStatusCode.Conflict, response.StatusCode);
    }

    [Fact]
    public async Task Profile_Update_WithoutLogin_ReturnsUnauthorized()
    {
        var client = _factory.CreateClient();

        var response = await client.PutAsJsonAsync("/api/profile",
            new { fullName = "Nobody", email = ApiHelpers.UniqueEmail("anon"), contactNumber = "0831112222" });

        Assert.Equal(HttpStatusCode.Unauthorized, response.StatusCode);
    }
}
