using System.Net;
using System.Net.Http.Json;
using RaceDay.Api.Models.DTOs;

namespace RaceDay.Tests;

public class EventTests : IClassFixture<ApiFactory>
{
    private readonly ApiFactory _factory;

    public EventTests(ApiFactory factory) => _factory = factory;

    // ---------- Organisers can manage events ----------

    [Fact]
    public async Task Organiser_CanCreateEvent()
    {
        var (organiser, _, organiserId) = await ApiHelpers.RegisterAndLoginAsync(_factory, "Organiser");

        var response = await organiser.PostAsJsonAsync("/api/events", ApiHelpers.EventBody("Soweto 10km", "run"));

        Assert.Equal(HttpStatusCode.Created, response.StatusCode);
        var created = await response.Content.ReadFromJsonAsync<EventResponse>();
        Assert.Equal("Soweto 10km", created!.Name);
        Assert.Equal("Run", created.EventType);              // "run" is tidied up to "Run"
        Assert.Equal(organiserId, created.OrganiserID);
    }

    [Fact]
    public async Task Organiser_CanUpdateOwnEvent()
    {
        var (organiser, _, _) = await ApiHelpers.RegisterAndLoginAsync(_factory, "Organiser");
        var ev = await ApiHelpers.CreateEventAsync(organiser);

        var response = await organiser.PutAsJsonAsync($"/api/events/{ev.EventID}", ApiHelpers.EventBody("Renamed Race", "Walk"));

        Assert.Equal(HttpStatusCode.OK, response.StatusCode);
        var updated = await response.Content.ReadFromJsonAsync<EventResponse>();
        Assert.Equal("Renamed Race", updated!.Name);
        Assert.Equal("Walk", updated.EventType);
    }

    [Fact]
    public async Task Organiser_CanDeleteOwnEvent()
    {
        var (organiser, _, _) = await ApiHelpers.RegisterAndLoginAsync(_factory, "Organiser");
        var ev = await ApiHelpers.CreateEventAsync(organiser);

        var delete = await organiser.DeleteAsync($"/api/events/{ev.EventID}");

        Assert.Equal(HttpStatusCode.OK, delete.StatusCode);
        Assert.Equal(HttpStatusCode.NotFound, (await organiser.GetAsync($"/api/events/{ev.EventID}")).StatusCode);
    }

    [Fact]
    public async Task Organiser_CannotDeleteEventThatHasEnrolments()
    {
        var (organiser, _, _) = await ApiHelpers.RegisterAndLoginAsync(_factory, "Organiser");
        var (participant, _, _) = await ApiHelpers.RegisterAndLoginAsync(_factory, "Participant");
        var ev = await ApiHelpers.CreateEventAsync(organiser);
        var category = await ApiHelpers.CreateCategoryAsync(organiser, ev.EventID);
        await ApiHelpers.EnrolAsync(participant, category.CategoryID);

        var delete = await organiser.DeleteAsync($"/api/events/{ev.EventID}");

        Assert.Equal(HttpStatusCode.Conflict, delete.StatusCode);
    }

    // ---------- Roles are enforced ----------

    [Fact]
    public async Task Participant_CannotCreateEvent_ReturnsForbidden()
    {
        var (participant, _, _) = await ApiHelpers.RegisterAndLoginAsync(_factory, "Participant");

        var response = await participant.PostAsJsonAsync("/api/events", ApiHelpers.EventBody());

        Assert.Equal(HttpStatusCode.Forbidden, response.StatusCode);
    }

    [Fact]
    public async Task Participant_CannotUpdateOrDeleteEvent_ReturnsForbidden()
    {
        var (organiser, _, _) = await ApiHelpers.RegisterAndLoginAsync(_factory, "Organiser");
        var (participant, _, _) = await ApiHelpers.RegisterAndLoginAsync(_factory, "Participant");
        var ev = await ApiHelpers.CreateEventAsync(organiser);

        var put = await participant.PutAsJsonAsync($"/api/events/{ev.EventID}", ApiHelpers.EventBody("Hacked"));
        var delete = await participant.DeleteAsync($"/api/events/{ev.EventID}");

        Assert.Equal(HttpStatusCode.Forbidden, put.StatusCode);
        Assert.Equal(HttpStatusCode.Forbidden, delete.StatusCode);
    }

    [Fact]
    public async Task Anonymous_CannotCreateEvent_ReturnsUnauthorized()
    {
        var client = _factory.CreateClient();

        var response = await client.PostAsJsonAsync("/api/events", ApiHelpers.EventBody());

        Assert.Equal(HttpStatusCode.Unauthorized, response.StatusCode);
    }

    [Fact]
    public async Task Organiser_CannotUpdateAnotherOrganisersEvent_ReturnsForbidden()
    {
        var (owner, _, _) = await ApiHelpers.RegisterAndLoginAsync(_factory, "Organiser");
        var (otherOrganiser, _, _) = await ApiHelpers.RegisterAndLoginAsync(_factory, "Organiser");
        var ev = await ApiHelpers.CreateEventAsync(owner);

        var response = await otherOrganiser.PutAsJsonAsync($"/api/events/{ev.EventID}", ApiHelpers.EventBody("Stolen"));

        Assert.Equal(HttpStatusCode.Forbidden, response.StatusCode);
    }

    [Fact]
    public async Task Organiser_CannotDeleteAnotherOrganisersEvent_ReturnsForbidden()
    {
        var (owner, _, _) = await ApiHelpers.RegisterAndLoginAsync(_factory, "Organiser");
        var (otherOrganiser, _, _) = await ApiHelpers.RegisterAndLoginAsync(_factory, "Organiser");
        var ev = await ApiHelpers.CreateEventAsync(owner);

        var response = await otherOrganiser.DeleteAsync($"/api/events/{ev.EventID}");

        Assert.Equal(HttpStatusCode.Forbidden, response.StatusCode);
    }

    // ---------- Both roles (and visitors) can view events ----------

    [Fact]
    public async Task Everyone_CanViewEvents()
    {
        var (organiser, _, _) = await ApiHelpers.RegisterAndLoginAsync(_factory, "Organiser");
        var (participant, _, _) = await ApiHelpers.RegisterAndLoginAsync(_factory, "Participant");
        var anonymous = _factory.CreateClient();
        var ev = await ApiHelpers.CreateEventAsync(organiser);

        foreach (var client in new[] { organiser, participant, anonymous })
        {
            var list = await client.GetAsync("/api/events");
            Assert.Equal(HttpStatusCode.OK, list.StatusCode);
            var events = await list.Content.ReadFromJsonAsync<List<EventResponse>>();
            Assert.Contains(events!, e => e.EventID == ev.EventID);

            Assert.Equal(HttpStatusCode.OK, (await client.GetAsync($"/api/events/{ev.EventID}")).StatusCode);
        }
    }

    // ---------- Validation and not-found ----------

    [Fact]
    public async Task CreateEvent_WithInvalidEventType_ReturnsBadRequest()
    {
        var (organiser, _, _) = await ApiHelpers.RegisterAndLoginAsync(_factory, "Organiser");

        var response = await organiser.PostAsJsonAsync("/api/events", ApiHelpers.EventBody(eventType: "Swim"));

        Assert.Equal(HttpStatusCode.BadRequest, response.StatusCode);
    }

    [Fact]
    public async Task CreateEvent_WithDateInThePast_ReturnsBadRequest()
    {
        var (organiser, _, _) = await ApiHelpers.RegisterAndLoginAsync(_factory, "Organiser");

        var response = await organiser.PostAsJsonAsync("/api/events", ApiHelpers.EventBody(daysAhead: -5));

        Assert.Equal(HttpStatusCode.BadRequest, response.StatusCode);
    }

    [Fact]
    public async Task CreateEvent_WithMissingFields_ReturnsBadRequest()
    {
        var (organiser, _, _) = await ApiHelpers.RegisterAndLoginAsync(_factory, "Organiser");

        var response = await organiser.PostAsJsonAsync("/api/events", new { name = "Only a name" });

        Assert.Equal(HttpStatusCode.BadRequest, response.StatusCode);
    }

    [Fact]
    public async Task GetEvent_ThatDoesNotExist_ReturnsNotFound()
    {
        var client = _factory.CreateClient();

        var response = await client.GetAsync("/api/events/999999");

        Assert.Equal(HttpStatusCode.NotFound, response.StatusCode);
    }

    // ---------- Categories ----------

    [Fact]
    public async Task Organiser_CanCreateCategories_AndEveryoneCanViewThem()
    {
        var (organiser, _, _) = await ApiHelpers.RegisterAndLoginAsync(_factory, "Organiser");
        var anonymous = _factory.CreateClient();
        var ev = await ApiHelpers.CreateEventAsync(organiser);

        var distance = await organiser.PostAsJsonAsync($"/api/events/{ev.EventID}/categories", new { name = "21km", distance = 21.1, maxParticipants = 50 });
        var age = await organiser.PostAsJsonAsync($"/api/events/{ev.EventID}/categories", new { name = "Under 20", maxParticipants = 50 });

        Assert.Equal(HttpStatusCode.Created, distance.StatusCode);
        Assert.Equal(HttpStatusCode.Created, age.StatusCode);   // age categories have no distance

        var list = await anonymous.GetAsync($"/api/events/{ev.EventID}/categories");
        Assert.Equal(HttpStatusCode.OK, list.StatusCode);
        var categories = await list.Content.ReadFromJsonAsync<List<CategoryResponse>>();
        Assert.Equal(2, categories!.Count);
    }

    [Fact]
    public async Task Participant_CannotCreateCategory_ReturnsForbidden()
    {
        var (organiser, _, _) = await ApiHelpers.RegisterAndLoginAsync(_factory, "Organiser");
        var (participant, _, _) = await ApiHelpers.RegisterAndLoginAsync(_factory, "Participant");
        var ev = await ApiHelpers.CreateEventAsync(organiser);

        var response = await participant.PostAsJsonAsync($"/api/events/{ev.EventID}/categories", new { name = "Senior", maxParticipants = 10 });

        Assert.Equal(HttpStatusCode.Forbidden, response.StatusCode);
    }

    [Fact]
    public async Task Organiser_CannotAddCategoryToAnotherOrganisersEvent_ReturnsForbidden()
    {
        var (owner, _, _) = await ApiHelpers.RegisterAndLoginAsync(_factory, "Organiser");
        var (other, _, _) = await ApiHelpers.RegisterAndLoginAsync(_factory, "Organiser");
        var ev = await ApiHelpers.CreateEventAsync(owner);

        var response = await other.PostAsJsonAsync($"/api/events/{ev.EventID}/categories", new { name = "Senior", maxParticipants = 10 });

        Assert.Equal(HttpStatusCode.Forbidden, response.StatusCode);
    }

    [Fact]
    public async Task CreateCategory_WithDuplicateName_ReturnsConflict()
    {
        var (organiser, _, _) = await ApiHelpers.RegisterAndLoginAsync(_factory, "Organiser");
        var ev = await ApiHelpers.CreateEventAsync(organiser);
        await ApiHelpers.CreateCategoryAsync(organiser, ev.EventID, name: "Senior");

        var response = await organiser.PostAsJsonAsync($"/api/events/{ev.EventID}/categories", new { name = "Senior", maxParticipants = 10 });

        Assert.Equal(HttpStatusCode.Conflict, response.StatusCode);
    }

    [Fact]
    public async Task Organiser_CanUpdateAndDeleteOwnCategory()
    {
        var (organiser, _, _) = await ApiHelpers.RegisterAndLoginAsync(_factory, "Organiser");
        var ev = await ApiHelpers.CreateEventAsync(organiser);
        var category = await ApiHelpers.CreateCategoryAsync(organiser, ev.EventID);

        var put = await organiser.PutAsJsonAsync($"/api/categories/{category.CategoryID}", new { name = "Masters", maxParticipants = 25 });
        Assert.Equal(HttpStatusCode.OK, put.StatusCode);

        var delete = await organiser.DeleteAsync($"/api/categories/{category.CategoryID}");
        Assert.Equal(HttpStatusCode.OK, delete.StatusCode);
    }

    [Fact]
    public async Task Categories_ForUnknownEvent_ReturnsNotFound()
    {
        var client = _factory.CreateClient();

        var response = await client.GetAsync("/api/events/999999/categories");

        Assert.Equal(HttpStatusCode.NotFound, response.StatusCode);
    }
}
