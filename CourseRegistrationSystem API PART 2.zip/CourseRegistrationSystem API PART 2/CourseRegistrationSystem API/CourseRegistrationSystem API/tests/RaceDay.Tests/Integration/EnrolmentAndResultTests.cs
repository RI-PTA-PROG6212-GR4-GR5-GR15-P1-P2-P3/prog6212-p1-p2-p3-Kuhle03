using System.Net;
using System.Net.Http.Json;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection;
using RaceDay.Api.Data;
using RaceDay.Api.Models.DTOs;

namespace RaceDay.Tests;

public class EnrolmentAndResultTests : IClassFixture<ApiFactory>
{
    private readonly ApiFactory _factory;

    public EnrolmentAndResultTests(ApiFactory factory) => _factory = factory;

    // ---------- Enrolments ----------

    [Fact]
    public async Task Participant_CanEnrol_AndEnrolmentIsRecordedCorrectly()
    {
        var (organiser, _, _) = await ApiHelpers.RegisterAndLoginAsync(_factory, "Organiser");
        var (participant, _, participantId) = await ApiHelpers.RegisterAndLoginAsync(_factory, "Participant");
        var ev = await ApiHelpers.CreateEventAsync(organiser);
        var category = await ApiHelpers.CreateCategoryAsync(organiser, ev.EventID);

        var response = await participant.PostAsJsonAsync("/api/enrolments", new { categoryId = category.CategoryID });

        Assert.Equal(HttpStatusCode.Created, response.StatusCode);
        var enrolment = await response.Content.ReadFromJsonAsync<EnrolmentResponse>();
        Assert.Equal(participantId, enrolment!.ParticipantID);
        Assert.Equal(category.CategoryID, enrolment.CategoryID);
        Assert.Equal(ev.EventID, enrolment.EventID);

        // The link between participant, category and event must really be in the database.
        using var scope = _factory.Services.CreateScope();
        var db = scope.ServiceProvider.GetRequiredService<AppDbContext>();
        var saved = await db.EventEnrolments.Include(en => en.Category)
            .SingleAsync(en => en.EnrolmentID == enrolment.EnrolmentID);
        Assert.Equal(participantId, saved.ParticipantID);
        Assert.Equal(category.CategoryID, saved.CategoryID);
        Assert.Equal(ev.EventID, saved.Category.EventID);
    }

    [Fact]
    public async Task EnrolmentsMy_ListsOnlyTheParticipantsOwnEnrolments()
    {
        var (organiser, _, _) = await ApiHelpers.RegisterAndLoginAsync(_factory, "Organiser");
        var (first, _, _) = await ApiHelpers.RegisterAndLoginAsync(_factory, "Participant");
        var (second, _, _) = await ApiHelpers.RegisterAndLoginAsync(_factory, "Participant");
        var ev = await ApiHelpers.CreateEventAsync(organiser);
        var category = await ApiHelpers.CreateCategoryAsync(organiser, ev.EventID);
        var firstEnrolment = await ApiHelpers.EnrolAsync(first, category.CategoryID);
        await ApiHelpers.EnrolAsync(second, category.CategoryID);

        var response = await first.GetAsync("/api/enrolments/my");

        Assert.Equal(HttpStatusCode.OK, response.StatusCode);
        var mine = await response.Content.ReadFromJsonAsync<List<EnrolmentResponse>>();
        Assert.Single(mine!);
        Assert.Equal(firstEnrolment.EnrolmentID, mine![0].EnrolmentID);
    }

    [Fact]
    public async Task Organiser_CannotEnrol_ReturnsForbidden()
    {
        var (organiser, _, _) = await ApiHelpers.RegisterAndLoginAsync(_factory, "Organiser");
        var ev = await ApiHelpers.CreateEventAsync(organiser);
        var category = await ApiHelpers.CreateCategoryAsync(organiser, ev.EventID);

        var response = await organiser.PostAsJsonAsync("/api/enrolments", new { categoryId = category.CategoryID });

        Assert.Equal(HttpStatusCode.Forbidden, response.StatusCode);
    }

    [Fact]
    public async Task Anonymous_CannotEnrol_ReturnsUnauthorized()
    {
        var client = _factory.CreateClient();

        var response = await client.PostAsJsonAsync("/api/enrolments", new { categoryId = 1 });

        Assert.Equal(HttpStatusCode.Unauthorized, response.StatusCode);
    }

    [Fact]
    public async Task Enrol_InSameCategoryTwice_ReturnsConflict()
    {
        var (organiser, _, _) = await ApiHelpers.RegisterAndLoginAsync(_factory, "Organiser");
        var (participant, _, _) = await ApiHelpers.RegisterAndLoginAsync(_factory, "Participant");
        var ev = await ApiHelpers.CreateEventAsync(organiser);
        var category = await ApiHelpers.CreateCategoryAsync(organiser, ev.EventID);
        await ApiHelpers.EnrolAsync(participant, category.CategoryID);

        var again = await participant.PostAsJsonAsync("/api/enrolments", new { categoryId = category.CategoryID });

        Assert.Equal(HttpStatusCode.Conflict, again.StatusCode);
    }

    [Fact]
    public async Task Enrol_InFullCategory_ReturnsConflict()
    {
        var (organiser, _, _) = await ApiHelpers.RegisterAndLoginAsync(_factory, "Organiser");
        var (first, _, _) = await ApiHelpers.RegisterAndLoginAsync(_factory, "Participant");
        var (second, _, _) = await ApiHelpers.RegisterAndLoginAsync(_factory, "Participant");
        var ev = await ApiHelpers.CreateEventAsync(organiser);
        var category = await ApiHelpers.CreateCategoryAsync(organiser, ev.EventID, maxParticipants: 1);
        await ApiHelpers.EnrolAsync(first, category.CategoryID);

        var response = await second.PostAsJsonAsync("/api/enrolments", new { categoryId = category.CategoryID });

        Assert.Equal(HttpStatusCode.Conflict, response.StatusCode);
    }

    [Fact]
    public async Task Enrol_InUnknownCategory_ReturnsNotFound()
    {
        var (participant, _, _) = await ApiHelpers.RegisterAndLoginAsync(_factory, "Participant");

        var response = await participant.PostAsJsonAsync("/api/enrolments", new { categoryId = 999999 });

        Assert.Equal(HttpStatusCode.NotFound, response.StatusCode);
    }

    [Fact]
    public async Task Organiser_CanViewEnrolmentsForOwnEvent()
    {
        var (organiser, _, _) = await ApiHelpers.RegisterAndLoginAsync(_factory, "Organiser");
        var (participant, _, _) = await ApiHelpers.RegisterAndLoginAsync(_factory, "Participant");
        var ev = await ApiHelpers.CreateEventAsync(organiser);
        var category = await ApiHelpers.CreateCategoryAsync(organiser, ev.EventID);
        await ApiHelpers.EnrolAsync(participant, category.CategoryID);

        var response = await organiser.GetAsync($"/api/events/{ev.EventID}/enrolments");

        Assert.Equal(HttpStatusCode.OK, response.StatusCode);
        var list = await response.Content.ReadFromJsonAsync<List<EnrolmentResponse>>();
        Assert.Single(list!);
    }

    [Fact]
    public async Task Participant_CannotViewEventEnrolments_ReturnsForbidden()
    {
        var (organiser, _, _) = await ApiHelpers.RegisterAndLoginAsync(_factory, "Organiser");
        var (participant, _, _) = await ApiHelpers.RegisterAndLoginAsync(_factory, "Participant");
        var ev = await ApiHelpers.CreateEventAsync(organiser);

        var response = await participant.GetAsync($"/api/events/{ev.EventID}/enrolments");

        Assert.Equal(HttpStatusCode.Forbidden, response.StatusCode);
    }

    [Fact]
    public async Task Organiser_CannotViewEnrolmentsOfAnotherOrganisersEvent_ReturnsForbidden()
    {
        var (owner, _, _) = await ApiHelpers.RegisterAndLoginAsync(_factory, "Organiser");
        var (other, _, _) = await ApiHelpers.RegisterAndLoginAsync(_factory, "Organiser");
        var ev = await ApiHelpers.CreateEventAsync(owner);

        var response = await other.GetAsync($"/api/events/{ev.EventID}/enrolments");

        Assert.Equal(HttpStatusCode.Forbidden, response.StatusCode);
    }

    [Fact]
    public async Task Participant_CanCancelOwnEnrolment_ButNotSomeoneElses()
    {
        var (organiser, _, _) = await ApiHelpers.RegisterAndLoginAsync(_factory, "Organiser");
        var (owner, _, _) = await ApiHelpers.RegisterAndLoginAsync(_factory, "Participant");
        var (stranger, _, _) = await ApiHelpers.RegisterAndLoginAsync(_factory, "Participant");
        var ev = await ApiHelpers.CreateEventAsync(organiser);
        var category = await ApiHelpers.CreateCategoryAsync(organiser, ev.EventID);
        var enrolment = await ApiHelpers.EnrolAsync(owner, category.CategoryID);

        var byStranger = await stranger.DeleteAsync($"/api/enrolments/{enrolment.EnrolmentID}");
        var byOwner = await owner.DeleteAsync($"/api/enrolments/{enrolment.EnrolmentID}");

        Assert.Equal(HttpStatusCode.Forbidden, byStranger.StatusCode);
        Assert.Equal(HttpStatusCode.OK, byOwner.StatusCode);
    }

    // ---------- Results ----------

    [Fact]
    public async Task Organiser_CanCaptureResult_AndParticipantCanViewOwnResults()
    {
        var (organiser, _, _) = await ApiHelpers.RegisterAndLoginAsync(_factory, "Organiser");
        var (participant, _, participantId) = await ApiHelpers.RegisterAndLoginAsync(_factory, "Participant");
        var ev = await ApiHelpers.CreateEventAsync(organiser);
        var category = await ApiHelpers.CreateCategoryAsync(organiser, ev.EventID);
        var enrolment = await ApiHelpers.EnrolAsync(participant, category.CategoryID);

        var capture = await organiser.PostAsJsonAsync("/api/results",
            new { enrolmentId = enrolment.EnrolmentID, finishTime = "00:45:10", position = 1 });

        Assert.Equal(HttpStatusCode.Created, capture.StatusCode);

        var mine = await participant.GetAsync($"/api/participants/{participantId}/results");
        Assert.Equal(HttpStatusCode.OK, mine.StatusCode);
        var results = await mine.Content.ReadFromJsonAsync<List<ResultResponse>>();
        Assert.Single(results!);
        Assert.Equal(1, results![0].Position);
        Assert.Equal(new TimeSpan(0, 45, 10), results[0].FinishTime);
    }

    [Fact]
    public async Task Participant_CannotCaptureResult_ReturnsForbidden()
    {
        var (organiser, _, _) = await ApiHelpers.RegisterAndLoginAsync(_factory, "Organiser");
        var (participant, _, _) = await ApiHelpers.RegisterAndLoginAsync(_factory, "Participant");
        var ev = await ApiHelpers.CreateEventAsync(organiser);
        var category = await ApiHelpers.CreateCategoryAsync(organiser, ev.EventID);
        var enrolment = await ApiHelpers.EnrolAsync(participant, category.CategoryID);

        var response = await participant.PostAsJsonAsync("/api/results",
            new { enrolmentId = enrolment.EnrolmentID, finishTime = "00:30:00", position = 1 });

        Assert.Equal(HttpStatusCode.Forbidden, response.StatusCode);
    }

    [Fact]
    public async Task Organiser_CannotCaptureResultForAnotherOrganisersEvent_ReturnsForbidden()
    {
        var (owner, _, _) = await ApiHelpers.RegisterAndLoginAsync(_factory, "Organiser");
        var (other, _, _) = await ApiHelpers.RegisterAndLoginAsync(_factory, "Organiser");
        var (participant, _, _) = await ApiHelpers.RegisterAndLoginAsync(_factory, "Participant");
        var ev = await ApiHelpers.CreateEventAsync(owner);
        var category = await ApiHelpers.CreateCategoryAsync(owner, ev.EventID);
        var enrolment = await ApiHelpers.EnrolAsync(participant, category.CategoryID);

        var response = await other.PostAsJsonAsync("/api/results",
            new { enrolmentId = enrolment.EnrolmentID, finishTime = "00:30:00", position = 1 });

        Assert.Equal(HttpStatusCode.Forbidden, response.StatusCode);
    }

    [Fact]
    public async Task CaptureResult_Twice_ForSameEnrolment_ReturnsConflict()
    {
        var (organiser, _, _) = await ApiHelpers.RegisterAndLoginAsync(_factory, "Organiser");
        var (participant, _, _) = await ApiHelpers.RegisterAndLoginAsync(_factory, "Participant");
        var ev = await ApiHelpers.CreateEventAsync(organiser);
        var category = await ApiHelpers.CreateCategoryAsync(organiser, ev.EventID);
        var enrolment = await ApiHelpers.EnrolAsync(participant, category.CategoryID);
        await organiser.PostAsJsonAsync("/api/results", new { enrolmentId = enrolment.EnrolmentID, finishTime = "00:30:00", position = 1 });

        var again = await organiser.PostAsJsonAsync("/api/results", new { enrolmentId = enrolment.EnrolmentID, finishTime = "00:31:00", position = 2 });

        Assert.Equal(HttpStatusCode.Conflict, again.StatusCode);
    }

    [Fact]
    public async Task CaptureResult_WithPositionAlreadyTakenInCategory_ReturnsConflict()
    {
        var (organiser, _, _) = await ApiHelpers.RegisterAndLoginAsync(_factory, "Organiser");
        var (first, _, _) = await ApiHelpers.RegisterAndLoginAsync(_factory, "Participant");
        var (second, _, _) = await ApiHelpers.RegisterAndLoginAsync(_factory, "Participant");
        var ev = await ApiHelpers.CreateEventAsync(organiser);
        var category = await ApiHelpers.CreateCategoryAsync(organiser, ev.EventID);
        var e1 = await ApiHelpers.EnrolAsync(first, category.CategoryID);
        var e2 = await ApiHelpers.EnrolAsync(second, category.CategoryID);
        await organiser.PostAsJsonAsync("/api/results", new { enrolmentId = e1.EnrolmentID, finishTime = "00:30:00", position = 1 });

        var response = await organiser.PostAsJsonAsync("/api/results", new { enrolmentId = e2.EnrolmentID, finishTime = "00:31:00", position = 1 });

        Assert.Equal(HttpStatusCode.Conflict, response.StatusCode);
    }

    [Fact]
    public async Task CaptureResult_ForUnknownEnrolment_ReturnsNotFound()
    {
        var (organiser, _, _) = await ApiHelpers.RegisterAndLoginAsync(_factory, "Organiser");

        var response = await organiser.PostAsJsonAsync("/api/results", new { enrolmentId = 999999, finishTime = "00:30:00", position = 1 });

        Assert.Equal(HttpStatusCode.NotFound, response.StatusCode);
    }

    [Fact]
    public async Task Participant_CannotViewAnotherParticipantsResults_ReturnsForbidden()
    {
        var (first, _, _) = await ApiHelpers.RegisterAndLoginAsync(_factory, "Participant");
        var (_, _, secondId) = await ApiHelpers.RegisterAndLoginAsync(_factory, "Participant");

        var response = await first.GetAsync($"/api/participants/{secondId}/results");

        Assert.Equal(HttpStatusCode.Forbidden, response.StatusCode);
    }

    [Fact]
    public async Task Organiser_CanViewAParticipantsResults()
    {
        var (organiser, _, _) = await ApiHelpers.RegisterAndLoginAsync(_factory, "Organiser");
        var (_, _, participantId) = await ApiHelpers.RegisterAndLoginAsync(_factory, "Participant");

        var response = await organiser.GetAsync($"/api/participants/{participantId}/results");

        Assert.Equal(HttpStatusCode.OK, response.StatusCode);
    }

    [Fact]
    public async Task Results_WithoutLogin_ReturnsUnauthorized()
    {
        var client = _factory.CreateClient();

        var response = await client.GetAsync("/api/participants/1/results");

        Assert.Equal(HttpStatusCode.Unauthorized, response.StatusCode);
    }

    [Fact]
    public async Task EventResults_AreVisibleToEveryone()
    {
        var (organiser, _, _) = await ApiHelpers.RegisterAndLoginAsync(_factory, "Organiser");
        var (participant, _, _) = await ApiHelpers.RegisterAndLoginAsync(_factory, "Participant");
        var anonymous = _factory.CreateClient();
        var ev = await ApiHelpers.CreateEventAsync(organiser);
        var category = await ApiHelpers.CreateCategoryAsync(organiser, ev.EventID);
        var enrolment = await ApiHelpers.EnrolAsync(participant, category.CategoryID);
        await organiser.PostAsJsonAsync("/api/results", new { enrolmentId = enrolment.EnrolmentID, finishTime = "00:30:00", position = 1 });

        var response = await anonymous.GetAsync($"/api/events/{ev.EventID}/results");

        Assert.Equal(HttpStatusCode.OK, response.StatusCode);
        var results = await response.Content.ReadFromJsonAsync<List<ResultResponse>>();
        Assert.Single(results!);
    }

    [Fact]
    public async Task Organiser_CanCorrectAResult()
    {
        var (organiser, _, _) = await ApiHelpers.RegisterAndLoginAsync(_factory, "Organiser");
        var (participant, _, _) = await ApiHelpers.RegisterAndLoginAsync(_factory, "Participant");
        var ev = await ApiHelpers.CreateEventAsync(organiser);
        var category = await ApiHelpers.CreateCategoryAsync(organiser, ev.EventID);
        var enrolment = await ApiHelpers.EnrolAsync(participant, category.CategoryID);
        var capture = await organiser.PostAsJsonAsync("/api/results", new { enrolmentId = enrolment.EnrolmentID, finishTime = "00:30:00", position = 2 });
        var created = await capture.Content.ReadFromJsonAsync<ResultResponse>();

        var update = await organiser.PutAsJsonAsync($"/api/results/{created!.ResultID}", new { finishTime = "00:29:00", position = 1 });

        Assert.Equal(HttpStatusCode.OK, update.StatusCode);
        var updated = await update.Content.ReadFromJsonAsync<ResultResponse>();
        Assert.Equal(1, updated!.Position);
        Assert.Equal(new TimeSpan(0, 29, 0), updated.FinishTime);
    }
}
