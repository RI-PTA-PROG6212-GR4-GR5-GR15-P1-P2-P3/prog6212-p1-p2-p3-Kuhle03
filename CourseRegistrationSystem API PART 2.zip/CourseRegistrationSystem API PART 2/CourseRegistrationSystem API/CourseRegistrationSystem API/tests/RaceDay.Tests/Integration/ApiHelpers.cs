using System.Net.Http.Json;
using RaceDay.Api.Models.DTOs;

namespace RaceDay.Tests;

/// <summary>Small helpers so each test reads like a story instead of a pile of HTTP calls.</summary>
public static class ApiHelpers
{
    public const string Password = "Password123!";

    public static string UniqueEmail(string prefix) => $"{prefix}-{Guid.NewGuid():N}@test.com";

    /// <summary>Registers a new user and logs them in. The returned client keeps the session cookie.</summary>
    public static async Task<(HttpClient Client, string Email, int UserId)> RegisterAndLoginAsync(ApiFactory factory, string role)
    {
        var client = factory.CreateClient();
        var email = UniqueEmail(role.ToLowerInvariant());

        var register = await client.PostAsJsonAsync("/api/auth/register", new
        {
            fullName = "Test " + role,
            email,
            password = Password,
            contactNumber = "0820000000",
            role
        });
        register.EnsureSuccessStatusCode();
        var body = await register.Content.ReadFromJsonAsync<AuthResponse>();

        var login = await client.PostAsJsonAsync("/api/auth/login", new { email, password = Password });
        login.EnsureSuccessStatusCode();

        return (client, email, body!.UserId);
    }

    public static object EventBody(string name = "Test Race", string eventType = "Run", int daysAhead = 30) => new
    {
        name,
        description = "A test event.",
        eventDate = DateTime.UtcNow.Date.AddDays(daysAhead),
        location = "Johannesburg",
        distance = 10,
        eventType,
        routeInfo = "Flat loop."
    };

    public static async Task<EventResponse> CreateEventAsync(HttpClient organiser, string eventType = "Run")
    {
        var response = await organiser.PostAsJsonAsync("/api/events", EventBody(eventType: eventType));
        response.EnsureSuccessStatusCode();
        return (await response.Content.ReadFromJsonAsync<EventResponse>())!;
    }

    public static async Task<CategoryResponse> CreateCategoryAsync(HttpClient organiser, int eventId, int maxParticipants = 100, string name = "10km")
    {
        var response = await organiser.PostAsJsonAsync($"/api/events/{eventId}/categories",
            new { name, distance = 10, maxParticipants });
        response.EnsureSuccessStatusCode();
        return (await response.Content.ReadFromJsonAsync<CategoryResponse>())!;
    }

    public static async Task<EnrolmentResponse> EnrolAsync(HttpClient participant, int categoryId)
    {
        var response = await participant.PostAsJsonAsync("/api/enrolments", new { categoryId });
        response.EnsureSuccessStatusCode();
        return (await response.Content.ReadFromJsonAsync<EnrolmentResponse>())!;
    }
}
