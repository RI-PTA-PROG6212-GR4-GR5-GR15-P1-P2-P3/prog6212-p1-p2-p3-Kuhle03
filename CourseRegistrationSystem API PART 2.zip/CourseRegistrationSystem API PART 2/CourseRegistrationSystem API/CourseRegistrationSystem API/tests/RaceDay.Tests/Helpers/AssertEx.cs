using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Xunit;

namespace RaceDay.Tests;

public static class AssertEx
{
    /// <summary>The API answers "logged in, but not allowed" with an ObjectResult carrying status code 403.</summary>
    public static void Forbidden(IActionResult? result)
    {
        var objectResult = Assert.IsType<ObjectResult>(result);
        Assert.Equal(StatusCodes.Status403Forbidden, objectResult.StatusCode);
    }

    /// <summary>The API answers a successful create with an ObjectResult carrying status code 201.</summary>
    public static T Created<T>(IActionResult? result)
    {
        var objectResult = Assert.IsType<ObjectResult>(result);
        Assert.Equal(StatusCodes.Status201Created, objectResult.StatusCode);
        return Assert.IsType<T>(objectResult.Value);
    }
}
