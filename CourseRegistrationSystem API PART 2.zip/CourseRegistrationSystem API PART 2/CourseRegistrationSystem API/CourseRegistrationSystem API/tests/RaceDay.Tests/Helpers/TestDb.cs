using Microsoft.EntityFrameworkCore;
using RaceDay.Api.Data;
using RaceDay.Api.Models;

namespace RaceDay.Tests;

/// <summary>
/// Creates a brand-new in-memory database for every test, so tests never share data
/// and never touch a real SQL Server database. The Add... methods create small pieces of test data.
/// </summary>
public static class TestDb
{
    public const string HashedPassword = "hashed-password";

    public static AppDbContext Create()
    {
        var options = new DbContextOptionsBuilder<AppDbContext>()
            .UseInMemoryDatabase("UnitTests-" + Guid.NewGuid())
            .Options;
        return new AppDbContext(options);
    }

    public static Organiser AddOrganiser(AppDbContext db, string? email = null)
    {
        var organiser = new Organiser
        {
            FullName = "Test Organiser",
            Email = email ?? $"org-{Guid.NewGuid():N}@test.com",
            PasswordHash = HashedPassword
        };
        db.Organisers.Add(organiser);
        db.SaveChanges();
        return organiser;
    }

    public static Participant AddParticipant(AppDbContext db, string? email = null)
    {
        var participant = new Participant
        {
            FullName = "Test Participant",
            Email = email ?? $"par-{Guid.NewGuid():N}@test.com",
            PasswordHash = HashedPassword
        };
        db.Participants.Add(participant);
        db.SaveChanges();
        return participant;
    }

    public static RaceEvent AddEvent(AppDbContext db, Organiser owner, int daysAhead = 30)
    {
        var ev = new RaceEvent
        {
            OrganiserID = owner.OrganiserID,
            Name = "Test Race",
            Description = "A test event.",
            EventDate = DateTime.UtcNow.Date.AddDays(daysAhead),
            Location = "Johannesburg",
            Distance = 10m,
            EventType = "Run"
        };
        db.Events.Add(ev);
        db.SaveChanges();
        return ev;
    }

    public static Category AddCategory(AppDbContext db, RaceEvent ev, int maxParticipants = 100, string name = "10km")
    {
        var category = new Category { EventID = ev.EventID, Name = name, Distance = 10m, MaxParticipants = maxParticipants };
        db.Categories.Add(category);
        db.SaveChanges();
        return category;
    }

    public static EventEnrolment AddEnrolment(AppDbContext db, Participant participant, Category category)
    {
        var enrolment = new EventEnrolment { ParticipantID = participant.ParticipantID, CategoryID = category.CategoryID };
        db.EventEnrolments.Add(enrolment);
        db.SaveChanges();
        return enrolment;
    }

    public static RaceResult AddResult(AppDbContext db, EventEnrolment enrolment, int position = 1)
    {
        var result = new RaceResult { EnrolmentID = enrolment.EnrolmentID, FinishTime = new TimeSpan(0, 30, 0), Position = position };
        db.Results.Add(result);
        db.SaveChanges();
        return result;
    }
}
