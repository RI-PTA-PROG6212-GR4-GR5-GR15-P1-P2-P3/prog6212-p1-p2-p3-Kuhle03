using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using RaceDay.Api.Helpers;

namespace RaceDay.Tests;

public static class ControllerTestHelper
{
    /// <summary>
    /// Gives a controller a fake session. Pass a userId and role to simulate a logged-in user,
    /// or leave both empty to simulate a visitor who is not logged in.
    /// </summary>
    public static T WithSession<T>(T controller, int? userId = null, string? role = null) where T : ControllerBase
    {
        var session = new FakeSession();
        if (userId.HasValue) session.SetInt32(SessionKeys.UserId, userId.Value);
        if (role != null) session.SetString(SessionKeys.Role, role);

        controller.ControllerContext = new ControllerContext
        {
            HttpContext = new DefaultHttpContext { Session = session }
        };
        return controller;
    }
}
