using Microsoft.AspNetCore.Mvc;
using RaceDay.Api.Controllers;
using RaceDay.Api.Data;
using RaceDay.Api.Helpers;
using RaceDay.Api.Models.DTOs;

namespace RaceDay.Tests;

public class CategoriesControllerTests
{
    private readonly AppDbContext _db = TestDb.Create();

    private CategoriesController CreateController(int? userId = null, string? role = null) =>
        ControllerTestHelper.WithSession(new CategoriesController(_db), userId, role);

    private static CategoryDto ValidCategoryDto(string name = "21km", decimal? distance = 21.1m, int max = 50) =>
        new() { Name = name, Distance = distance, MaxParticipants = max };

    [Fact]
    public async Task CreateCategory_OwnEvent_ReturnsCreatedAndSavesCategory()
    {
        // Arrange
        var organiser = TestDb.AddOrganiser(_db);
        var ev = TestDb.AddEvent(_db, organiser);
        var controller = CreateController(organiser.OrganiserID, Roles.Organiser);

        // Act
        var result = await controller.CreateCategory(ev.EventID, ValidCategoryDto());

        // Assert
        var created = Assert.IsType<CreatedAtActionResult>(result.Result);
        var body = Assert.IsType<CategoryResponse>(created.Value);
        Assert.Equal(ev.EventID, body.EventID);
        Assert.Single(_db.Categories);
    }

    [Fact]
    public async Task CreateCategory_AgeCategoryWithoutDistance_ReturnsCreated()
    {
        // Arrange
        var organiser = TestDb.AddOrganiser(_db);
        var ev = TestDb.AddEvent(_db, organiser);
        var controller = CreateController(organiser.OrganiserID, Roles.Organiser);

        // Act
        var result = await controller.CreateCategory(ev.EventID, ValidCategoryDto(name: "Under 20", distance: null));

        // Assert
        var created = Assert.IsType<CreatedAtActionResult>(result.Result);
        var body = Assert.IsType<CategoryResponse>(created.Value);
        Assert.Null(body.Distance);
    }

    [Fact]
    public async Task CreateCategory_DuplicateNameInSameEvent_ReturnsConflict()
    {
        // Arrange
        var organiser = TestDb.AddOrganiser(_db);
        var ev = TestDb.AddEvent(_db, organiser);
        TestDb.AddCategory(_db, ev, name: "Senior");
        var controller = CreateController(organiser.OrganiserID, Roles.Organiser);

        // Act
        var result = await controller.CreateCategory(ev.EventID, ValidCategoryDto(name: "Senior"));

        // Assert
        Assert.IsType<ConflictObjectResult>(result.Result);
        Assert.Single(_db.Categories);
    }

    [Fact]
    public async Task CreateCategory_SameNameInDifferentEvent_ReturnsCreated()
    {
        // Arrange
        var organiser = TestDb.AddOrganiser(_db);
        var firstEvent = TestDb.AddEvent(_db, organiser);
        var secondEvent = TestDb.AddEvent(_db, organiser);
        TestDb.AddCategory(_db, firstEvent, name: "Senior");
        var controller = CreateController(organiser.OrganiserID, Roles.Organiser);

        // Act
        var result = await controller.CreateCategory(secondEvent.EventID, ValidCategoryDto(name: "Senior"));

        // Assert
        Assert.IsType<CreatedAtActionResult>(result.Result);
    }

    [Fact]
    public async Task CreateCategory_UnknownEvent_ReturnsNotFound()
    {
        // Arrange
        var organiser = TestDb.AddOrganiser(_db);
        var controller = CreateController(organiser.OrganiserID, Roles.Organiser);

        // Act
        var result = await controller.CreateCategory(999, ValidCategoryDto());

        // Assert
        Assert.IsType<NotFoundObjectResult>(result.Result);
    }

    [Fact]
    public async Task CreateCategory_AnotherOrganisersEvent_ReturnsForbidden()
    {
        // Arrange
        var owner = TestDb.AddOrganiser(_db);
        var otherOrganiser = TestDb.AddOrganiser(_db);
        var ev = TestDb.AddEvent(_db, owner);
        var controller = CreateController(otherOrganiser.OrganiserID, Roles.Organiser);

        // Act
        var result = await controller.CreateCategory(ev.EventID, ValidCategoryDto());

        // Assert
        AssertEx.Forbidden(result.Result);
        Assert.Empty(_db.Categories);
    }

    [Fact]
    public async Task GetCategories_EventWithCategories_ReturnsThemWithEnrolledCount()
    {
        // Arrange
        var organiser = TestDb.AddOrganiser(_db);
        var participant = TestDb.AddParticipant(_db);
        var ev = TestDb.AddEvent(_db, organiser);
        var category = TestDb.AddCategory(_db, ev);
        TestDb.AddEnrolment(_db, participant, category);
        var controller = CreateController();

        // Act
        var result = await controller.GetCategories(ev.EventID);

        // Assert
        var ok = Assert.IsType<OkObjectResult>(result.Result);
        var categories = Assert.IsAssignableFrom<IEnumerable<CategoryResponse>>(ok.Value).ToList();
        Assert.Single(categories);
        Assert.Equal(1, categories[0].EnrolledCount);
    }

    [Fact]
    public async Task GetCategories_UnknownEvent_ReturnsNotFound()
    {
        // Arrange
        var controller = CreateController();

        // Act
        var result = await controller.GetCategories(999);

        // Assert
        Assert.IsType<NotFoundObjectResult>(result.Result);
    }

    [Fact]
    public async Task GetCategory_UnknownId_ReturnsNotFound()
    {
        // Arrange
        var controller = CreateController();

        // Act
        var result = await controller.GetCategory(999);

        // Assert
        Assert.IsType<NotFoundObjectResult>(result.Result);
    }

    [Fact]
    public async Task UpdateCategory_OwnCategory_ReturnsOkWithNewValues()
    {
        // Arrange
        var organiser = TestDb.AddOrganiser(_db);
        var ev = TestDb.AddEvent(_db, organiser);
        var category = TestDb.AddCategory(_db, ev);
        var controller = CreateController(organiser.OrganiserID, Roles.Organiser);

        // Act
        var result = await controller.UpdateCategory(category.CategoryID, ValidCategoryDto(name: "Masters", max: 25));

        // Assert
        var ok = Assert.IsType<OkObjectResult>(result.Result);
        var body = Assert.IsType<CategoryResponse>(ok.Value);
        Assert.Equal("Masters", body.Name);
        Assert.Equal(25, body.MaxParticipants);
    }

    [Fact]
    public async Task UpdateCategory_LimitLowerThanEnrolledCount_ReturnsBadRequest()
    {
        // Arrange
        var organiser = TestDb.AddOrganiser(_db);
        var first = TestDb.AddParticipant(_db);
        var second = TestDb.AddParticipant(_db);
        var ev = TestDb.AddEvent(_db, organiser);
        var category = TestDb.AddCategory(_db, ev);
        TestDb.AddEnrolment(_db, first, category);
        TestDb.AddEnrolment(_db, second, category);
        var controller = CreateController(organiser.OrganiserID, Roles.Organiser);

        // Act
        var result = await controller.UpdateCategory(category.CategoryID, ValidCategoryDto(max: 1));

        // Assert
        Assert.IsType<BadRequestObjectResult>(result.Result);
    }

    [Fact]
    public async Task UpdateCategory_AnotherOrganisersCategory_ReturnsForbidden()
    {
        // Arrange
        var owner = TestDb.AddOrganiser(_db);
        var otherOrganiser = TestDb.AddOrganiser(_db);
        var ev = TestDb.AddEvent(_db, owner);
        var category = TestDb.AddCategory(_db, ev);
        var controller = CreateController(otherOrganiser.OrganiserID, Roles.Organiser);

        // Act
        var result = await controller.UpdateCategory(category.CategoryID, ValidCategoryDto());

        // Assert
        AssertEx.Forbidden(result.Result);
    }

    [Fact]
    public async Task UpdateCategory_UnknownId_ReturnsNotFound()
    {
        // Arrange
        var organiser = TestDb.AddOrganiser(_db);
        var controller = CreateController(organiser.OrganiserID, Roles.Organiser);

        // Act
        var result = await controller.UpdateCategory(999, ValidCategoryDto());

        // Assert
        Assert.IsType<NotFoundObjectResult>(result.Result);
    }

    [Fact]
    public async Task DeleteCategory_OwnCategoryWithoutEnrolments_ReturnsOkAndRemovesIt()
    {
        // Arrange
        var organiser = TestDb.AddOrganiser(_db);
        var ev = TestDb.AddEvent(_db, organiser);
        var category = TestDb.AddCategory(_db, ev);
        var controller = CreateController(organiser.OrganiserID, Roles.Organiser);

        // Act
        var result = await controller.DeleteCategory(category.CategoryID);

        // Assert
        Assert.IsType<OkObjectResult>(result);
        Assert.Empty(_db.Categories);
    }

    [Fact]
    public async Task DeleteCategory_CategoryHasEnrolments_ReturnsConflict()
    {
        // Arrange
        var organiser = TestDb.AddOrganiser(_db);
        var participant = TestDb.AddParticipant(_db);
        var ev = TestDb.AddEvent(_db, organiser);
        var category = TestDb.AddCategory(_db, ev);
        TestDb.AddEnrolment(_db, participant, category);
        var controller = CreateController(organiser.OrganiserID, Roles.Organiser);

        // Act
        var result = await controller.DeleteCategory(category.CategoryID);

        // Assert
        Assert.IsType<ConflictObjectResult>(result);
        Assert.Single(_db.Categories);
    }

    [Fact]
    public async Task DeleteCategory_UnknownId_ReturnsNotFound()
    {
        // Arrange
        var organiser = TestDb.AddOrganiser(_db);
        var controller = CreateController(organiser.OrganiserID, Roles.Organiser);

        // Act
        var result = await controller.DeleteCategory(999);

        // Assert
        Assert.IsType<NotFoundObjectResult>(result);
    }
}
