using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Moq;
using RaceDay.Api.Controllers;
using RaceDay.Api.Data;
using RaceDay.Api.Helpers;
using RaceDay.Api.Models.DTOs;
using RaceDay.Api.Services;

namespace RaceDay.Tests;

/// <summary>
/// Unit tests for AuthController. The password service is replaced with a Moq mock so the tests
/// are fast and only check the controller's own behaviour. The database is a fresh in-memory one.
/// </summary>
public class AuthControllerTests
{
    private readonly AppDbContext _db = TestDb.Create();
    private readonly Mock<IPasswordService> _passwords = new();
    private readonly AuthController _controller;

    public AuthControllerTests()
    {
        _passwords.Setup(p => p.Hash(It.IsAny<string>())).Returns(TestDb.HashedPassword);
        _passwords.Setup(p => p.Verify("Password123!", TestDb.HashedPassword)).Returns(true);
        _passwords.Setup(p => p.Verify("WrongPassword", TestDb.HashedPassword)).Returns(false);

        _controller = ControllerTestHelper.WithSession(new AuthController(_db, _passwords.Object));
    }

    private static RegisterDto ValidRegisterDto(string email = "new@example.com", string role = "Participant") => new()
    {
        FullName = "Test User",
        Email = email,
        Password = "Password123!",
        ContactNumber = "0820000000",
        Role = role
    };

    // ---------- Register ----------

    [Fact]
    public async Task Register_ValidParticipant_ReturnsCreatedAndSavesParticipant()
    {
        // Arrange
        var dto = ValidRegisterDto(role: "Participant");

        // Act
        var result = await _controller.Register(dto);

        // Assert
        var body = AssertEx.Created<AuthResponse>(result.Result);
        Assert.Equal("Participant", body.Role);
        Assert.Single(_db.Participants);
        Assert.Empty(_db.Organisers);
    }

    [Fact]
    public async Task Register_ValidOrganiser_ReturnsCreatedAndSavesOrganiser()
    {
        // Arrange
        var dto = ValidRegisterDto(role: "Organiser");

        // Act
        var result = await _controller.Register(dto);

        // Assert
        var body = AssertEx.Created<AuthResponse>(result.Result);
        Assert.Equal("Organiser", body.Role);
        Assert.Single(_db.Organisers);
        Assert.Empty(_db.Participants);
    }

    [Fact]
    public async Task Register_RoleInDifferentCase_IsAcceptedAndTidied()
    {
        // Arrange
        var dto = ValidRegisterDto(role: "organiser");

        // Act
        var result = await _controller.Register(dto);

        // Assert
        var body = AssertEx.Created<AuthResponse>(result.Result);
        Assert.Equal("Organiser", body.Role);
    }

    [Fact]
    public async Task Register_PasswordIsHashed_StoredValueIsNotThePlainPassword()
    {
        // Arrange
        var dto = ValidRegisterDto();

        // Act
        await _controller.Register(dto);

        // Assert
        var saved = Assert.Single(_db.Participants);
        Assert.NotEqual("Password123!", saved.PasswordHash);
        Assert.Equal(TestDb.HashedPassword, saved.PasswordHash);
        _passwords.Verify(p => p.Hash("Password123!"), Times.Once);
    }

    [Fact]
    public async Task Register_DuplicateEmail_ReturnsConflict()
    {
        // Arrange
        TestDb.AddParticipant(_db, "taken@example.com");
        var dto = ValidRegisterDto(email: "taken@example.com");

        // Act
        var result = await _controller.Register(dto);

        // Assert
        Assert.IsType<ConflictObjectResult>(result.Result);
        Assert.Single(_db.Participants);
    }

    [Fact]
    public async Task Register_EmailAlreadyUsedByAnOrganiser_ReturnsConflict()
    {
        // Arrange
        TestDb.AddOrganiser(_db, "taken@example.com");
        var dto = ValidRegisterDto(email: "taken@example.com", role: "Participant");

        // Act
        var result = await _controller.Register(dto);

        // Assert
        Assert.IsType<ConflictObjectResult>(result.Result);
        Assert.Empty(_db.Participants);
    }

    [Fact]
    public async Task Register_DuplicateEmailInDifferentCase_ReturnsConflict()
    {
        // Arrange
        TestDb.AddParticipant(_db, "taken@example.com");
        var dto = ValidRegisterDto(email: "TAKEN@Example.com");

        // Act
        var result = await _controller.Register(dto);

        // Assert
        Assert.IsType<ConflictObjectResult>(result.Result);
    }

    [Fact]
    public async Task Register_InvalidRole_ReturnsBadRequest()
    {
        // Arrange
        var dto = ValidRegisterDto(role: "Admin");

        // Act
        var result = await _controller.Register(dto);

        // Assert
        Assert.IsType<BadRequestObjectResult>(result.Result);
        Assert.Empty(_db.Participants);
        Assert.Empty(_db.Organisers);
    }

    // ---------- Login ----------

    [Fact]
    public async Task Login_ValidParticipantCredentials_ReturnsOkAndStartsSession()
    {
        // Arrange
        var participant = TestDb.AddParticipant(_db, "lindiwe@example.com");
        var dto = new LoginDto { Email = "lindiwe@example.com", Password = "Password123!" };

        // Act
        var result = await _controller.Login(dto);

        // Assert
        var ok = Assert.IsType<OkObjectResult>(result.Result);
        var body = Assert.IsType<AuthResponse>(ok.Value);
        Assert.Equal("Participant", body.Role);
        Assert.Equal(participant.ParticipantID, _controller.HttpContext.Session.GetInt32(SessionKeys.UserId));
        Assert.Equal("Participant", _controller.HttpContext.Session.GetString(SessionKeys.Role));
    }

    [Fact]
    public async Task Login_ValidOrganiserCredentials_ReturnsOkAndStoresOrganiserRole()
    {
        // Arrange
        var organiser = TestDb.AddOrganiser(_db, "thandeka@raceday.co.za");
        var dto = new LoginDto { Email = "thandeka@raceday.co.za", Password = "Password123!" };

        // Act
        var result = await _controller.Login(dto);

        // Assert
        Assert.IsType<OkObjectResult>(result.Result);
        Assert.Equal(organiser.OrganiserID, _controller.HttpContext.Session.GetInt32(SessionKeys.UserId));
        Assert.Equal("Organiser", _controller.HttpContext.Session.GetString(SessionKeys.Role));
    }

    [Fact]
    public async Task Login_EmailInDifferentCase_ReturnsOk()
    {
        // Arrange
        TestDb.AddParticipant(_db, "lindiwe@example.com");
        var dto = new LoginDto { Email = "LINDIWE@example.com", Password = "Password123!" };

        // Act
        var result = await _controller.Login(dto);

        // Assert
        Assert.IsType<OkObjectResult>(result.Result);
    }

    [Fact]
    public async Task Login_WrongPassword_ReturnsUnauthorizedAndNoSession()
    {
        // Arrange
        TestDb.AddParticipant(_db, "lindiwe@example.com");
        var dto = new LoginDto { Email = "lindiwe@example.com", Password = "WrongPassword" };

        // Act
        var result = await _controller.Login(dto);

        // Assert
        Assert.IsType<UnauthorizedObjectResult>(result.Result);
        Assert.Null(_controller.HttpContext.Session.GetInt32(SessionKeys.UserId));
        Assert.Null(_controller.HttpContext.Session.GetString(SessionKeys.Role));
    }

    [Fact]
    public async Task Login_WrongPasswordForOrganiser_ReturnsUnauthorized()
    {
        // Arrange
        TestDb.AddOrganiser(_db, "thandeka@raceday.co.za");
        var dto = new LoginDto { Email = "thandeka@raceday.co.za", Password = "WrongPassword" };

        // Act
        var result = await _controller.Login(dto);

        // Assert
        Assert.IsType<UnauthorizedObjectResult>(result.Result);
    }

    [Fact]
    public async Task Login_UnknownEmail_ReturnsUnauthorized()
    {
        // Arrange
        var dto = new LoginDto { Email = "unknown@example.com", Password = "Password123!" };

        // Act
        var result = await _controller.Login(dto);

        // Assert
        Assert.IsType<UnauthorizedObjectResult>(result.Result);
        Assert.Null(_controller.HttpContext.Session.GetInt32(SessionKeys.UserId));
    }

    [Fact]
    public async Task Login_AfterEarlierLogin_ReplacesTheOldSession()
    {
        // Arrange
        var participant = TestDb.AddParticipant(_db, "lindiwe@example.com");
        _controller.HttpContext.Session.SetInt32(SessionKeys.UserId, 999);
        _controller.HttpContext.Session.SetString(SessionKeys.Role, "Organiser");
        var dto = new LoginDto { Email = "lindiwe@example.com", Password = "Password123!" };

        // Act
        await _controller.Login(dto);

        // Assert
        Assert.Equal(participant.ParticipantID, _controller.HttpContext.Session.GetInt32(SessionKeys.UserId));
        Assert.Equal("Participant", _controller.HttpContext.Session.GetString(SessionKeys.Role));
    }

    // ---------- Logout ----------

    [Fact]
    public void Logout_LoggedInUser_ClearsTheSession()
    {
        // Arrange
        _controller.HttpContext.Session.SetInt32(SessionKeys.UserId, 1);
        _controller.HttpContext.Session.SetString(SessionKeys.Role, "Participant");

        // Act
        var result = _controller.Logout();

        // Assert
        Assert.IsType<OkObjectResult>(result);
        Assert.Null(_controller.HttpContext.Session.GetInt32(SessionKeys.UserId));
        Assert.Null(_controller.HttpContext.Session.GetString(SessionKeys.Role));
    }
}
