using Microsoft.AspNetCore.Mvc;
using RaceDay.Api.Controllers;
using RaceDay.Api.Data;
using RaceDay.Api.Helpers;
using RaceDay.Api.Models.DTOs;

namespace RaceDay.Tests;

public class ProfileControllerTests
{
    private readonly AppDbContext _db = TestDb.Create();

    private ProfileController CreateController(int userId, string role) =>
        ControllerTestHelper.WithSession(new ProfileController(_db), userId, role);

    [Fact]
    public async Task GetProfile_Organiser_ReturnsOwnProfile()
    {
        // Arrange
        var organiser = TestDb.AddOrganiser(_db, "thandeka@raceday.co.za");
        var controller = CreateController(organiser.OrganiserID, Roles.Organiser);

        // Act
        var result = await controller.GetProfile();

        // Assert
        var ok = Assert.IsType<OkObjectResult>(result.Result);
        var body = Assert.IsType<ProfileResponse>(ok.Value);
        Assert.Equal("Organiser", body.Role);
        Assert.Equal("thandeka@raceday.co.za", body.Email);
    }

    [Fact]
    public async Task GetProfile_Participant_ReturnsOwnProfile()
    {
        // Arrange
        var participant = TestDb.AddParticipant(_db, "lindiwe@example.com");
        var controller = CreateController(participant.ParticipantID, Roles.Participant);

        // Act
        var result = await controller.GetProfile();

        // Assert
        var ok = Assert.IsType<OkObjectResult>(result.Result);
        var body = Assert.IsType<ProfileResponse>(ok.Value);
        Assert.Equal("Participant", body.Role);
        Assert.Equal("lindiwe@example.com", body.Email);
    }

    [Fact]
    public async Task GetProfile_AccountNoLongerExists_ReturnsNotFound()
    {
        // Arrange
        var controller = CreateController(999, Roles.Participant);

        // Act
        var result = await controller.GetProfile();

        // Assert
        Assert.IsType<NotFoundObjectResult>(result.Result);
    }

    [Fact]
    public async Task UpdateProfile_ValidChanges_ReturnsOkAndSavesThem()
    {
        // Arrange
        var participant = TestDb.AddParticipant(_db);
        var controller = CreateController(participant.ParticipantID, Roles.Participant);
        var dto = new UpdateProfileDto { FullName = "New Name", Email = "new@example.com", ContactNumber = "0831112222" };

        // Act
        var result = await controller.UpdateProfile(dto);

        // Assert
        Assert.IsType<OkObjectResult>(result.Result);
        var saved = Assert.Single(_db.Participants);
        Assert.Equal("New Name", saved.FullName);
        Assert.Equal("new@example.com", saved.Email);
    }

    [Fact]
    public async Task UpdateProfile_OrganiserChangesDetails_UpdatesOrganiserRecord()
    {
        // Arrange
        var organiser = TestDb.AddOrganiser(_db);
        var controller = CreateController(organiser.OrganiserID, Roles.Organiser);
        var dto = new UpdateProfileDto { FullName = "Renamed Organiser", Email = "renamed@raceday.co.za" };

        // Act
        var result = await controller.UpdateProfile(dto);

        // Assert
        Assert.IsType<OkObjectResult>(result.Result);
        Assert.Equal("Renamed Organiser", _db.Organisers.Single().FullName);
    }

    [Fact]
    public async Task UpdateProfile_KeepingOwnEmail_ReturnsOk()
    {
        // Arrange
        var participant = TestDb.AddParticipant(_db, "same@example.com");
        var controller = CreateController(participant.ParticipantID, Roles.Participant);
        var dto = new UpdateProfileDto { FullName = "Changed Name", Email = "same@example.com" };

        // Act
        var result = await controller.UpdateProfile(dto);

        // Assert
        Assert.IsType<OkObjectResult>(result.Result);
    }

    [Fact]
    public async Task UpdateProfile_EmailBelongsToAnotherUser_ReturnsConflict()
    {
        // Arrange
        TestDb.AddOrganiser(_db, "taken@example.com");
        var participant = TestDb.AddParticipant(_db);
        var controller = CreateController(participant.ParticipantID, Roles.Participant);
        var dto = new UpdateProfileDto { FullName = "Someone", Email = "taken@example.com" };

        // Act
        var result = await controller.UpdateProfile(dto);

        // Assert
        Assert.IsType<ConflictObjectResult>(result.Result);
    }

    [Fact]
    public async Task UpdateProfile_AccountNoLongerExists_ReturnsNotFound()
    {
        // Arrange
        var controller = CreateController(999, Roles.Participant);
        var dto = new UpdateProfileDto { FullName = "Ghost", Email = "ghost@example.com" };

        // Act
        var result = await controller.UpdateProfile(dto);

        // Assert
        Assert.IsType<NotFoundObjectResult>(result.Result);
    }
}
