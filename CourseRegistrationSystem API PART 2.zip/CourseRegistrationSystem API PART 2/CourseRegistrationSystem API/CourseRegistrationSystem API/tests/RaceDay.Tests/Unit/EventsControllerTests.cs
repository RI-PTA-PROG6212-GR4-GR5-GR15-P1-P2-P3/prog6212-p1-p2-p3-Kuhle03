using Microsoft.AspNetCore.Mvc;
using RaceDay.Api.Controllers;
using RaceDay.Api.Data;
using RaceDay.Api.Helpers;
using RaceDay.Api.Models.DTOs;

namespace RaceDay.Tests;

public class EventsControllerTests
{
    private readonly AppDbContext _db = TestDb.Create();

    private EventsController CreateController(int? userId = null, string? role = null) =>
        ControllerTestHelper.WithSession(new EventsController(_db), userId, role);

    private static EventDto ValidEventDto(string name = "New Race", int daysAhead = 30, string eventType = "run") => new()
    {
        Name = name,
        Description = "A test event.",
        EventDate = DateTime.UtcNow.Date.AddDays(daysAhead),
        Location = "Soweto",
        Distance = 21.1m,
        EventType = eventType,
        RouteInfo = "Flat loop."
    };

    // ---------- Create ----------

    [Fact]
    public async Task CreateEvent_ValidOrganiser_ReturnsCreatedAndSavesEvent()
    {
        // Arrange
        var organiser = TestDb.AddOrganiser(_db);
        var controller = CreateController(organiser.OrganiserID, Roles.Organiser);

        // Act
        var result = await controller.CreateEvent(ValidEventDto());

        // Assert
        var created = Assert.IsType<CreatedAtActionResult>(result.Result);
        var body = Assert.IsType<EventResponse>(created.Value);
        Assert.Equal(organiser.OrganiserID, body.OrganiserID);
        Assert.Equal("New Race", body.Name);
        Assert.Single(_db.Events);
    }

    [Fact]
    public async Task CreateEvent_EventTypeInLowerCase_IsSavedWithCapitalLetter()
    {
        // Arrange
        var organiser = TestDb.AddOrganiser(_db);
        var controller = CreateController(organiser.OrganiserID, Roles.Organiser);

        // Act
        var result = await controller.CreateEvent(ValidEventDto(eventType: "cycle"));

        // Assert
        var created = Assert.IsType<CreatedAtActionResult>(result.Result);
        var body = Assert.IsType<EventResponse>(created.Value);
        Assert.Equal("Cycle", body.EventType);
    }

    [Fact]
    public async Task CreateEvent_DateInThePast_ReturnsBadRequest()
    {
        // Arrange
        var organiser = TestDb.AddOrganiser(_db);
        var controller = CreateController(organiser.OrganiserID, Roles.Organiser);

        // Act
        var result = await controller.CreateEvent(ValidEventDto(daysAhead: -3));

        // Assert
        Assert.IsType<BadRequestObjectResult>(result.Result);
        Assert.Empty(_db.Events);
    }

    // ---------- Read ----------

    [Fact]
    public async Task GetEvents_Default_ReturnsOnlyUpcomingEvents()
    {
        // Arrange
        var organiser = TestDb.AddOrganiser(_db);
        TestDb.AddEvent(_db, organiser, daysAhead: 10);
        TestDb.AddEvent(_db, organiser, daysAhead: -10);
        var controller = CreateController();

        // Act
        var result = await controller.GetEvents();

        // Assert
        var ok = Assert.IsType<OkObjectResult>(result.Result);
        var events = Assert.IsAssignableFrom<IEnumerable<EventResponse>>(ok.Value);
        Assert.Single(events);
    }

    [Fact]
    public async Task GetEvents_IncludePast_ReturnsAllEvents()
    {
        // Arrange
        var organiser = TestDb.AddOrganiser(_db);
        TestDb.AddEvent(_db, organiser, daysAhead: 10);
        TestDb.AddEvent(_db, organiser, daysAhead: -10);
        var controller = CreateController();

        // Act
        var result = await controller.GetEvents(includePast: true);

        // Assert
        var ok = Assert.IsType<OkObjectResult>(result.Result);
        var events = Assert.IsAssignableFrom<IEnumerable<EventResponse>>(ok.Value);
        Assert.Equal(2, events.Count());
    }

    [Fact]
    public async Task GetEvents_VisitorNotLoggedIn_ReturnsOk()
    {
        // Arrange
        var controller = CreateController();

        // Act
        var result = await controller.GetEvents();

        // Assert
        Assert.IsType<OkObjectResult>(result.Result);
    }

    [Fact]
    public async Task GetEvent_ExistingId_ReturnsOkWithEvent()
    {
        // Arrange
        var organiser = TestDb.AddOrganiser(_db);
        var ev = TestDb.AddEvent(_db, organiser);
        var controller = CreateController();

        // Act
        var result = await controller.GetEvent(ev.EventID);

        // Assert
        var ok = Assert.IsType<OkObjectResult>(result.Result);
        var body = Assert.IsType<EventResponse>(ok.Value);
        Assert.Equal(ev.EventID, body.EventID);
    }

    [Fact]
    public async Task GetEvent_UnknownId_ReturnsNotFound()
    {
        // Arrange
        var controller = CreateController();

        // Act
        var result = await controller.GetEvent(999);

        // Assert
        Assert.IsType<NotFoundObjectResult>(result.Result);
    }

    // ---------- Update ----------

    [Fact]
    public async Task UpdateEvent_OwnEvent_ReturnsOkWithNewValues()
    {
        // Arrange
        var organiser = TestDb.AddOrganiser(_db);
        var ev = TestDb.AddEvent(_db, organiser);
        var controller = CreateController(organiser.OrganiserID, Roles.Organiser);

        // Act
        var result = await controller.UpdateEvent(ev.EventID, ValidEventDto(name: "Renamed Race", eventType: "walk"));

        // Assert
        var ok = Assert.IsType<OkObjectResult>(result.Result);
        var body = Assert.IsType<EventResponse>(ok.Value);
        Assert.Equal("Renamed Race", body.Name);
        Assert.Equal("Walk", body.EventType);
        Assert.Equal("Renamed Race", _db.Events.Single().Name);
    }

    [Fact]
    public async Task UpdateEvent_AnotherOrganisersEvent_ReturnsForbidden()
    {
        // Arrange
        var owner = TestDb.AddOrganiser(_db);
        var otherOrganiser = TestDb.AddOrganiser(_db);
        var ev = TestDb.AddEvent(_db, owner);
        var controller = CreateController(otherOrganiser.OrganiserID, Roles.Organiser);

        // Act
        var result = await controller.UpdateEvent(ev.EventID, ValidEventDto(name: "Stolen"));

        // Assert
        AssertEx.Forbidden(result.Result);
        Assert.Equal("Test Race", _db.Events.Single().Name);
    }

    [Fact]
    public async Task UpdateEvent_UnknownId_ReturnsNotFound()
    {
        // Arrange
        var organiser = TestDb.AddOrganiser(_db);
        var controller = CreateController(organiser.OrganiserID, Roles.Organiser);

        // Act
        var result = await controller.UpdateEvent(999, ValidEventDto());

        // Assert
        Assert.IsType<NotFoundObjectResult>(result.Result);
    }

    // ---------- Delete ----------

    [Fact]
    public async Task DeleteEvent_OwnEventWithoutEnrolments_ReturnsOkAndRemovesEventAndCategories()
    {
        // Arrange
        var organiser = TestDb.AddOrganiser(_db);
        var ev = TestDb.AddEvent(_db, organiser);
        TestDb.AddCategory(_db, ev);
        var controller = CreateController(organiser.OrganiserID, Roles.Organiser);

        // Act
        var result = await controller.DeleteEvent(ev.EventID);

        // Assert
        Assert.IsType<OkObjectResult>(result);
        Assert.Empty(_db.Events);
        Assert.Empty(_db.Categories);
    }

    [Fact]
    public async Task DeleteEvent_EventHasEnrolments_ReturnsConflictAndKeepsEvent()
    {
        // Arrange
        var organiser = TestDb.AddOrganiser(_db);
        var participant = TestDb.AddParticipant(_db);
        var ev = TestDb.AddEvent(_db, organiser);
        var category = TestDb.AddCategory(_db, ev);
        TestDb.AddEnrolment(_db, participant, category);
        var controller = CreateController(organiser.OrganiserID, Roles.Organiser);

        // Act
        var result = await controller.DeleteEvent(ev.EventID);

        // Assert
        Assert.IsType<ConflictObjectResult>(result);
        Assert.Single(_db.Events);
    }

    [Fact]
    public async Task DeleteEvent_AnotherOrganisersEvent_ReturnsForbidden()
    {
        // Arrange
        var owner = TestDb.AddOrganiser(_db);
        var otherOrganiser = TestDb.AddOrganiser(_db);
        var ev = TestDb.AddEvent(_db, owner);
        var controller = CreateController(otherOrganiser.OrganiserID, Roles.Organiser);

        // Act
        var result = await controller.DeleteEvent(ev.EventID);

        // Assert
        AssertEx.Forbidden(result);
        Assert.Single(_db.Events);
    }

    [Fact]
    public async Task DeleteEvent_UnknownId_ReturnsNotFound()
    {
        // Arrange
        var organiser = TestDb.AddOrganiser(_db);
        var controller = CreateController(organiser.OrganiserID, Roles.Organiser);

        // Act
        var result = await controller.DeleteEvent(999);

        // Assert
        Assert.IsType<NotFoundObjectResult>(result);
    }
}
