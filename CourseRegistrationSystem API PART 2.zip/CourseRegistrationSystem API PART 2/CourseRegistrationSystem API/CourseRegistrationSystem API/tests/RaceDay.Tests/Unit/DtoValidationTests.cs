using System.ComponentModel.DataAnnotations;
using RaceDay.Api.Models.DTOs;

namespace RaceDay.Tests;

/// <summary>
/// Checks the validation rules on the request objects (DTOs). With [ApiController], ASP.NET Core runs
/// these rules before the action and returns 400 automatically, so we test the rules themselves.
/// </summary>
public class DtoValidationTests
{
    private static List<ValidationResult> Validate(object model)
    {
        var results = new List<ValidationResult>();
        Validator.TryValidateObject(model, new ValidationContext(model), results, validateAllProperties: true);
        return results;
    }

    private static RegisterDto ValidRegister() => new()
    {
        FullName = "Test User", Email = "test@example.com", Password = "Password123!", Role = "Participant"
    };

    private static EventDto ValidEvent() => new()
    {
        Name = "Soweto 10km", Description = "A test event.", EventDate = DateTime.Today.AddDays(30),
        Location = "Soweto", Distance = 10m, EventType = "Run"
    };

    // ---------- Register ----------

    [Fact]
    public void Register_ValidDto_PassesValidation() => Assert.Empty(Validate(ValidRegister()));

    [Fact]
    public void Register_MissingEmail_FailsValidation()
    {
        // Arrange
        var dto = ValidRegister();
        dto.Email = "";

        // Act
        var errors = Validate(dto);

        // Assert
        Assert.NotEmpty(errors);
    }

    [Fact]
    public void Register_InvalidEmailFormat_FailsValidation()
    {
        // Arrange
        var dto = ValidRegister();
        dto.Email = "not-an-email";

        // Act
        var errors = Validate(dto);

        // Assert
        Assert.NotEmpty(errors);
    }

    [Fact]
    public void Register_MissingPassword_FailsValidation()
    {
        // Arrange
        var dto = ValidRegister();
        dto.Password = "";

        // Act
        var errors = Validate(dto);

        // Assert
        Assert.NotEmpty(errors);
    }

    [Fact]
    public void Register_PasswordShorterThanEightCharacters_FailsValidation()
    {
        // Arrange
        var dto = ValidRegister();
        dto.Password = "Abc123!";

        // Act
        var errors = Validate(dto);

        // Assert
        Assert.NotEmpty(errors);
    }

    [Fact]
    public void Register_MissingFullName_FailsValidation()
    {
        // Arrange
        var dto = ValidRegister();
        dto.FullName = "";

        // Act
        var errors = Validate(dto);

        // Assert
        Assert.NotEmpty(errors);
    }

    [Fact]
    public void Register_MissingRole_FailsValidation()
    {
        // Arrange
        var dto = ValidRegister();
        dto.Role = "";

        // Act
        var errors = Validate(dto);

        // Assert
        Assert.NotEmpty(errors);
    }

    // ---------- Login ----------

    [Fact]
    public void Login_ValidDto_PassesValidation() =>
        Assert.Empty(Validate(new LoginDto { Email = "test@example.com", Password = "Password123!" }));

    [Fact]
    public void Login_MissingPassword_FailsValidation() =>
        Assert.NotEmpty(Validate(new LoginDto { Email = "test@example.com", Password = "" }));

    [Fact]
    public void Login_MissingEmail_FailsValidation() =>
        Assert.NotEmpty(Validate(new LoginDto { Email = "", Password = "Password123!" }));

    // ---------- Events ----------

    [Fact]
    public void Event_ValidDto_PassesValidation() => Assert.Empty(Validate(ValidEvent()));

    [Theory]
    [InlineData("Run")]
    [InlineData("walk")]
    [InlineData("CYCLE")]
    public void Event_AcceptedEventTypes_PassValidation(string eventType)
    {
        // Arrange
        var dto = ValidEvent();
        dto.EventType = eventType;

        // Act
        var errors = Validate(dto);

        // Assert
        Assert.Empty(errors);
    }

    [Theory]
    [InlineData("Swim")]
    [InlineData("Marathon")]
    [InlineData("")]
    public void Event_UnknownEventType_FailsValidation(string eventType)
    {
        // Arrange
        var dto = ValidEvent();
        dto.EventType = eventType;

        // Act
        var errors = Validate(dto);

        // Assert
        Assert.NotEmpty(errors);
    }

    [Fact]
    public void Event_ZeroDistance_FailsValidation()
    {
        // Arrange
        var dto = ValidEvent();
        dto.Distance = 0m;

        // Act
        var errors = Validate(dto);

        // Assert
        Assert.NotEmpty(errors);
    }

    [Fact]
    public void Event_MissingName_FailsValidation()
    {
        // Arrange
        var dto = ValidEvent();
        dto.Name = "";

        // Act
        var errors = Validate(dto);

        // Assert
        Assert.NotEmpty(errors);
    }

    [Fact]
    public void Event_MissingLocation_FailsValidation()
    {
        // Arrange
        var dto = ValidEvent();
        dto.Location = "";

        // Act
        var errors = Validate(dto);

        // Assert
        Assert.NotEmpty(errors);
    }

    [Fact]
    public void Event_MissingDate_FailsValidation()
    {
        // Arrange
        var dto = ValidEvent();
        dto.EventDate = default;

        // Act
        var errors = Validate(dto);

        // Assert
        Assert.NotEmpty(errors);
    }

    // ---------- Categories, enrolments, results ----------

    [Fact]
    public void Category_AgeCategoryWithoutDistance_PassesValidation() =>
        Assert.Empty(Validate(new CategoryDto { Name = "Under 20", Distance = null, MaxParticipants = 50 }));

    [Fact]
    public void Category_MissingName_FailsValidation() =>
        Assert.NotEmpty(Validate(new CategoryDto { Name = "", MaxParticipants = 50 }));

    [Fact]
    public void Category_ZeroMaxParticipants_FailsValidation() =>
        Assert.NotEmpty(Validate(new CategoryDto { Name = "10km", MaxParticipants = 0 }));

    [Fact]
    public void Enrol_ValidCategoryId_PassesValidation() =>
        Assert.Empty(Validate(new EnrolDto { CategoryId = 3 }));

    [Fact]
    public void Enrol_ZeroCategoryId_FailsValidation() =>
        Assert.NotEmpty(Validate(new EnrolDto { CategoryId = 0 }));

    [Fact]
    public void Result_PositionZero_FailsValidation() =>
        Assert.NotEmpty(Validate(new CreateResultDto { EnrolmentId = 1, FinishTime = new TimeSpan(0, 30, 0), Position = 0 }));

    [Fact]
    public void Result_ValidDto_PassesValidation() =>
        Assert.Empty(Validate(new CreateResultDto { EnrolmentId = 1, FinishTime = new TimeSpan(0, 30, 0), Position = 1 }));
}
