using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Abstractions;
using Microsoft.AspNetCore.Mvc.Filters;
using Microsoft.AspNetCore.Routing;
using RaceDay.Api.Helpers;

namespace RaceDay.Tests;

/// <summary>
/// Unit tests for the filter that protects endpoints. This is where "not logged in = 401"
/// and "wrong role = 403" are decided, so it is tested directly.
/// </summary>
public class SessionAuthorizeAttributeTests
{
    private static AuthorizationFilterContext BuildContext(int? userId = null, string? role = null)
    {
        var httpContext = new DefaultHttpContext { Session = new FakeSession() };
        if (userId.HasValue) httpContext.Session.SetInt32(SessionKeys.UserId, userId.Value);
        if (role != null) httpContext.Session.SetString(SessionKeys.Role, role);

        var actionContext = new ActionContext(httpContext, new RouteData(), new ActionDescriptor());
        return new AuthorizationFilterContext(actionContext, new List<IFilterMetadata>());
    }

    [Fact]
    public void OnAuthorization_NotLoggedIn_ReturnsUnauthorized()
    {
        // Arrange
        var filter = new SessionAuthorizeAttribute(Roles.Organiser);
        var context = BuildContext();

        // Act
        filter.OnAuthorization(context);

        // Assert
        Assert.IsType<UnauthorizedObjectResult>(context.Result);
    }

    [Fact]
    public void OnAuthorization_NotLoggedInAndNoRoleRequired_ReturnsUnauthorized()
    {
        // Arrange
        var filter = new SessionAuthorizeAttribute();
        var context = BuildContext();

        // Act
        filter.OnAuthorization(context);

        // Assert
        Assert.IsType<UnauthorizedObjectResult>(context.Result);
    }

    [Fact]
    public void OnAuthorization_UserIdWithoutRole_ReturnsUnauthorized()
    {
        // Arrange
        var filter = new SessionAuthorizeAttribute();
        var context = BuildContext(userId: 5);

        // Act
        filter.OnAuthorization(context);

        // Assert
        Assert.IsType<UnauthorizedObjectResult>(context.Result);
    }

    [Fact]
    public void OnAuthorization_ParticipantOnOrganiserEndpoint_ReturnsForbidden()
    {
        // Arrange
        var filter = new SessionAuthorizeAttribute(Roles.Organiser);
        var context = BuildContext(userId: 1, role: Roles.Participant);

        // Act
        filter.OnAuthorization(context);

        // Assert
        AssertEx.Forbidden(context.Result);
    }

    [Fact]
    public void OnAuthorization_OrganiserOnParticipantEndpoint_ReturnsForbidden()
    {
        // Arrange
        var filter = new SessionAuthorizeAttribute(Roles.Participant);
        var context = BuildContext(userId: 1, role: Roles.Organiser);

        // Act
        filter.OnAuthorization(context);

        // Assert
        AssertEx.Forbidden(context.Result);
    }

    [Fact]
    public void OnAuthorization_OrganiserOnOrganiserEndpoint_AllowsRequest()
    {
        // Arrange
        var filter = new SessionAuthorizeAttribute(Roles.Organiser);
        var context = BuildContext(userId: 1, role: Roles.Organiser);

        // Act
        filter.OnAuthorization(context);

        // Assert
        Assert.Null(context.Result);
    }

    [Fact]
    public void OnAuthorization_ParticipantOnParticipantEndpoint_AllowsRequest()
    {
        // Arrange
        var filter = new SessionAuthorizeAttribute(Roles.Participant);
        var context = BuildContext(userId: 1, role: Roles.Participant);

        // Act
        filter.OnAuthorization(context);

        // Assert
        Assert.Null(context.Result);
    }

    [Theory]
    [InlineData(Roles.Organiser)]
    [InlineData(Roles.Participant)]
    public void OnAuthorization_AnyLoggedInUserOnOpenToAllEndpoint_AllowsRequest(string role)
    {
        // Arrange
        var filter = new SessionAuthorizeAttribute();
        var context = BuildContext(userId: 1, role: role);

        // Act
        filter.OnAuthorization(context);

        // Assert
        Assert.Null(context.Result);
    }

    [Theory]
    [InlineData(Roles.Organiser)]
    [InlineData(Roles.Participant)]
    public void OnAuthorization_RoleListedAmongSeveral_AllowsRequest(string role)
    {
        // Arrange
        var filter = new SessionAuthorizeAttribute(Roles.Participant, Roles.Organiser);
        var context = BuildContext(userId: 1, role: role);

        // Act
        filter.OnAuthorization(context);

        // Assert
        Assert.Null(context.Result);
    }
}
