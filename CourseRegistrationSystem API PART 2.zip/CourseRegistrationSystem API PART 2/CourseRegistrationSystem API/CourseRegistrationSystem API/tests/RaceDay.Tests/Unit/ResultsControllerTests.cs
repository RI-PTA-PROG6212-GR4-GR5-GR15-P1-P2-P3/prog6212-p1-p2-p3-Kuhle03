using Microsoft.AspNetCore.Mvc;
using RaceDay.Api.Controllers;
using RaceDay.Api.Data;
using RaceDay.Api.Helpers;
using RaceDay.Api.Models.DTOs;

namespace RaceDay.Tests;

public class ResultsControllerTests
{
    private readonly AppDbContext _db = TestDb.Create();

    private ResultsController CreateController(int? userId = null, string? role = null) =>
        ControllerTestHelper.WithSession(new ResultsController(_db), userId, role);

    private static CreateResultDto ValidResultDto(int enrolmentId, int position = 1) =>
        new() { EnrolmentId = enrolmentId, FinishTime = new TimeSpan(0, 45, 10), Position = position };

    // ---------- Capture ----------

    [Fact]
    public async Task CreateResult_OwnEvent_ReturnsCreatedAndSavesFinishTimeAndPosition()
    {
        // Arrange
        var organiser = TestDb.AddOrganiser(_db);
        var participant = TestDb.AddParticipant(_db);
        var category = TestDb.AddCategory(_db, TestDb.AddEvent(_db, organiser));
        var enrolment = TestDb.AddEnrolment(_db, participant, category);
        var controller = CreateController(organiser.OrganiserID, Roles.Organiser);

        // Act
        var result = await controller.CreateResult(ValidResultDto(enrolment.EnrolmentID, position: 2));

        // Assert
        var body = AssertEx.Created<ResultResponse>(result.Result);
        Assert.Equal(2, body.Position);
        Assert.Equal(new TimeSpan(0, 45, 10), body.FinishTime);
        var saved = Assert.Single(_db.Results);
        Assert.Equal(enrolment.EnrolmentID, saved.EnrolmentID);
    }

    [Fact]
    public async Task CreateResult_FinishTimeOfZero_ReturnsBadRequest()
    {
        // Arrange
        var organiser = TestDb.AddOrganiser(_db);
        var participant = TestDb.AddParticipant(_db);
        var category = TestDb.AddCategory(_db, TestDb.AddEvent(_db, organiser));
        var enrolment = TestDb.AddEnrolment(_db, participant, category);
        var controller = CreateController(organiser.OrganiserID, Roles.Organiser);
        var dto = new CreateResultDto { EnrolmentId = enrolment.EnrolmentID, FinishTime = TimeSpan.Zero, Position = 1 };

        // Act
        var result = await controller.CreateResult(dto);

        // Assert
        Assert.IsType<BadRequestObjectResult>(result.Result);
        Assert.Empty(_db.Results);
    }

    [Fact]
    public async Task CreateResult_UnknownEnrolment_ReturnsNotFound()
    {
        // Arrange
        var organiser = TestDb.AddOrganiser(_db);
        var controller = CreateController(organiser.OrganiserID, Roles.Organiser);

        // Act
        var result = await controller.CreateResult(ValidResultDto(enrolmentId: 999));

        // Assert
        Assert.IsType<NotFoundObjectResult>(result.Result);
    }

    [Fact]
    public async Task CreateResult_AnotherOrganisersEvent_ReturnsForbidden()
    {
        // Arrange
        var owner = TestDb.AddOrganiser(_db);
        var otherOrganiser = TestDb.AddOrganiser(_db);
        var participant = TestDb.AddParticipant(_db);
        var category = TestDb.AddCategory(_db, TestDb.AddEvent(_db, owner));
        var enrolment = TestDb.AddEnrolment(_db, participant, category);
        var controller = CreateController(otherOrganiser.OrganiserID, Roles.Organiser);

        // Act
        var result = await controller.CreateResult(ValidResultDto(enrolment.EnrolmentID));

        // Assert
        AssertEx.Forbidden(result.Result);
        Assert.Empty(_db.Results);
    }

    [Fact]
    public async Task CreateResult_EnrolmentAlreadyHasResult_ReturnsConflict()
    {
        // Arrange
        var organiser = TestDb.AddOrganiser(_db);
        var participant = TestDb.AddParticipant(_db);
        var category = TestDb.AddCategory(_db, TestDb.AddEvent(_db, organiser));
        var enrolment = TestDb.AddEnrolment(_db, participant, category);
        TestDb.AddResult(_db, enrolment, position: 1);
        var controller = CreateController(organiser.OrganiserID, Roles.Organiser);

        // Act
        var result = await controller.CreateResult(ValidResultDto(enrolment.EnrolmentID, position: 2));

        // Assert
        Assert.IsType<ConflictObjectResult>(result.Result);
        Assert.Single(_db.Results);
    }

    [Fact]
    public async Task CreateResult_PositionAlreadyTakenInCategory_ReturnsConflict()
    {
        // Arrange
        var organiser = TestDb.AddOrganiser(_db);
        var first = TestDb.AddParticipant(_db);
        var second = TestDb.AddParticipant(_db);
        var category = TestDb.AddCategory(_db, TestDb.AddEvent(_db, organiser));
        var firstEnrolment = TestDb.AddEnrolment(_db, first, category);
        var secondEnrolment = TestDb.AddEnrolment(_db, second, category);
        TestDb.AddResult(_db, firstEnrolment, position: 1);
        var controller = CreateController(organiser.OrganiserID, Roles.Organiser);

        // Act
        var result = await controller.CreateResult(ValidResultDto(secondEnrolment.EnrolmentID, position: 1));

        // Assert
        Assert.IsType<ConflictObjectResult>(result.Result);
    }

    [Fact]
    public async Task CreateResult_SamePositionInDifferentCategory_ReturnsCreated()
    {
        // Arrange
        var organiser = TestDb.AddOrganiser(_db);
        var first = TestDb.AddParticipant(_db);
        var second = TestDb.AddParticipant(_db);
        var ev = TestDb.AddEvent(_db, organiser);
        var tenKm = TestDb.AddCategory(_db, ev, name: "10km");
        var fiveKm = TestDb.AddCategory(_db, ev, name: "5km");
        var firstEnrolment = TestDb.AddEnrolment(_db, first, tenKm);
        var secondEnrolment = TestDb.AddEnrolment(_db, second, fiveKm);
        TestDb.AddResult(_db, firstEnrolment, position: 1);
        var controller = CreateController(organiser.OrganiserID, Roles.Organiser);

        // Act
        var result = await controller.CreateResult(ValidResultDto(secondEnrolment.EnrolmentID, position: 1));

        // Assert
        AssertEx.Created<ResultResponse>(result.Result);
    }

    // ---------- Update ----------

    [Fact]
    public async Task UpdateResult_OwnEvent_ReturnsOkWithNewValues()
    {
        // Arrange
        var organiser = TestDb.AddOrganiser(_db);
        var participant = TestDb.AddParticipant(_db);
        var category = TestDb.AddCategory(_db, TestDb.AddEvent(_db, organiser));
        var enrolment = TestDb.AddEnrolment(_db, participant, category);
        var saved = TestDb.AddResult(_db, enrolment, position: 2);
        var controller = CreateController(organiser.OrganiserID, Roles.Organiser);
        var dto = new UpdateResultDto { FinishTime = new TimeSpan(0, 29, 0), Position = 1 };

        // Act
        var result = await controller.UpdateResult(saved.ResultID, dto);

        // Assert
        var ok = Assert.IsType<OkObjectResult>(result.Result);
        var body = Assert.IsType<ResultResponse>(ok.Value);
        Assert.Equal(1, body.Position);
        Assert.Equal(new TimeSpan(0, 29, 0), body.FinishTime);
    }

    [Fact]
    public async Task UpdateResult_UnknownId_ReturnsNotFound()
    {
        // Arrange
        var organiser = TestDb.AddOrganiser(_db);
        var controller = CreateController(organiser.OrganiserID, Roles.Organiser);
        var dto = new UpdateResultDto { FinishTime = new TimeSpan(0, 29, 0), Position = 1 };

        // Act
        var result = await controller.UpdateResult(999, dto);

        // Assert
        Assert.IsType<NotFoundObjectResult>(result.Result);
    }

    [Fact]
    public async Task UpdateResult_AnotherOrganisersEvent_ReturnsForbidden()
    {
        // Arrange
        var owner = TestDb.AddOrganiser(_db);
        var otherOrganiser = TestDb.AddOrganiser(_db);
        var participant = TestDb.AddParticipant(_db);
        var category = TestDb.AddCategory(_db, TestDb.AddEvent(_db, owner));
        var enrolment = TestDb.AddEnrolment(_db, participant, category);
        var saved = TestDb.AddResult(_db, enrolment);
        var controller = CreateController(otherOrganiser.OrganiserID, Roles.Organiser);
        var dto = new UpdateResultDto { FinishTime = new TimeSpan(0, 29, 0), Position = 1 };

        // Act
        var result = await controller.UpdateResult(saved.ResultID, dto);

        // Assert
        AssertEx.Forbidden(result.Result);
    }

    // ---------- View ----------

    [Fact]
    public async Task GetEventResults_ReturnsResultsOrderedByPosition()
    {
        // Arrange
        var organiser = TestDb.AddOrganiser(_db);
        var first = TestDb.AddParticipant(_db);
        var second = TestDb.AddParticipant(_db);
        var ev = TestDb.AddEvent(_db, organiser);
        var category = TestDb.AddCategory(_db, ev);
        TestDb.AddResult(_db, TestDb.AddEnrolment(_db, first, category), position: 2);
        TestDb.AddResult(_db, TestDb.AddEnrolment(_db, second, category), position: 1);
        var controller = CreateController();

        // Act
        var result = await controller.GetEventResults(ev.EventID);

        // Assert
        var ok = Assert.IsType<OkObjectResult>(result.Result);
        var results = Assert.IsAssignableFrom<IEnumerable<ResultResponse>>(ok.Value).ToList();
        Assert.Equal(new[] { 1, 2 }, results.Select(r => r.Position).ToArray());
    }

    [Fact]
    public async Task GetEventResults_UnknownEvent_ReturnsNotFound()
    {
        // Arrange
        var controller = CreateController();

        // Act
        var result = await controller.GetEventResults(999);

        // Assert
        Assert.IsType<NotFoundObjectResult>(result.Result);
    }

    [Fact]
    public async Task GetParticipantResults_ParticipantViewsOwn_ReturnsOk()
    {
        // Arrange
        var organiser = TestDb.AddOrganiser(_db);
        var participant = TestDb.AddParticipant(_db);
        var category = TestDb.AddCategory(_db, TestDb.AddEvent(_db, organiser));
        TestDb.AddResult(_db, TestDb.AddEnrolment(_db, participant, category));
        var controller = CreateController(participant.ParticipantID, Roles.Participant);

        // Act
        var result = await controller.GetParticipantResults(participant.ParticipantID);

        // Assert
        var ok = Assert.IsType<OkObjectResult>(result.Result);
        var results = Assert.IsAssignableFrom<IEnumerable<ResultResponse>>(ok.Value);
        Assert.Single(results);
    }

    [Fact]
    public async Task GetParticipantResults_ParticipantViewsSomeoneElses_ReturnsForbidden()
    {
        // Arrange
        var me = TestDb.AddParticipant(_db);
        var someoneElse = TestDb.AddParticipant(_db);
        var controller = CreateController(me.ParticipantID, Roles.Participant);

        // Act
        var result = await controller.GetParticipantResults(someoneElse.ParticipantID);

        // Assert
        AssertEx.Forbidden(result.Result);
    }

    [Fact]
    public async Task GetParticipantResults_OrganiserViewsAnyParticipant_ReturnsOk()
    {
        // Arrange
        var organiser = TestDb.AddOrganiser(_db);
        var participant = TestDb.AddParticipant(_db);
        var controller = CreateController(organiser.OrganiserID, Roles.Organiser);

        // Act
        var result = await controller.GetParticipantResults(participant.ParticipantID);

        // Assert
        Assert.IsType<OkObjectResult>(result.Result);
    }

    [Fact]
    public async Task GetParticipantResults_UnknownParticipant_ReturnsNotFound()
    {
        // Arrange
        var organiser = TestDb.AddOrganiser(_db);
        var controller = CreateController(organiser.OrganiserID, Roles.Organiser);

        // Act
        var result = await controller.GetParticipantResults(999);

        // Assert
        Assert.IsType<NotFoundObjectResult>(result.Result);
    }
}
