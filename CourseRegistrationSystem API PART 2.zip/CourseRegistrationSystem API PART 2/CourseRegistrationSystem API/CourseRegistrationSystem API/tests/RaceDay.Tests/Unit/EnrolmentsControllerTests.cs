using Microsoft.AspNetCore.Mvc;
using RaceDay.Api.Controllers;
using RaceDay.Api.Data;
using RaceDay.Api.Helpers;
using RaceDay.Api.Models.DTOs;

namespace RaceDay.Tests;

public class EnrolmentsControllerTests
{
    private readonly AppDbContext _db = TestDb.Create();

    private EnrolmentsController CreateController(int? userId = null, string? role = null) =>
        ControllerTestHelper.WithSession(new EnrolmentsController(_db), userId, role);

    // ---------- Enrol ----------

    [Fact]
    public async Task Enrol_ValidParticipant_ReturnsCreatedAndRecordsParticipantCategoryAndEvent()
    {
        // Arrange
        var organiser = TestDb.AddOrganiser(_db);
        var participant = TestDb.AddParticipant(_db);
        var ev = TestDb.AddEvent(_db, organiser);
        var category = TestDb.AddCategory(_db, ev);
        var controller = CreateController(participant.ParticipantID, Roles.Participant);

        // Act
        var result = await controller.Enrol(new EnrolDto { CategoryId = category.CategoryID });

        // Assert
        var body = AssertEx.Created<EnrolmentResponse>(result.Result);
        Assert.Equal(participant.ParticipantID, body.ParticipantID);
        Assert.Equal(category.CategoryID, body.CategoryID);
        Assert.Equal(ev.EventID, body.EventID);

        var saved = Assert.Single(_db.EventEnrolments);
        Assert.Equal(participant.ParticipantID, saved.ParticipantID);
        Assert.Equal(category.CategoryID, saved.CategoryID);
    }

    [Fact]
    public async Task Enrol_AlreadyEnrolledInCategory_ReturnsConflict()
    {
        // Arrange
        var organiser = TestDb.AddOrganiser(_db);
        var participant = TestDb.AddParticipant(_db);
        var category = TestDb.AddCategory(_db, TestDb.AddEvent(_db, organiser));
        TestDb.AddEnrolment(_db, participant, category);
        var controller = CreateController(participant.ParticipantID, Roles.Participant);

        // Act
        var result = await controller.Enrol(new EnrolDto { CategoryId = category.CategoryID });

        // Assert
        Assert.IsType<ConflictObjectResult>(result.Result);
        Assert.Single(_db.EventEnrolments);
    }

    [Fact]
    public async Task Enrol_CategoryIsFull_ReturnsConflict()
    {
        // Arrange
        var organiser = TestDb.AddOrganiser(_db);
        var firstParticipant = TestDb.AddParticipant(_db);
        var secondParticipant = TestDb.AddParticipant(_db);
        var category = TestDb.AddCategory(_db, TestDb.AddEvent(_db, organiser), maxParticipants: 1);
        TestDb.AddEnrolment(_db, firstParticipant, category);
        var controller = CreateController(secondParticipant.ParticipantID, Roles.Participant);

        // Act
        var result = await controller.Enrol(new EnrolDto { CategoryId = category.CategoryID });

        // Assert
        Assert.IsType<ConflictObjectResult>(result.Result);
        Assert.Single(_db.EventEnrolments);
    }

    [Fact]
    public async Task Enrol_UnknownCategory_ReturnsNotFound()
    {
        // Arrange
        var participant = TestDb.AddParticipant(_db);
        var controller = CreateController(participant.ParticipantID, Roles.Participant);

        // Act
        var result = await controller.Enrol(new EnrolDto { CategoryId = 999 });

        // Assert
        Assert.IsType<NotFoundObjectResult>(result.Result);
    }

    [Fact]
    public async Task Enrol_EventAlreadyTookPlace_ReturnsBadRequest()
    {
        // Arrange
        var organiser = TestDb.AddOrganiser(_db);
        var participant = TestDb.AddParticipant(_db);
        var category = TestDb.AddCategory(_db, TestDb.AddEvent(_db, organiser, daysAhead: -2));
        var controller = CreateController(participant.ParticipantID, Roles.Participant);

        // Act
        var result = await controller.Enrol(new EnrolDto { CategoryId = category.CategoryID });

        // Assert
        Assert.IsType<BadRequestObjectResult>(result.Result);
        Assert.Empty(_db.EventEnrolments);
    }

    [Fact]
    public async Task Enrol_SameParticipantInTwoDifferentCategories_BothAreRecorded()
    {
        // Arrange
        var organiser = TestDb.AddOrganiser(_db);
        var participant = TestDb.AddParticipant(_db);
        var ev = TestDb.AddEvent(_db, organiser);
        var tenKm = TestDb.AddCategory(_db, ev, name: "10km");
        var senior = TestDb.AddCategory(_db, ev, name: "Senior");
        var controller = CreateController(participant.ParticipantID, Roles.Participant);

        // Act
        await controller.Enrol(new EnrolDto { CategoryId = tenKm.CategoryID });
        var result = await controller.Enrol(new EnrolDto { CategoryId = senior.CategoryID });

        // Assert
        AssertEx.Created<EnrolmentResponse>(result.Result);
        Assert.Equal(2, _db.EventEnrolments.Count());
    }

    // ---------- View ----------

    [Fact]
    public async Task GetMyEnrolments_ReturnsOnlyTheLoggedInParticipantsEnrolments()
    {
        // Arrange
        var organiser = TestDb.AddOrganiser(_db);
        var me = TestDb.AddParticipant(_db);
        var someoneElse = TestDb.AddParticipant(_db);
        var category = TestDb.AddCategory(_db, TestDb.AddEvent(_db, organiser));
        var mine = TestDb.AddEnrolment(_db, me, category);
        TestDb.AddEnrolment(_db, someoneElse, category);
        var controller = CreateController(me.ParticipantID, Roles.Participant);

        // Act
        var result = await controller.GetMyEnrolments();

        // Assert
        var ok = Assert.IsType<OkObjectResult>(result.Result);
        var enrolments = Assert.IsAssignableFrom<IEnumerable<EnrolmentResponse>>(ok.Value).ToList();
        var single = Assert.Single(enrolments);
        Assert.Equal(mine.EnrolmentID, single.EnrolmentID);
    }

    [Fact]
    public async Task GetMyEnrolments_NoEnrolments_ReturnsEmptyList()
    {
        // Arrange
        var participant = TestDb.AddParticipant(_db);
        var controller = CreateController(participant.ParticipantID, Roles.Participant);

        // Act
        var result = await controller.GetMyEnrolments();

        // Assert
        var ok = Assert.IsType<OkObjectResult>(result.Result);
        Assert.Empty(Assert.IsAssignableFrom<IEnumerable<EnrolmentResponse>>(ok.Value));
    }

    [Fact]
    public async Task GetEventEnrolments_OwnEvent_ReturnsEnrolmentsWithParticipantNames()
    {
        // Arrange
        var organiser = TestDb.AddOrganiser(_db);
        var participant = TestDb.AddParticipant(_db);
        var ev = TestDb.AddEvent(_db, organiser);
        var category = TestDb.AddCategory(_db, ev);
        TestDb.AddEnrolment(_db, participant, category);
        var controller = CreateController(organiser.OrganiserID, Roles.Organiser);

        // Act
        var result = await controller.GetEventEnrolments(ev.EventID);

        // Assert
        var ok = Assert.IsType<OkObjectResult>(result.Result);
        var enrolments = Assert.IsAssignableFrom<IEnumerable<EnrolmentResponse>>(ok.Value).ToList();
        var single = Assert.Single(enrolments);
        Assert.Equal("Test Participant", single.ParticipantName);
    }

    [Fact]
    public async Task GetEventEnrolments_AnotherOrganisersEvent_ReturnsForbidden()
    {
        // Arrange
        var owner = TestDb.AddOrganiser(_db);
        var otherOrganiser = TestDb.AddOrganiser(_db);
        var ev = TestDb.AddEvent(_db, owner);
        var controller = CreateController(otherOrganiser.OrganiserID, Roles.Organiser);

        // Act
        var result = await controller.GetEventEnrolments(ev.EventID);

        // Assert
        AssertEx.Forbidden(result.Result);
    }

    [Fact]
    public async Task GetEventEnrolments_UnknownEvent_ReturnsNotFound()
    {
        // Arrange
        var organiser = TestDb.AddOrganiser(_db);
        var controller = CreateController(organiser.OrganiserID, Roles.Organiser);

        // Act
        var result = await controller.GetEventEnrolments(999);

        // Assert
        Assert.IsType<NotFoundObjectResult>(result.Result);
    }

    // ---------- Cancel ----------

    [Fact]
    public async Task CancelEnrolment_OwnEnrolment_ReturnsOkAndRemovesIt()
    {
        // Arrange
        var organiser = TestDb.AddOrganiser(_db);
        var participant = TestDb.AddParticipant(_db);
        var category = TestDb.AddCategory(_db, TestDb.AddEvent(_db, organiser));
        var enrolment = TestDb.AddEnrolment(_db, participant, category);
        var controller = CreateController(participant.ParticipantID, Roles.Participant);

        // Act
        var result = await controller.CancelEnrolment(enrolment.EnrolmentID);

        // Assert
        Assert.IsType<OkObjectResult>(result);
        Assert.Empty(_db.EventEnrolments);
    }

    [Fact]
    public async Task CancelEnrolment_SomeoneElsesEnrolment_ReturnsForbidden()
    {
        // Arrange
        var organiser = TestDb.AddOrganiser(_db);
        var owner = TestDb.AddParticipant(_db);
        var stranger = TestDb.AddParticipant(_db);
        var category = TestDb.AddCategory(_db, TestDb.AddEvent(_db, organiser));
        var enrolment = TestDb.AddEnrolment(_db, owner, category);
        var controller = CreateController(stranger.ParticipantID, Roles.Participant);

        // Act
        var result = await controller.CancelEnrolment(enrolment.EnrolmentID);

        // Assert
        AssertEx.Forbidden(result);
        Assert.Single(_db.EventEnrolments);
    }

    [Fact]
    public async Task CancelEnrolment_ResultAlreadyCaptured_ReturnsConflict()
    {
        // Arrange
        var organiser = TestDb.AddOrganiser(_db);
        var participant = TestDb.AddParticipant(_db);
        var category = TestDb.AddCategory(_db, TestDb.AddEvent(_db, organiser));
        var enrolment = TestDb.AddEnrolment(_db, participant, category);
        TestDb.AddResult(_db, enrolment);
        var controller = CreateController(participant.ParticipantID, Roles.Participant);

        // Act
        var result = await controller.CancelEnrolment(enrolment.EnrolmentID);

        // Assert
        Assert.IsType<ConflictObjectResult>(result);
        Assert.Single(_db.EventEnrolments);
    }

    [Fact]
    public async Task CancelEnrolment_UnknownId_ReturnsNotFound()
    {
        // Arrange
        var participant = TestDb.AddParticipant(_db);
        var controller = CreateController(participant.ParticipantID, Roles.Participant);

        // Act
        var result = await controller.CancelEnrolment(999);

        // Assert
        Assert.IsType<NotFoundObjectResult>(result);
    }
}
