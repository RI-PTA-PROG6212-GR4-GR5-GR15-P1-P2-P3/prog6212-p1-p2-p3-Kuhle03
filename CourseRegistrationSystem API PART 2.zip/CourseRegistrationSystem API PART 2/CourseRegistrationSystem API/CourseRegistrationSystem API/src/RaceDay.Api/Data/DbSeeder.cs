using RaceDay.Api.Models;
using RaceDay.Api.Services;

namespace RaceDay.Api.Data;

/// <summary>Adds demo data the first time the app runs against an empty SQL Server database.</summary>
public static class DbSeeder
{
    public const string DemoPassword = "Password123!";

    public static void Seed(AppDbContext db, IPasswordService passwords)
    {
        if (db.Organisers.Any() || db.Participants.Any()) return;

        var hash = passwords.Hash(DemoPassword);
        var today = DateTime.UtcNow.Date;

        var thandeka = new Organiser { FullName = "Thandeka Nkosi", Email = "thandeka@raceday.co.za", PasswordHash = hash, ContactNumber = "0821234567" };
        var johan = new Organiser { FullName = "Johan van der Merwe", Email = "johan@raceday.co.za", PasswordHash = hash, ContactNumber = "0837654321" };
        var lindiwe = new Participant { FullName = "Lindiwe Dube", Email = "lindiwe@example.com", PasswordHash = hash, ContactNumber = "0731112222" };
        var sipho = new Participant { FullName = "Sipho Mahlangu", Email = "sipho@example.com", PasswordHash = hash, ContactNumber = "0723334444" };

        var parkRun = new RaceEvent
        {
            Organiser = thandeka, Name = "Johannesburg City Park Run",
            Description = "A community park run through the Johannesburg botanical gardens.",
            EventDate = today.AddDays(-14), Location = "Johannesburg", Distance = 10m, EventType = "Run",
            RouteInfo = "Flat, tarred loop, 5km and 10km options."
        };
        var cycle = new RaceEvent
        {
            Organiser = thandeka, Name = "Soweto Heritage Cycle Challenge",
            Description = "A charity cycling event supporting local youth sports programmes.",
            EventDate = today.AddDays(30), Location = "Soweto", Distance = 80m, EventType = "Cycle",
            RouteInfo = "Rolling hills, mixed tar and gravel, water points every 15km."
        };
        var roadRace = new RaceEvent
        {
            Organiser = johan, Name = "Pretoria Winter Road Race",
            Description = "An annual road running event with categories for all experience levels.",
            EventDate = today.AddDays(60), Location = "Pretoria", Distance = 21.1m, EventType = "Run",
            RouteInfo = "Point-to-point road route, closed to traffic."
        };

        var run5k = new Category { Event = parkRun, Name = "5km Fun Run", Distance = 5m, MaxParticipants = 200 };
        var run10k = new Category { Event = parkRun, Name = "10km Race", Distance = 10m, MaxParticipants = 150 };
        var under20 = new Category { Event = parkRun, Name = "Under 20", Distance = null, MaxParticipants = 100 };
        var cycle40 = new Category { Event = cycle, Name = "40km Cycle", Distance = 40m, MaxParticipants = 100 };
        var cycle80 = new Category { Event = cycle, Name = "80km Cycle", Distance = 80m, MaxParticipants = 60 };
        var road10k = new Category { Event = roadRace, Name = "10km Race", Distance = 10m, MaxParticipants = 150 };
        var half = new Category { Event = roadRace, Name = "21km Half Marathon", Distance = 21.1m, MaxParticipants = 100 };

        var e1 = new EventEnrolment { Participant = lindiwe, Category = run5k };
        var e2 = new EventEnrolment { Participant = sipho, Category = run10k };
        var e3 = new EventEnrolment { Participant = lindiwe, Category = cycle40 };
        var e4 = new EventEnrolment { Participant = sipho, Category = road10k };

        db.AddRange(thandeka, johan, lindiwe, sipho);
        db.AddRange(parkRun, cycle, roadRace);
        db.AddRange(run5k, run10k, under20, cycle40, cycle80, road10k, half);
        db.AddRange(e1, e2, e3, e4);

        // Results exist only for the park run, which has already taken place.
        db.Results.Add(new RaceResult { Enrolment = e1, FinishTime = new TimeSpan(0, 24, 38), Position = 1 });
        db.Results.Add(new RaceResult { Enrolment = e2, FinishTime = new TimeSpan(0, 48, 12), Position = 1 });

        db.SaveChanges();
    }
}
