namespace RaceDay.Api.Helpers;

public static class SessionKeys
{
    public const string UserId = "UserId";
    public const string Role = "Role";
}

public static class Roles
{
    public const string Organiser = "Organiser";
    public const string Participant = "Participant";

    /// <summary>Returns the correctly spelled role name, or null if the text is not a valid role.</summary>
    public static string? Normalise(string? role)
    {
        if (string.Equals(role?.Trim(), Organiser, StringComparison.OrdinalIgnoreCase)) return Organiser;
        if (string.Equals(role?.Trim(), Participant, StringComparison.OrdinalIgnoreCase)) return Participant;
        return null;
    }
}

public static class EventTypes
{
    /// <summary>Turns "run", "RUN" or "Run" into "Run" (same for Walk and Cycle).</summary>
    public static string Normalise(string value)
    {
        var v = value.Trim().ToLowerInvariant();
        return char.ToUpperInvariant(v[0]) + v[1..];
    }
}
