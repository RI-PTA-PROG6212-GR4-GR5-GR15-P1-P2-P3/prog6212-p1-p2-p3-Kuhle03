using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Filters;
using RaceDay.Api.Models.DTOs;

namespace RaceDay.Api.Helpers;

/// <summary>
/// Protects an endpoint using the server-side session.
/// No session = 401 Unauthorized. Logged in with the wrong role = 403 Forbidden.
/// Use [SessionAuthorize] for "any logged-in user" or [SessionAuthorize(Roles.Organiser)] for a specific role.
/// </summary>
[AttributeUsage(AttributeTargets.Class | AttributeTargets.Method, AllowMultiple = false)]
public class SessionAuthorizeAttribute : Attribute, IAuthorizationFilter
{
    private readonly string[] _roles;

    public SessionAuthorizeAttribute(params string[] roles)
    {
        _roles = roles;
    }

    public void OnAuthorization(AuthorizationFilterContext context)
    {
        var session = context.HttpContext.Session;
        var userId = session.GetInt32(SessionKeys.UserId);
        var role = session.GetString(SessionKeys.Role);

        if (userId == null || role == null)
        {
            context.Result = new UnauthorizedObjectResult(new ErrorResponse("You must be logged in to do this."));
            return;
        }

        if (_roles.Length > 0 && !_roles.Contains(role))
        {
            context.Result = new ObjectResult(new ErrorResponse($"This action is not available to the {role} role."))
            {
                StatusCode = StatusCodes.Status403Forbidden
            };
        }
    }
}
