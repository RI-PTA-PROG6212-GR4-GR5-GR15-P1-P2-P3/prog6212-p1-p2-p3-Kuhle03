using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using RaceDay.Api.Data;
using RaceDay.Api.Models.DTOs;
using RaceDay.Api.Helpers;
using RaceDay.Api.Models;

namespace RaceDay.Api.Controllers;

[Route("api")]
public class CategoriesController : ApiControllerBase
{
    private readonly AppDbContext _db;

    public CategoriesController(AppDbContext db) => _db = db;

    /// <summary>List the categories of an event (for example Under 20, Senior, 10km, 21km). Open to everyone.</summary>
    /// <response code="200">Returns the categories, including how many people have enrolled in each.</response>
    /// <response code="404">No event has that ID.</response>
    [HttpGet("events/{eventId:int}/categories")]
    [ProducesResponseType(typeof(IEnumerable<CategoryResponse>), StatusCodes.Status200OK)]
    [ProducesResponseType(typeof(ErrorResponse), StatusCodes.Status404NotFound)]
    public async Task<ActionResult<IEnumerable<CategoryResponse>>> GetCategories(int eventId)
    {
        if (!await _db.Events.AnyAsync(e => e.EventID == eventId))
            return NotFound(new ErrorResponse("Event not found."));

        var categories = await _db.Categories
            .Where(c => c.EventID == eventId)
            .OrderBy(c => c.Name)
            .Select(c => new CategoryResponse
            {
                CategoryID = c.CategoryID,
                EventID = c.EventID,
                Name = c.Name,
                Distance = c.Distance,
                MaxParticipants = c.MaxParticipants,
                EnrolledCount = c.Enrolments.Count
            })
            .ToListAsync();

        return Ok(categories);
    }

    /// <summary>Get one category. Open to everyone.</summary>
    /// <response code="200">Returns the category.</response>
    /// <response code="404">No category has that ID.</response>
    [HttpGet("categories/{id:int}")]
    [ProducesResponseType(typeof(CategoryResponse), StatusCodes.Status200OK)]
    [ProducesResponseType(typeof(ErrorResponse), StatusCodes.Status404NotFound)]
    public async Task<ActionResult<CategoryResponse>> GetCategory(int id)
    {
        var category = await _db.Categories.FirstOrDefaultAsync(c => c.CategoryID == id);
        if (category == null) return NotFound(new ErrorResponse("Category not found."));

        var count = await _db.EventEnrolments.CountAsync(en => en.CategoryID == id);
        return Ok(Mapping.ToCategoryResponse(category, count));
    }

    /// <summary>Add a category to an event. Only the Organiser who owns the event can do this.</summary>
    /// <remarks>Expects: name, optional distance in km (leave empty for age categories) and maxParticipants (default 100).</remarks>
    /// <response code="201">Category created.</response>
    /// <response code="400">A field is missing or invalid.</response>
    /// <response code="401">Not logged in.</response>
    /// <response code="403">Logged in as a Participant, or the event belongs to another Organiser.</response>
    /// <response code="404">No event has that ID.</response>
    /// <response code="409">The event already has a category with that name.</response>
    [HttpPost("events/{eventId:int}/categories")]
    [SessionAuthorize(Roles.Organiser)]
    [ProducesResponseType(typeof(CategoryResponse), StatusCodes.Status201Created)]
    [ProducesResponseType(typeof(ErrorResponse), StatusCodes.Status400BadRequest)]
    [ProducesResponseType(typeof(ErrorResponse), StatusCodes.Status401Unauthorized)]
    [ProducesResponseType(typeof(ErrorResponse), StatusCodes.Status403Forbidden)]
    [ProducesResponseType(typeof(ErrorResponse), StatusCodes.Status404NotFound)]
    [ProducesResponseType(typeof(ErrorResponse), StatusCodes.Status409Conflict)]
    public async Task<ActionResult<CategoryResponse>> CreateCategory(int eventId, CategoryDto request)
    {
        var ev = await _db.Events.FirstOrDefaultAsync(e => e.EventID == eventId);
        if (ev == null) return NotFound(new ErrorResponse("Event not found."));
        if (ev.OrganiserID != CurrentUserId) return ForbiddenResult("You can only add categories to your own events.");

        var name = request.Name.Trim();
        if (await _db.Categories.AnyAsync(c => c.EventID == eventId && c.Name == name))
            return Conflict(new ErrorResponse("This event already has a category with that name."));

        var category = new Category
        {
            EventID = eventId,
            Name = name,
            Distance = request.Distance,
            MaxParticipants = request.MaxParticipants
        };
        _db.Categories.Add(category);
        await _db.SaveChangesAsync();

        return CreatedAtAction(nameof(GetCategory), new { id = category.CategoryID }, Mapping.ToCategoryResponse(category, 0));
    }

    /// <summary>Update a category. Only the Organiser who owns the event can do this.</summary>
    /// <response code="200">Category updated.</response>
    /// <response code="400">A field is missing or invalid, or the new limit is lower than the number already enrolled.</response>
    /// <response code="401">Not logged in.</response>
    /// <response code="403">Logged in as a Participant, or the event belongs to another Organiser.</response>
    /// <response code="404">No category has that ID.</response>
    /// <response code="409">The event already has another category with that name.</response>
    [HttpPut("categories/{id:int}")]
    [SessionAuthorize(Roles.Organiser)]
    [ProducesResponseType(typeof(CategoryResponse), StatusCodes.Status200OK)]
    [ProducesResponseType(typeof(ErrorResponse), StatusCodes.Status400BadRequest)]
    [ProducesResponseType(typeof(ErrorResponse), StatusCodes.Status401Unauthorized)]
    [ProducesResponseType(typeof(ErrorResponse), StatusCodes.Status403Forbidden)]
    [ProducesResponseType(typeof(ErrorResponse), StatusCodes.Status404NotFound)]
    [ProducesResponseType(typeof(ErrorResponse), StatusCodes.Status409Conflict)]
    public async Task<ActionResult<CategoryResponse>> UpdateCategory(int id, CategoryDto request)
    {
        var category = await _db.Categories.Include(c => c.Event).FirstOrDefaultAsync(c => c.CategoryID == id);
        if (category == null) return NotFound(new ErrorResponse("Category not found."));
        if (category.Event.OrganiserID != CurrentUserId) return ForbiddenResult("You can only change categories of your own events.");

        var name = request.Name.Trim();
        if (await _db.Categories.AnyAsync(c => c.EventID == category.EventID && c.Name == name && c.CategoryID != id))
            return Conflict(new ErrorResponse("This event already has a category with that name."));

        var enrolled = await _db.EventEnrolments.CountAsync(en => en.CategoryID == id);
        if (request.MaxParticipants < enrolled)
            return BadRequest(new ErrorResponse($"{enrolled} people have already enrolled, so the limit cannot be lower than that."));

        category.Name = name;
        category.Distance = request.Distance;
        category.MaxParticipants = request.MaxParticipants;
        await _db.SaveChangesAsync();

        return Ok(Mapping.ToCategoryResponse(category, enrolled));
    }

    /// <summary>Delete a category. Only the Organiser who owns the event can do this.</summary>
    /// <response code="200">Category deleted.</response>
    /// <response code="401">Not logged in.</response>
    /// <response code="403">Logged in as a Participant, or the event belongs to another Organiser.</response>
    /// <response code="404">No category has that ID.</response>
    /// <response code="409">Participants have already enrolled in this category.</response>
    [HttpDelete("categories/{id:int}")]
    [SessionAuthorize(Roles.Organiser)]
    [ProducesResponseType(typeof(ErrorResponse), StatusCodes.Status200OK)]
    [ProducesResponseType(typeof(ErrorResponse), StatusCodes.Status401Unauthorized)]
    [ProducesResponseType(typeof(ErrorResponse), StatusCodes.Status403Forbidden)]
    [ProducesResponseType(typeof(ErrorResponse), StatusCodes.Status404NotFound)]
    [ProducesResponseType(typeof(ErrorResponse), StatusCodes.Status409Conflict)]
    public async Task<IActionResult> DeleteCategory(int id)
    {
        var category = await _db.Categories.Include(c => c.Event).FirstOrDefaultAsync(c => c.CategoryID == id);
        if (category == null) return NotFound(new ErrorResponse("Category not found."));
        if (category.Event.OrganiserID != CurrentUserId) return ForbiddenResult("You can only delete categories of your own events.");

        if (await _db.EventEnrolments.AnyAsync(en => en.CategoryID == id))
            return Conflict(new ErrorResponse("People have already enrolled in this category, so it cannot be deleted."));

        _db.Categories.Remove(category);
        await _db.SaveChangesAsync();
        return Ok(new ErrorResponse("Category deleted."));
    }
}
