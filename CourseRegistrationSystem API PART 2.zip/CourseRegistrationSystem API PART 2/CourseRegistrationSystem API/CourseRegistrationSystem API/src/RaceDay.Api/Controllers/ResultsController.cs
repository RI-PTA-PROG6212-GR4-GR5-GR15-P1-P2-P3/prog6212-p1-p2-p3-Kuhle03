using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using RaceDay.Api.Data;
using RaceDay.Api.Models.DTOs;
using RaceDay.Api.Helpers;
using RaceDay.Api.Models;

namespace RaceDay.Api.Controllers;

[Route("api")]
public class ResultsController : ApiControllerBase
{
    private readonly AppDbContext _db;

    public ResultsController(AppDbContext db) => _db = db;

    private IQueryable<RaceResult> ResultsWithDetails() => _db.Results
        .Include(r => r.Enrolment).ThenInclude(en => en.Participant)
        .Include(r => r.Enrolment).ThenInclude(en => en.Category).ThenInclude(c => c.Event);

    /// <summary>Capture a finish time and position for a participant. Organisers only.</summary>
    /// <remarks>
    /// Expects: enrolmentId, finishTime (hh:mm:ss) and position (1 = winner of that category).
    /// The enrolment must belong to one of your own events.
    /// </remarks>
    /// <response code="201">Result recorded.</response>
    /// <response code="400">A field is missing or invalid (for example a finish time of zero).</response>
    /// <response code="401">Not logged in.</response>
    /// <response code="403">Logged in as a Participant, or the event belongs to another Organiser.</response>
    /// <response code="404">No enrolment has that ID.</response>
    /// <response code="409">This enrolment already has a result, or another finisher already has that position in the category.</response>
    [HttpPost("results")]
    [SessionAuthorize(Roles.Organiser)]
    [ProducesResponseType(typeof(ResultResponse), StatusCodes.Status201Created)]
    [ProducesResponseType(typeof(ErrorResponse), StatusCodes.Status400BadRequest)]
    [ProducesResponseType(typeof(ErrorResponse), StatusCodes.Status401Unauthorized)]
    [ProducesResponseType(typeof(ErrorResponse), StatusCodes.Status403Forbidden)]
    [ProducesResponseType(typeof(ErrorResponse), StatusCodes.Status404NotFound)]
    [ProducesResponseType(typeof(ErrorResponse), StatusCodes.Status409Conflict)]
    public async Task<ActionResult<ResultResponse>> CreateResult(CreateResultDto request)
    {
        if (request.FinishTime <= TimeSpan.Zero)
            return BadRequest(new ErrorResponse("Finish time must be greater than zero (format hh:mm:ss)."));

        var enrolment = await _db.EventEnrolments
            .Include(en => en.Participant)
            .Include(en => en.Category).ThenInclude(c => c.Event)
            .FirstOrDefaultAsync(en => en.EnrolmentID == request.EnrolmentId);
        if (enrolment == null) return NotFound(new ErrorResponse("Enrolment not found."));
        if (enrolment.Category.Event.OrganiserID != CurrentUserId)
            return ForbiddenResult("You can only capture results for your own events.");

        if (await _db.Results.AnyAsync(r => r.EnrolmentID == enrolment.EnrolmentID))
            return Conflict(new ErrorResponse("A result has already been captured for this enrolment."));

        if (await _db.Results.AnyAsync(r => r.Enrolment.CategoryID == enrolment.CategoryID && r.Position == request.Position))
            return Conflict(new ErrorResponse("Another finisher in this category already has that position."));

        var result = new RaceResult
        {
            EnrolmentID = enrolment.EnrolmentID,
            FinishTime = request.FinishTime,
            Position = request.Position,
            Enrolment = enrolment
        };
        _db.Results.Add(result);
        await _db.SaveChangesAsync();

        return StatusCode(StatusCodes.Status201Created, Mapping.ToResultResponse(result));
    }

    /// <summary>Correct a result that was captured earlier. Organisers only.</summary>
    /// <response code="200">Result updated.</response>
    /// <response code="400">A field is missing or invalid.</response>
    /// <response code="401">Not logged in.</response>
    /// <response code="403">Logged in as a Participant, or the event belongs to another Organiser.</response>
    /// <response code="404">No result has that ID.</response>
    /// <response code="409">Another finisher in the category already has that position.</response>
    [HttpPut("results/{id:int}")]
    [SessionAuthorize(Roles.Organiser)]
    [ProducesResponseType(typeof(ResultResponse), StatusCodes.Status200OK)]
    [ProducesResponseType(typeof(ErrorResponse), StatusCodes.Status400BadRequest)]
    [ProducesResponseType(typeof(ErrorResponse), StatusCodes.Status401Unauthorized)]
    [ProducesResponseType(typeof(ErrorResponse), StatusCodes.Status403Forbidden)]
    [ProducesResponseType(typeof(ErrorResponse), StatusCodes.Status404NotFound)]
    [ProducesResponseType(typeof(ErrorResponse), StatusCodes.Status409Conflict)]
    public async Task<ActionResult<ResultResponse>> UpdateResult(int id, UpdateResultDto request)
    {
        if (request.FinishTime <= TimeSpan.Zero)
            return BadRequest(new ErrorResponse("Finish time must be greater than zero (format hh:mm:ss)."));

        var result = await ResultsWithDetails().FirstOrDefaultAsync(r => r.ResultID == id);
        if (result == null) return NotFound(new ErrorResponse("Result not found."));
        if (result.Enrolment.Category.Event.OrganiserID != CurrentUserId)
            return ForbiddenResult("You can only change results for your own events.");

        var categoryId = result.Enrolment.CategoryID;
        if (await _db.Results.AnyAsync(r => r.Enrolment.CategoryID == categoryId && r.Position == request.Position && r.ResultID != id))
            return Conflict(new ErrorResponse("Another finisher in this category already has that position."));

        result.FinishTime = request.FinishTime;
        result.Position = request.Position;
        await _db.SaveChangesAsync();

        return Ok(Mapping.ToResultResponse(result));
    }

    /// <summary>View all results for an event, grouped by category and ordered by position. Open to everyone.</summary>
    /// <response code="200">Returns the results.</response>
    /// <response code="404">No event has that ID.</response>
    [HttpGet("events/{eventId:int}/results")]
    [ProducesResponseType(typeof(IEnumerable<ResultResponse>), StatusCodes.Status200OK)]
    [ProducesResponseType(typeof(ErrorResponse), StatusCodes.Status404NotFound)]
    public async Task<ActionResult<IEnumerable<ResultResponse>>> GetEventResults(int eventId)
    {
        if (!await _db.Events.AnyAsync(e => e.EventID == eventId))
            return NotFound(new ErrorResponse("Event not found."));

        var results = await ResultsWithDetails()
            .Where(r => r.Enrolment.Category.EventID == eventId)
            .OrderBy(r => r.Enrolment.Category.Name).ThenBy(r => r.Position)
            .ToListAsync();

        return Ok(results.Select(Mapping.ToResultResponse));
    }

    /// <summary>View a participant's results across all events. A Participant can only view their own; Organisers can view anyone's.</summary>
    /// <response code="200">Returns the participant's results, newest event first.</response>
    /// <response code="401">Not logged in.</response>
    /// <response code="403">A Participant tried to view someone else's results.</response>
    /// <response code="404">No participant has that ID.</response>
    [HttpGet("participants/{id:int}/results")]
    [SessionAuthorize(Roles.Participant, Roles.Organiser)]
    [ProducesResponseType(typeof(IEnumerable<ResultResponse>), StatusCodes.Status200OK)]
    [ProducesResponseType(typeof(ErrorResponse), StatusCodes.Status401Unauthorized)]
    [ProducesResponseType(typeof(ErrorResponse), StatusCodes.Status403Forbidden)]
    [ProducesResponseType(typeof(ErrorResponse), StatusCodes.Status404NotFound)]
    public async Task<ActionResult<IEnumerable<ResultResponse>>> GetParticipantResults(int id)
    {
        if (CurrentRole == Roles.Participant && id != CurrentUserId)
            return ForbiddenResult("You can only view your own results.");

        if (!await _db.Participants.AnyAsync(p => p.ParticipantID == id))
            return NotFound(new ErrorResponse("Participant not found."));

        var results = await ResultsWithDetails()
            .Where(r => r.Enrolment.ParticipantID == id)
            .OrderByDescending(r => r.Enrolment.Category.Event.EventDate)
            .ToListAsync();

        return Ok(results.Select(Mapping.ToResultResponse));
    }
}
