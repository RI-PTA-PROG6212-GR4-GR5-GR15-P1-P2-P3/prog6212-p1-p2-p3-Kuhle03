using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using RaceDay.Api.Data;
using RaceDay.Api.Models.DTOs;
using RaceDay.Api.Helpers;
using RaceDay.Api.Models;
using RaceDay.Api.Services;

namespace RaceDay.Api.Controllers;

[Route("api/auth")]
public class AuthController : ApiControllerBase
{
    private readonly AppDbContext _db;
    private readonly IPasswordService _passwords;

    public AuthController(AppDbContext db, IPasswordService passwords)
    {
        _db = db;
        _passwords = passwords;
    }

    /// <summary>Register a new account as an Organiser or a Participant.</summary>
    /// <remarks>
    /// Expects: fullName, email, password (min 8 characters), optional contactNumber, and role ("Organiser" or "Participant").
    /// The password is hashed with BCrypt before it is saved. Registering does not log you in.
    /// </remarks>
    /// <response code="201">Account created. Returns the new user's ID, name, email and role.</response>
    /// <response code="400">A field is missing or invalid, or the role is not Organiser/Participant.</response>
    /// <response code="409">That email address is already registered.</response>
    [HttpPost("register")]
    [ProducesResponseType(typeof(AuthResponse), StatusCodes.Status201Created)]
    [ProducesResponseType(typeof(ErrorResponse), StatusCodes.Status400BadRequest)]
    [ProducesResponseType(typeof(ErrorResponse), StatusCodes.Status409Conflict)]
    public async Task<ActionResult<AuthResponse>> Register(RegisterDto request)
    {
        var role = Roles.Normalise(request.Role);
        if (role == null)
            return BadRequest(new ErrorResponse("Role must be 'Organiser' or 'Participant'."));

        var email = request.Email.Trim().ToLowerInvariant();

        // One email can only belong to one account, whichever role it was registered under.
        var taken = await _db.Organisers.AnyAsync(o => o.Email == email)
                    || await _db.Participants.AnyAsync(p => p.Email == email);
        if (taken)
            return Conflict(new ErrorResponse("That email address is already registered."));

        var hash = _passwords.Hash(request.Password);
        int id;

        if (role == Roles.Organiser)
        {
            var organiser = new Organiser
            {
                FullName = request.FullName.Trim(),
                Email = email,
                PasswordHash = hash,
                ContactNumber = request.ContactNumber?.Trim()
            };
            _db.Organisers.Add(organiser);
            await _db.SaveChangesAsync();
            id = organiser.OrganiserID;
        }
        else
        {
            var participant = new Participant
            {
                FullName = request.FullName.Trim(),
                Email = email,
                PasswordHash = hash,
                ContactNumber = request.ContactNumber?.Trim()
            };
            _db.Participants.Add(participant);
            await _db.SaveChangesAsync();
            id = participant.ParticipantID;
        }

        return StatusCode(StatusCodes.Status201Created, new AuthResponse
        {
            UserId = id,
            FullName = request.FullName.Trim(),
            Email = email,
            Role = role
        });
    }

    /// <summary>Log in and start a server-side session.</summary>
    /// <remarks>
    /// Expects: email and password. On success the server stores your user ID and role in the session
    /// and sends back a session cookie, which the browser (and Swagger UI) includes in every later request.
    /// </remarks>
    /// <response code="200">Logged in. Returns the user's ID, name, email and role.</response>
    /// <response code="400">Email or password missing.</response>
    /// <response code="401">Email or password is wrong.</response>
    [HttpPost("login")]
    [ProducesResponseType(typeof(AuthResponse), StatusCodes.Status200OK)]
    [ProducesResponseType(typeof(ErrorResponse), StatusCodes.Status400BadRequest)]
    [ProducesResponseType(typeof(ErrorResponse), StatusCodes.Status401Unauthorized)]
    public async Task<ActionResult<AuthResponse>> Login(LoginDto request)
    {
        var email = request.Email.Trim().ToLowerInvariant();
        AuthResponse? user = null;

        var organiser = await _db.Organisers.FirstOrDefaultAsync(o => o.Email == email);
        if (organiser != null && _passwords.Verify(request.Password, organiser.PasswordHash))
        {
            user = new AuthResponse { UserId = organiser.OrganiserID, FullName = organiser.FullName, Email = organiser.Email, Role = Roles.Organiser };
        }
        else if (organiser == null)
        {
            var participant = await _db.Participants.FirstOrDefaultAsync(p => p.Email == email);
            if (participant != null && _passwords.Verify(request.Password, participant.PasswordHash))
            {
                user = new AuthResponse { UserId = participant.ParticipantID, FullName = participant.FullName, Email = participant.Email, Role = Roles.Participant };
            }
        }

        if (user == null)
            return Unauthorized(new ErrorResponse("Invalid email or password."));

        HttpContext.Session.Clear();   // start a fresh session on every login
        HttpContext.Session.SetInt32(SessionKeys.UserId, user.UserId);
        HttpContext.Session.SetString(SessionKeys.Role, user.Role);
        return Ok(user);
    }

    /// <summary>Log out and destroy the current session.</summary>
    /// <response code="200">Session ended.</response>
    /// <response code="401">You were not logged in.</response>
    [HttpPost("logout")]
    [SessionAuthorize]
    [ProducesResponseType(typeof(ErrorResponse), StatusCodes.Status200OK)]
    [ProducesResponseType(typeof(ErrorResponse), StatusCodes.Status401Unauthorized)]
    public IActionResult Logout()
    {
        HttpContext.Session.Clear();
        return Ok(new ErrorResponse("Logged out."));
    }
}
