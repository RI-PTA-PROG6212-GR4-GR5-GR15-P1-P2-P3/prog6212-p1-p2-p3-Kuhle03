using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using RaceDay.Api.Data;
using RaceDay.Api.Models.DTOs;
using RaceDay.Api.Helpers;
using RaceDay.Api.Models;

namespace RaceDay.Api.Controllers;

[Route("api/events")]
public class EventsController : ApiControllerBase
{
    private readonly AppDbContext _db;

    public EventsController(AppDbContext db) => _db = db;

    /// <summary>List events. Open to everyone, no login needed.</summary>
    /// <remarks>By default only upcoming events are returned. Add ?includePast=true to include events that have already happened.</remarks>
    /// <response code="200">Returns the events, earliest first.</response>
    [HttpGet]
    [ProducesResponseType(typeof(IEnumerable<EventResponse>), StatusCodes.Status200OK)]
    public async Task<ActionResult<IEnumerable<EventResponse>>> GetEvents([FromQuery] bool includePast = false)
    {
        var query = _db.Events.Include(e => e.Organiser).AsQueryable();
        if (!includePast)
        {
            var today = DateTime.UtcNow.Date;
            query = query.Where(e => e.EventDate >= today);
        }

        var events = await query.OrderBy(e => e.EventDate).ToListAsync();
        return Ok(events.Select(Mapping.ToEventResponse));
    }

    /// <summary>Get the details of one event. Open to everyone.</summary>
    /// <response code="200">Returns the event.</response>
    /// <response code="404">No event has that ID.</response>
    [HttpGet("{id:int}")]
    [ProducesResponseType(typeof(EventResponse), StatusCodes.Status200OK)]
    [ProducesResponseType(typeof(ErrorResponse), StatusCodes.Status404NotFound)]
    public async Task<ActionResult<EventResponse>> GetEvent(int id)
    {
        var ev = await _db.Events.Include(e => e.Organiser).FirstOrDefaultAsync(e => e.EventID == id);
        if (ev == null) return NotFound(new ErrorResponse("Event not found."));
        return Ok(Mapping.ToEventResponse(ev));
    }

    /// <summary>Create a new event. Organisers only.</summary>
    /// <remarks>
    /// Expects: name, description, eventDate (today or later), location, distance in km, eventType (Run, Walk or Cycle) and optional routeInfo.
    /// The logged-in Organiser becomes the owner of the event.
    /// </remarks>
    /// <response code="201">Event created. Returns the new event.</response>
    /// <response code="400">A field is missing or invalid, or the date is in the past.</response>
    /// <response code="401">Not logged in.</response>
    /// <response code="403">Logged in as a Participant.</response>
    [HttpPost]
    [SessionAuthorize(Roles.Organiser)]
    [ProducesResponseType(typeof(EventResponse), StatusCodes.Status201Created)]
    [ProducesResponseType(typeof(ErrorResponse), StatusCodes.Status400BadRequest)]
    [ProducesResponseType(typeof(ErrorResponse), StatusCodes.Status401Unauthorized)]
    [ProducesResponseType(typeof(ErrorResponse), StatusCodes.Status403Forbidden)]
    public async Task<ActionResult<EventResponse>> CreateEvent(EventDto request)
    {
        if (request.EventDate.Date < DateTime.UtcNow.Date)
            return BadRequest(new ErrorResponse("The event date cannot be in the past."));

        var ev = new RaceEvent
        {
            OrganiserID = CurrentUserId,
            Name = request.Name.Trim(),
            Description = request.Description.Trim(),
            EventDate = request.EventDate,
            Location = request.Location.Trim(),
            Distance = request.Distance,
            EventType = EventTypes.Normalise(request.EventType),
            RouteInfo = request.RouteInfo?.Trim()
        };

        _db.Events.Add(ev);
        await _db.SaveChangesAsync();
        await _db.Entry(ev).Reference(e => e.Organiser).LoadAsync();

        return CreatedAtAction(nameof(GetEvent), new { id = ev.EventID }, Mapping.ToEventResponse(ev));
    }

    /// <summary>Update an event. Only the Organiser who created it can do this.</summary>
    /// <remarks>Expects the same fields as creating an event.</remarks>
    /// <response code="200">Event updated. Returns the new details.</response>
    /// <response code="400">A field is missing or invalid.</response>
    /// <response code="401">Not logged in.</response>
    /// <response code="403">Logged in as a Participant, or this event belongs to another Organiser.</response>
    /// <response code="404">No event has that ID.</response>
    [HttpPut("{id:int}")]
    [SessionAuthorize(Roles.Organiser)]
    [ProducesResponseType(typeof(EventResponse), StatusCodes.Status200OK)]
    [ProducesResponseType(typeof(ErrorResponse), StatusCodes.Status400BadRequest)]
    [ProducesResponseType(typeof(ErrorResponse), StatusCodes.Status401Unauthorized)]
    [ProducesResponseType(typeof(ErrorResponse), StatusCodes.Status403Forbidden)]
    [ProducesResponseType(typeof(ErrorResponse), StatusCodes.Status404NotFound)]
    public async Task<ActionResult<EventResponse>> UpdateEvent(int id, EventDto request)
    {
        var ev = await _db.Events.Include(e => e.Organiser).FirstOrDefaultAsync(e => e.EventID == id);
        if (ev == null) return NotFound(new ErrorResponse("Event not found."));
        if (ev.OrganiserID != CurrentUserId) return ForbiddenResult("You can only change your own events.");

        ev.Name = request.Name.Trim();
        ev.Description = request.Description.Trim();
        ev.EventDate = request.EventDate;
        ev.Location = request.Location.Trim();
        ev.Distance = request.Distance;
        ev.EventType = EventTypes.Normalise(request.EventType);
        ev.RouteInfo = request.RouteInfo?.Trim();

        await _db.SaveChangesAsync();
        return Ok(Mapping.ToEventResponse(ev));
    }

    /// <summary>Delete an event and its categories. Only the Organiser who created it can do this.</summary>
    /// <response code="200">Event deleted.</response>
    /// <response code="401">Not logged in.</response>
    /// <response code="403">Logged in as a Participant, or this event belongs to another Organiser.</response>
    /// <response code="404">No event has that ID.</response>
    /// <response code="409">Participants have already enrolled, so the event cannot be deleted.</response>
    [HttpDelete("{id:int}")]
    [SessionAuthorize(Roles.Organiser)]
    [ProducesResponseType(typeof(ErrorResponse), StatusCodes.Status200OK)]
    [ProducesResponseType(typeof(ErrorResponse), StatusCodes.Status401Unauthorized)]
    [ProducesResponseType(typeof(ErrorResponse), StatusCodes.Status403Forbidden)]
    [ProducesResponseType(typeof(ErrorResponse), StatusCodes.Status404NotFound)]
    [ProducesResponseType(typeof(ErrorResponse), StatusCodes.Status409Conflict)]
    public async Task<IActionResult> DeleteEvent(int id)
    {
        var ev = await _db.Events.FirstOrDefaultAsync(e => e.EventID == id);
        if (ev == null) return NotFound(new ErrorResponse("Event not found."));
        if (ev.OrganiserID != CurrentUserId) return ForbiddenResult("You can only delete your own events.");

        var hasEnrolments = await _db.EventEnrolments.AnyAsync(en => en.Category.EventID == id);
        if (hasEnrolments)
            return Conflict(new ErrorResponse("This event already has enrolments and cannot be deleted."));

        _db.Categories.RemoveRange(_db.Categories.Where(c => c.EventID == id));
        _db.Events.Remove(ev);
        await _db.SaveChangesAsync();
        return Ok(new ErrorResponse("Event deleted."));
    }
}
