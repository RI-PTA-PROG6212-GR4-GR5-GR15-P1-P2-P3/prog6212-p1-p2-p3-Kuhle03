using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using RaceDay.Api.Data;
using RaceDay.Api.Models.DTOs;
using RaceDay.Api.Helpers;
using RaceDay.Api.Models;

namespace RaceDay.Api.Controllers;

[Route("api")]
public class EnrolmentsController : ApiControllerBase
{
    private readonly AppDbContext _db;

    public EnrolmentsController(AppDbContext db) => _db = db;

    /// <summary>Enter an event by choosing one of its categories. Participants only.</summary>
    /// <remarks>
    /// Expects: categoryId. The system records the link between the logged-in Participant, the category and
    /// (through the category) the event.
    /// </remarks>
    /// <response code="201">Enrolment recorded.</response>
    /// <response code="400">categoryId missing, or the event has already taken place.</response>
    /// <response code="401">Not logged in.</response>
    /// <response code="403">Logged in as an Organiser.</response>
    /// <response code="404">No category has that ID.</response>
    /// <response code="409">You are already enrolled in this category, or it is full.</response>
    [HttpPost("enrolments")]
    [SessionAuthorize(Roles.Participant)]
    [ProducesResponseType(typeof(EnrolmentResponse), StatusCodes.Status201Created)]
    [ProducesResponseType(typeof(ErrorResponse), StatusCodes.Status400BadRequest)]
    [ProducesResponseType(typeof(ErrorResponse), StatusCodes.Status401Unauthorized)]
    [ProducesResponseType(typeof(ErrorResponse), StatusCodes.Status403Forbidden)]
    [ProducesResponseType(typeof(ErrorResponse), StatusCodes.Status404NotFound)]
    [ProducesResponseType(typeof(ErrorResponse), StatusCodes.Status409Conflict)]
    public async Task<ActionResult<EnrolmentResponse>> Enrol(EnrolDto request)
    {
        var category = await _db.Categories.Include(c => c.Event)
            .FirstOrDefaultAsync(c => c.CategoryID == request.CategoryId);
        if (category == null) return NotFound(new ErrorResponse("Category not found."));

        if (category.Event.EventDate.Date < DateTime.UtcNow.Date)
            return BadRequest(new ErrorResponse("This event has already taken place."));

        var participantId = CurrentUserId;

        if (await _db.EventEnrolments.AnyAsync(en => en.ParticipantID == participantId && en.CategoryID == category.CategoryID))
            return Conflict(new ErrorResponse("You are already enrolled in this category."));

        var enrolled = await _db.EventEnrolments.CountAsync(en => en.CategoryID == category.CategoryID);
        if (enrolled >= category.MaxParticipants)
            return Conflict(new ErrorResponse("This category is full."));

        var enrolment = new EventEnrolment { ParticipantID = participantId, CategoryID = category.CategoryID };
        _db.EventEnrolments.Add(enrolment);
        await _db.SaveChangesAsync();

        enrolment.Category = category;
        await _db.Entry(enrolment).Reference(en => en.Participant).LoadAsync();

        return StatusCode(StatusCodes.Status201Created, Mapping.ToEnrolmentResponse(enrolment));
    }

    /// <summary>View your own enrolments. Participants only.</summary>
    /// <response code="200">Returns every event/category you have entered.</response>
    /// <response code="401">Not logged in.</response>
    /// <response code="403">Logged in as an Organiser.</response>
    [HttpGet("enrolments/my")]
    [SessionAuthorize(Roles.Participant)]
    [ProducesResponseType(typeof(IEnumerable<EnrolmentResponse>), StatusCodes.Status200OK)]
    [ProducesResponseType(typeof(ErrorResponse), StatusCodes.Status401Unauthorized)]
    [ProducesResponseType(typeof(ErrorResponse), StatusCodes.Status403Forbidden)]
    public async Task<ActionResult<IEnumerable<EnrolmentResponse>>> GetMyEnrolments()
    {
        var participantId = CurrentUserId;
        var enrolments = await _db.EventEnrolments
            .Include(en => en.Participant)
            .Include(en => en.Category).ThenInclude(c => c.Event)
            .Where(en => en.ParticipantID == participantId)
            .OrderBy(en => en.Category.Event.EventDate)
            .ToListAsync();

        return Ok(enrolments.Select(Mapping.ToEnrolmentResponse));
    }

    /// <summary>View everyone enrolled in one of your events. Organisers only.</summary>
    /// <response code="200">Returns the enrolments for the event.</response>
    /// <response code="401">Not logged in.</response>
    /// <response code="403">Logged in as a Participant, or the event belongs to another Organiser.</response>
    /// <response code="404">No event has that ID.</response>
    [HttpGet("events/{eventId:int}/enrolments")]
    [SessionAuthorize(Roles.Organiser)]
    [ProducesResponseType(typeof(IEnumerable<EnrolmentResponse>), StatusCodes.Status200OK)]
    [ProducesResponseType(typeof(ErrorResponse), StatusCodes.Status401Unauthorized)]
    [ProducesResponseType(typeof(ErrorResponse), StatusCodes.Status403Forbidden)]
    [ProducesResponseType(typeof(ErrorResponse), StatusCodes.Status404NotFound)]
    public async Task<ActionResult<IEnumerable<EnrolmentResponse>>> GetEventEnrolments(int eventId)
    {
        var ev = await _db.Events.FirstOrDefaultAsync(e => e.EventID == eventId);
        if (ev == null) return NotFound(new ErrorResponse("Event not found."));
        if (ev.OrganiserID != CurrentUserId) return ForbiddenResult("You can only view enrolments for your own events.");

        var enrolments = await _db.EventEnrolments
            .Include(en => en.Participant)
            .Include(en => en.Category).ThenInclude(c => c.Event)
            .Where(en => en.Category.EventID == eventId)
            .OrderBy(en => en.Category.Name).ThenBy(en => en.Participant.FullName)
            .ToListAsync();

        return Ok(enrolments.Select(Mapping.ToEnrolmentResponse));
    }

    /// <summary>Cancel one of your own enrolments. Participants only.</summary>
    /// <response code="200">Enrolment cancelled.</response>
    /// <response code="401">Not logged in.</response>
    /// <response code="403">Logged in as an Organiser, or this enrolment belongs to someone else.</response>
    /// <response code="404">No enrolment has that ID.</response>
    /// <response code="409">A result has already been captured for this enrolment.</response>
    [HttpDelete("enrolments/{id:int}")]
    [SessionAuthorize(Roles.Participant)]
    [ProducesResponseType(typeof(ErrorResponse), StatusCodes.Status200OK)]
    [ProducesResponseType(typeof(ErrorResponse), StatusCodes.Status401Unauthorized)]
    [ProducesResponseType(typeof(ErrorResponse), StatusCodes.Status403Forbidden)]
    [ProducesResponseType(typeof(ErrorResponse), StatusCodes.Status404NotFound)]
    [ProducesResponseType(typeof(ErrorResponse), StatusCodes.Status409Conflict)]
    public async Task<IActionResult> CancelEnrolment(int id)
    {
        var enrolment = await _db.EventEnrolments.Include(en => en.Result)
            .FirstOrDefaultAsync(en => en.EnrolmentID == id);
        if (enrolment == null) return NotFound(new ErrorResponse("Enrolment not found."));
        if (enrolment.ParticipantID != CurrentUserId) return ForbiddenResult("You can only cancel your own enrolments.");
        if (enrolment.Result != null)
            return Conflict(new ErrorResponse("A result has already been captured, so this enrolment cannot be cancelled."));

        _db.EventEnrolments.Remove(enrolment);
        await _db.SaveChangesAsync();
        return Ok(new ErrorResponse("Enrolment cancelled."));
    }
}
