using Microsoft.AspNetCore.Mvc;
using RaceDay.Api.Models.DTOs;
using RaceDay.Api.Helpers;

namespace RaceDay.Api.Controllers;

[ApiController]
[Produces("application/json")]
public abstract class ApiControllerBase : ControllerBase
{
    /// <summary>ID of the logged-in user, read from the server-side session.</summary>
    protected int CurrentUserId => HttpContext.Session.GetInt32(SessionKeys.UserId) ?? 0;

    /// <summary>Role of the logged-in user ("Organiser" or "Participant"), read from the session.</summary>
    protected string? CurrentRole => HttpContext.Session.GetString(SessionKeys.Role);

    protected ObjectResult ForbiddenResult(string message) =>
        StatusCode(StatusCodes.Status403Forbidden, new ErrorResponse(message));
}
