namespace RaceDay.Api.Models;

/// <summary>Maps to the Events table (named RaceEvent in C# to avoid clashing with the C# "event" keyword).</summary>
public class RaceEvent
{
    public int EventID { get; set; }
    public int OrganiserID { get; set; }
    public string Name { get; set; } = string.Empty;
    public string Description { get; set; } = string.Empty;
    public DateTime EventDate { get; set; }
    public string Location { get; set; } = string.Empty;
    public decimal Distance { get; set; }
    public string EventType { get; set; } = string.Empty;   // Run, Walk or Cycle
    public string? RouteInfo { get; set; }

    public Organiser Organiser { get; set; } = null!;
    public List<Category> Categories { get; set; } = new();
}
