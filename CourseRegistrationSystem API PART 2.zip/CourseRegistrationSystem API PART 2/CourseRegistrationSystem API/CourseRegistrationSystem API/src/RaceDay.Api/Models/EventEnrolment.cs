namespace RaceDay.Api.Models;

/// <summary>Junction table linking a Participant to a Category (and therefore to an event).</summary>
public class EventEnrolment
{
    public int EnrolmentID { get; set; }
    public int ParticipantID { get; set; }
    public int CategoryID { get; set; }
    public DateTime EnrolmentDate { get; set; } = DateTime.UtcNow;

    public Participant Participant { get; set; } = null!;
    public Category Category { get; set; } = null!;
    public RaceResult? Result { get; set; }
}
