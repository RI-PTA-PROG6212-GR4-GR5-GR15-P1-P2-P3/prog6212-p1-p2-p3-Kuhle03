namespace RaceDay.Api.Models;

public class Category
{
    public int CategoryID { get; set; }
    public int EventID { get; set; }
    public string Name { get; set; } = string.Empty;
    public decimal? Distance { get; set; }          // null for age-based categories such as "Under 20"
    public int MaxParticipants { get; set; } = 100;

    public RaceEvent Event { get; set; } = null!;
    public List<EventEnrolment> Enrolments { get; set; } = new();
}
