namespace RaceDay.Api.Models;

/// <summary>Maps to the Results table. One result per enrolment.</summary>
public class RaceResult
{
    public int ResultID { get; set; }
    public int EnrolmentID { get; set; }
    public TimeSpan FinishTime { get; set; }
    public int Position { get; set; }                // rank inside the category

    public EventEnrolment Enrolment { get; set; } = null!;
}
