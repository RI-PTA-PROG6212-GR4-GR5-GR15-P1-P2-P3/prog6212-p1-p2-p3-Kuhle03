# RaceDay – API Endpoint Plan
**Module:** PROG6212 – Portfolio of Evidence (Part 1, Section B)

This document lists every API endpoint the RaceDay system will expose, covering Authentication, User Profile, Events, Categories, Event Enrolments, and Results. It is designed to match the ERD, in which Organisers and Participants are modelled as separate tables, and EventEnrolments is the junction table resolving the Participant–Category many-to-many relationship.

---

## Authentication

| HTTP Method | Route | Description | Role Required | Request Body | Expected Response |
|---|---|---|---|---|---|
| POST | /api/auth/register | Registers a new user as either an Organiser or a Participant | None (public) | `{ fullName, email, password, role }` | 201 Created – user account created, returns basic profile<br>400 Bad Request – validation failed<br>409 Conflict – email already registered |
| POST | /api/auth/login | Logs a user in and starts a server-side session | None (public) | `{ email, password }` | 200 OK – session started (session cookie), returns user ID and role<br>401 Unauthorized – invalid credentials |
| POST | /api/auth/logout | Logs the user out and ends the session | Organiser or Participant | None | 200 OK – session ended<br>401 Unauthorized – not logged in |

## User Profile

| HTTP Method | Route | Description | Role Required | Request Body | Expected Response |
|---|---|---|---|---|---|
| GET | /api/profile | Returns the logged-in user's own profile details | Organiser or Participant | None | 200 OK – profile data returned<br>401 Unauthorized – no valid token |
| PUT | /api/profile | Updates the logged-in user's own profile details | Organiser or Participant | `{ fullName, email, contactNumber }` | 200 OK – profile updated<br>400 Bad Request – validation failed |

## Events

| HTTP Method | Route | Description | Role Required | Request Body | Expected Response |
|---|---|---|---|---|---|
| GET | /api/events | Lists all upcoming events, so participants can browse | None (public) | None | 200 OK – array of events returned |
| GET | /api/events/{id} | Returns full details for one event | None (public) | None | 200 OK – event details returned<br>404 Not Found – event does not exist |
| POST | /api/events | Creates a new event | Organiser | `{ name, description, eventDate, location, distance, eventType, routeInfo }` | 201 Created – event created<br>400 Bad Request – validation failed |
| PUT | /api/events/{id} | Updates an event the Organiser owns | Organiser | `{ name, description, eventDate, location, distance, eventType, routeInfo }` | 200 OK – event updated<br>403 Forbidden – not the owning Organiser<br>404 Not Found – event does not exist |
| DELETE | /api/events/{id} | Deletes an event the Organiser owns | Organiser | None | 200 OK – event deleted<br>403 Forbidden – not the owning Organiser<br>404 Not Found – event does not exist<br>409 Conflict – event already has enrolments |

## Categories

| HTTP Method | Route | Description | Role Required | Request Body | Expected Response |
|---|---|---|---|---|---|
| GET | /api/events/{eventId}/categories | Lists all categories for a specific event (e.g. 10km, 21km) | None (public) | None | 200 OK – array of categories returned<br>404 Not Found – event does not exist |
| POST | /api/events/{eventId}/categories | Creates a new category under an event (distance optional for age categories such as Under 20) | Organiser | `{ name, distance, maxParticipants }` | 201 Created – category created<br>403 Forbidden – not the owning Organiser |
| GET | /api/categories/{id} | Returns one category | None (public) | None | 200 OK – category returned<br>404 Not Found – category does not exist |
| PUT | /api/categories/{id} | Updates a category the Organiser owns | Organiser | `{ name, distance, maxParticipants }` | 200 OK – category updated<br>403 Forbidden – not the owning Organiser<br>404 Not Found – category does not exist |
| DELETE | /api/categories/{id} | Deletes a category the Organiser owns | Organiser | None | 200 OK – category deleted<br>403 Forbidden – not the owning Organiser<br>404 Not Found – category does not exist<br>409 Conflict – category already has enrolments |

## Event Enrolments

| HTTP Method | Route | Description | Role Required | Request Body | Expected Response |
|---|---|---|---|---|---|
| POST | /api/enrolments | Enrols the logged-in Participant into a category for an event | Participant | `{ categoryId }` | 201 Created – enrolment created<br>404 Not Found – category does not exist<br>400 Bad Request – event already took place<br>409 Conflict – category full or already enrolled |
| GET | /api/enrolments/my | Returns the logged-in Participant's own enrolment history | Participant | None | 200 OK – array of the participant's enrolments returned |
| GET | /api/events/{eventId}/enrolments | Returns all enrolments for an event, for the Organiser managing it | Organiser | None | 200 OK – array of enrolments returned<br>403 Forbidden – not the owning Organiser |
| DELETE | /api/enrolments/{id} | Cancels the logged-in Participant's own enrolment | Participant | None | 200 OK – enrolment cancelled<br>403 Forbidden – not the owning participant<br>404 Not Found – enrolment does not exist |

## Results

| HTTP Method | Route | Description | Role Required | Request Body | Expected Response |
|---|---|---|---|---|---|
| POST | /api/results | Captures a result for a participant in a category | Organiser | `{ enrolmentId, finishTime, position }` | 201 Created – result recorded<br>404 Not Found – enrolment does not exist<br>409 Conflict – result already captured, or position already taken in the category |
| PUT | /api/results/{id} | Updates a previously captured result | Organiser | `{ finishTime, position }` | 200 OK – result updated<br>404 Not Found – result does not exist |
| GET | /api/events/{eventId}/results | Returns all results for an event, grouped by category | None (public) | None | 200 OK – array of results returned<br>404 Not Found – event does not exist |
| GET | /api/participants/{id}/results | Returns a participant's personal performance history across events | Participant (own) or Organiser | None | 200 OK – array of results returned<br>403 Forbidden – requesting another participant's history |

---

## Design Notes

- **Nested routes** (e.g. `/api/events/{eventId}/categories`) are used because categories don't exist independently of an event — the URL structure reflects that ownership.
- **403 vs 404**: a 404 means the resource doesn't exist at all; a 403 means it exists but the caller isn't allowed to act on it. Distinguishing these shows the design accounts for authorisation, not just basic CRUD.
- **`/api/enrolments/my`** is kept separate from the Organiser-facing enrolments-by-event route, since "show me my races" (Participant) and "show me who's entered my event" (Organiser) are different concerns requiring different roles.

- **Updated during Part 2:** login now starts a server-side session (cookie) instead of returning a JWT, because the Part 2 brief requires session management. Events gained `distance` and `eventType` (Run, Walk or Cycle), and category distance became optional so age categories like "Under 20" fit. A logout endpoint and `GET /api/categories/{id}` were added.
