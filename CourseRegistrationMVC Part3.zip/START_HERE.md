# RaceDay Part 3: how to add this to your repository

Your repo (`RaceDay-POE`) keeps Part 2 in `Part2-API/`. Add Part 3 next to it:

## 1. Part 3 MVC project
1. In Visual Studio: **File > New > Project > ASP.NET Core Web App (Model-View-Controller)**, name it `RaceDayMvc`, .NET 8, Authentication: None.
   Create it inside `RaceDay-POE/Part3-MVC/`. (This gives you the Bootstrap / jQuery files in `wwwroot/lib`.)
2. Copy everything from `Part3-MVC/RaceDayMvc/` in this zip over it, replacing files. Delete the template's own `Models/ErrorViewModel.cs` and
   `Views/Home/Privacy.cshtml` if you like (they are unused). Keep `wwwroot/lib` and `wwwroot/js/site.js`.
3. Right-click the solution > Add > Existing Project > `RaceDayMvc.csproj`.

## 2. Part 2 API changes (Azure Blob Storage)
1. Copy the files in `Part2-API-Changes/src/RaceDay.Api/` over the same paths in `Part2-API/src/RaceDay.Api/`
   (6 changed files + 3 new ones: `Services/BlobStorageService.cs`, `Controllers/EventBannerController.cs`, `Controllers/ProfilePictureController.cs`).
2. Run `Part2-API-Changes/add-blob-columns.sql` once on `RaceDayApiDb` (or drop the database and let the API recreate it).
3. Restore packages (adds `Azure.Storage.Blobs`). For local practice start **Azurite**; for real Azure put your storage connection string in
   user-secrets or an environment variable (`ConnectionStrings__StorageConnectionString`), never in GitHub.

## 3. GitHub Actions
Replace `.github/workflows/dotnet.yml` with the one in this zip (it still builds and tests Part 2, and now builds the MVC project + Docker image).

## 4. Still on you for the POE
- At least **20 meaningful commits** for Part 3 (suggest a `part3` branch or the `Part3-MVC` folder).
- Put your YouTube link in `Part3-MVC/RaceDayMvc/README.md`.
- Submit the GitHub link on ARC.
