using Microsoft.AspNetCore.Mvc;
using RaceDayMvc.Infrastructure;
using RaceDayMvc.Models;

namespace RaceDayMvc.Controllers;

/// <summary>Organiser-only: create, edit, delete events and upload the banner image.</summary>
[SessionAuthorize(Roles = Roles.Organiser)]
public class ManageEventsController : ApiControllerBase
{
    public ManageEventsController(IHttpClientFactory factory) : base(factory) { }

    public async Task<IActionResult> Index()
    {
        var result = await GetMyEventsAsync();
        if (!result.Ok) ViewBag.Error = result.Error;
        return View(result.Data ?? new List<EventDto>());
    }

    // ---------- Create ----------
    [HttpGet]
    public IActionResult Create() => View(new EventFormModel());

    [HttpPost, ValidateAntiForgeryToken]
    public async Task<IActionResult> Create(EventFormModel model)
    {
        var imageError = ValidateImage(model.Banner);
        if (imageError != null) ModelState.AddModelError(nameof(model.Banner), imageError);
        if (model.EventDate.Date < DateTime.Today)
            ModelState.AddModelError(nameof(model.EventDate), "The event date cannot be in the past.");
        if (!ModelState.IsValid) return View(model);

        var created = await SendAsync<EventDto>(HttpMethod.Post, ApiRoutes.UpcomingEvents, ToApiBody(model));
        if (!created.Ok)
        {
            ModelState.AddModelError("", created.Error!);
            return View(model);
        }

        // Banner goes MVC -> API -> Azure Blob Storage
        if (model.Banner is { Length: > 0 } && created.Data != null)
        {
            var upload = await UploadAsync(ApiRoutes.EventBanner(created.Data.EventID), model.Banner);
            if (!upload.Ok)
            {
                TempData["Error"] = "Event created, but the banner could not be uploaded: " + upload.Error;
                return RedirectToAction(nameof(Index));
            }
        }

        TempData["Success"] = "Event created. Add categories so participants can enrol.";
        return RedirectToAction(nameof(Index));
    }

    // ---------- Edit ----------
    [HttpGet]
    public async Task<IActionResult> Edit(int id)
    {
        var result = await GetAsync<EventDto>(ApiRoutes.EventById(id));
        if (!result.Ok || result.Data == null)
        {
            TempData["Error"] = result.Error ?? "That event could not be found.";
            return RedirectToAction(nameof(Index));
        }

        var e = result.Data;
        if (e.OrganiserID != CurrentUserId)
        {
            TempData["Error"] = "You can only change your own events.";
            return RedirectToAction(nameof(Index));
        }

        return View(new EventFormModel
        {
            EventID = e.EventID,
            Name = e.Name,
            Description = e.Description,
            EventDate = e.EventDate,
            Location = e.Location,
            Distance = e.Distance,
            EventType = e.EventType,
            RouteInfo = e.RouteInfo,
            HasBanner = !string.IsNullOrWhiteSpace(e.BannerBlobName)
        });
    }

    [HttpPost, ValidateAntiForgeryToken]
    public async Task<IActionResult> Edit(int id, EventFormModel model)
    {
        model.EventID = id;
        var imageError = ValidateImage(model.Banner);
        if (imageError != null) ModelState.AddModelError(nameof(model.Banner), imageError);
        if (!ModelState.IsValid) return View(model);

        var updated = await SendAsync<object>(HttpMethod.Put, ApiRoutes.EventById(id), ToApiBody(model));
        if (!updated.Ok)
        {
            ModelState.AddModelError("", updated.Error!);
            return View(model);
        }

        if (model.Banner is { Length: > 0 })
        {
            var upload = await UploadAsync(ApiRoutes.EventBanner(id), model.Banner);
            if (!upload.Ok)
            {
                TempData["Error"] = "Event updated, but the banner could not be uploaded: " + upload.Error;
                return RedirectToAction(nameof(Index));
            }
        }

        TempData["Success"] = "Event updated.";
        return RedirectToAction(nameof(Index));
    }

    // ---------- Delete ----------
    [HttpGet]
    public async Task<IActionResult> Delete(int id)
    {
        var result = await GetAsync<EventDto>(ApiRoutes.EventById(id));
        if (!result.Ok || result.Data == null)
        {
            TempData["Error"] = result.Error ?? "That event could not be found.";
            return RedirectToAction(nameof(Index));
        }

        var cats = await GetAsync<List<CategoryDto>>(ApiRoutes.EventCategories(id));
        result.Data.EnrolmentCount = cats.Data?.Sum(c => c.EnrolledCount) ?? 0;
        return View(result.Data);
    }

    [HttpPost, ActionName("Delete"), ValidateAntiForgeryToken]
    public async Task<IActionResult> DeleteConfirmed(int id)
    {
        // The API refuses (409) when people have already enrolled; its message is shown to the user.
        var result = await SendAsync<object>(HttpMethod.Delete, ApiRoutes.EventById(id));
        if (result.Ok) TempData["Success"] = "Event deleted.";
        else TempData["Error"] = result.Error;
        return RedirectToAction(nameof(Index));
    }

    private static object ToApiBody(EventFormModel m) => new
    {
        name = m.Name,
        description = m.Description,
        eventDate = m.EventDate,
        location = m.Location,
        distance = m.Distance,
        eventType = m.EventType,
        routeInfo = m.RouteInfo
    };
}
