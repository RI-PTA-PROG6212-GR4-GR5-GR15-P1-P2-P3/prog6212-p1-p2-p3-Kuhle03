using Microsoft.AspNetCore.Mvc;
using RaceDayMvc.Infrastructure;
using RaceDayMvc.Models;

namespace RaceDayMvc.Controllers;

public class EnrolmentsController : ApiControllerBase
{
    public EnrolmentsController(IHttpClientFactory factory) : base(factory) { }

    // ----- Participant: enrol for an event by choosing a category -----
    [HttpPost, ValidateAntiForgeryToken]
    [SessionAuthorize(Roles = Roles.Participant)]
    public async Task<IActionResult> Enrol(int eventId, int categoryId)
    {
        if (categoryId <= 0)
        {
            TempData["Error"] = "Please select a category before enrolling.";
            return RedirectToAction("Details", "Events", new { id = eventId });
        }

        // The API reads the participant from the session, so only the category is sent.
        var result = await SendAsync<object>(HttpMethod.Post, ApiRoutes.Enrol, new { categoryId });

        if (result.Ok)
        {
            TempData["Success"] = "You are enrolled! Your enrolment has been recorded.";
            return RedirectToAction(nameof(Mine));
        }

        TempData["Error"] = result.Error;
        return RedirectToAction("Details", "Events", new { id = eventId });
    }

    // ----- Participant: personal view of enrolments and their status -----
    [SessionAuthorize(Roles = Roles.Participant)]
    public async Task<IActionResult> Mine()
    {
        var enrolments = await GetAsync<List<EnrolmentDto>>(ApiRoutes.MyEnrolments);
        if (!enrolments.Ok) ViewBag.Error = enrolments.Error;

        var results = await GetAsync<List<ResultDto>>(ApiRoutes.ResultsForParticipant(CurrentUserId));
        var resultIds = (results.Data ?? new List<ResultDto>()).Select(r => r.EnrolmentID).ToHashSet();

        var list = enrolments.Data ?? new List<EnrolmentDto>();
        foreach (var e in list)
            e.Status = EnrolmentStatus.For(e.EventDate, resultIds.Contains(e.EnrolmentID));

        return View(list.OrderBy(e => e.EventDate).ToList());
    }

    // ----- Participant: cancel an upcoming enrolment -----
    [HttpPost, ValidateAntiForgeryToken]
    [SessionAuthorize(Roles = Roles.Participant)]
    public async Task<IActionResult> Cancel(int id)
    {
        var result = await SendAsync<object>(HttpMethod.Delete, $"api/enrolments/{id}");
        if (result.Ok) TempData["Success"] = "Enrolment cancelled.";
        else TempData["Error"] = result.Error;
        return RedirectToAction(nameof(Mine));
    }

    // ----- Organiser: all participants enrolled for one event -----
    [SessionAuthorize(Roles = Roles.Organiser)]
    public async Task<IActionResult> ByEvent(int eventId)
    {
        var ev = await GetAsync<EventDto>(ApiRoutes.EventById(eventId));
        if (!ev.Ok || ev.Data == null)
        {
            TempData["Error"] = ev.Error ?? "That event could not be found.";
            return RedirectToAction("Index", "ManageEvents");
        }

        var list = await GetAsync<List<EnrolmentDto>>(ApiRoutes.EnrolmentsForEvent(eventId));
        if (!list.Ok) ViewBag.Error = list.Error;

        var results = await GetAsync<List<ResultDto>>(ApiRoutes.ResultsForEvent(eventId));
        var resultIds = (results.Data ?? new List<ResultDto>()).Select(r => r.EnrolmentID).ToHashSet();

        var enrolments = list.Data ?? new List<EnrolmentDto>();
        foreach (var e in enrolments)
            e.Status = EnrolmentStatus.For(e.EventDate, resultIds.Contains(e.EnrolmentID));

        return View(new EnrolmentsByEventViewModel { Event = ev.Data, Enrolments = enrolments });
    }
}
