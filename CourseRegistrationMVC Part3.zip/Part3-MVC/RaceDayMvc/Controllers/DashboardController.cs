using Microsoft.AspNetCore.Mvc;
using RaceDayMvc.Infrastructure;
using RaceDayMvc.Models;

namespace RaceDayMvc.Controllers;

[SessionAuthorize]
public class DashboardController : ApiControllerBase
{
    public DashboardController(IHttpClientFactory factory) : base(factory) { }

    public async Task<IActionResult> Index()
    {
        // Participants land on the upcoming-events home page.
        if (CurrentRole == Roles.Participant)
            return RedirectToAction("Index", "Events");

        if (CurrentRole != Roles.Organiser)
            return RedirectToAction("AccessDenied", "Account");

        var result = await GetMyEventsAsync();
        var events = result.Data ?? new List<EventDto>();
        if (!result.Ok) ViewBag.Error = result.Error;

        var vm = new OrganiserDashboardViewModel
        {
            AllEvents = events,
            TotalEvents = events.Count,
            TotalEnrolments = events.Sum(e => e.EnrolmentCount),
            Upcoming = events.Where(e => e.EventDate.Date >= DateTime.Today)
                             .OrderBy(e => e.EventDate).Take(5).ToList()
        };

        return View("Organiser", vm);
    }
}
