using Microsoft.AspNetCore.Mvc;
using RaceDayMvc.Infrastructure;
using RaceDayMvc.Models;

namespace RaceDayMvc.Controllers;

/// <summary>Participant-facing pages: upcoming events with filters, and the event detail page.</summary>
[SessionAuthorize]
public class EventsController : ApiControllerBase
{
    public EventsController(IHttpClientFactory factory) : base(factory) { }

    public async Task<IActionResult> Index(EventFilter filter)
    {
        // GET api/events returns upcoming events only (includePast defaults to false)
        var result = await GetAsync<List<EventDto>>(ApiRoutes.UpcomingEvents);
        if (!result.Ok) ViewBag.Error = result.Error;

        var events = (result.Data ?? new List<EventDto>()).AsEnumerable();

        if (!string.IsNullOrWhiteSpace(filter.Search))
        {
            var s = filter.Search.Trim();
            events = events.Where(e =>
                e.Name.Contains(s, StringComparison.OrdinalIgnoreCase) ||
                e.Location.Contains(s, StringComparison.OrdinalIgnoreCase));
        }
        if (!string.IsNullOrWhiteSpace(filter.EventType))
            events = events.Where(e => e.EventType.Equals(filter.EventType, StringComparison.OrdinalIgnoreCase));
        if (filter.From.HasValue)
            events = events.Where(e => e.EventDate.Date >= filter.From.Value.Date);
        if (filter.MaxDistance.HasValue)
            events = events.Where(e => e.Distance <= filter.MaxDistance.Value);

        return View(new EventsIndexViewModel
        {
            Filter = filter,
            Events = events.OrderBy(e => e.EventDate).ToList()
        });
    }

    public async Task<IActionResult> Details(int id)
    {
        var ev = await GetAsync<EventDto>(ApiRoutes.EventById(id));
        if (!ev.Ok || ev.Data == null)
        {
            TempData["Error"] = ev.Error ?? "That event could not be found.";
            return RedirectToAction(nameof(Index));
        }

        var cats = await GetAsync<List<CategoryDto>>(ApiRoutes.EventCategories(id));

        return View(new EventDetailsViewModel
        {
            Event = ev.Data,
            Categories = cats.Data ?? new List<CategoryDto>()
        });
    }

    /// <summary>Returns the banner image (read from Blob Storage by the API).</summary>
    public Task<IActionResult> Banner(int id) =>
        ProxyImageAsync(ApiRoutes.EventBanner(id), "~/images/event-placeholder.svg");
}
