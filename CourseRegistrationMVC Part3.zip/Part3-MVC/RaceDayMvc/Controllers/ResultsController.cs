using System.Globalization;
using Microsoft.AspNetCore.Mvc;
using RaceDayMvc.Infrastructure;
using RaceDayMvc.Models;

namespace RaceDayMvc.Controllers;

public class ResultsController : ApiControllerBase
{
    private static readonly string[] TimeFormats =
        { @"h\:mm\:ss", @"hh\:mm\:ss", @"h\:mm\:ss\.f", @"hh\:mm\:ss\.ff", @"hh\:mm\:ss\.fff" };

    public ResultsController(IHttpClientFactory factory) : base(factory) { }

    // ================= Organiser: capture finish times and positions =================

    [SessionAuthorize(Roles = Roles.Organiser)]
    [HttpGet]
    public async Task<IActionResult> Entry(int eventId)
    {
        var ev = await GetAsync<EventDto>(ApiRoutes.EventById(eventId));
        if (!ev.Ok || ev.Data == null || ev.Data.OrganiserID != CurrentUserId)
        {
            TempData["Error"] = ev.Error ?? "That event could not be found.";
            return RedirectToAction("Index", "ManageEvents");
        }

        var enrolments = await GetAsync<List<EnrolmentDto>>(ApiRoutes.EnrolmentsForEvent(eventId));
        var existing = await GetAsync<List<ResultDto>>(ApiRoutes.ResultsForEvent(eventId));
        if (!enrolments.Ok) ViewBag.Error = enrolments.Error;

        var results = existing.Data ?? new List<ResultDto>();

        var rows = (enrolments.Data ?? new List<EnrolmentDto>())
            .Select(e =>
            {
                var r = results.FirstOrDefault(x => x.EnrolmentID == e.EnrolmentID);
                var time = r?.FinishTime.ToString(@"hh\:mm\:ss");
                return new ResultRowModel
                {
                    EnrolmentID = e.EnrolmentID,
                    CategoryID = e.CategoryID,
                    ParticipantName = e.ParticipantName,
                    CategoryName = e.CategoryName,
                    ResultID = r?.ResultID ?? 0,
                    OriginalFinishTime = time,
                    OriginalPosition = r?.Position,
                    FinishTime = time,
                    Position = r?.Position
                };
            })
            .OrderBy(r => r.CategoryName).ThenBy(r => r.Position ?? int.MaxValue).ThenBy(r => r.ParticipantName)
            .ToList();

        return View(new ResultsEntryViewModel { EventID = eventId, EventName = ev.Data.Name, Rows = rows });
    }

    [SessionAuthorize(Roles = Roles.Organiser)]
    [HttpPost, ValidateAntiForgeryToken]
    public async Task<IActionResult> Entry(ResultsEntryViewModel model)
    {
        // ---- 1. Validate what the organiser typed ----
        var entries = new List<(ResultRowModel Row, TimeSpan Time)>();

        for (var i = 0; i < model.Rows.Count; i++)
        {
            var row = model.Rows[i];
            if (string.IsNullOrWhiteSpace(row.FinishTime)) continue;

            if (!TimeSpan.TryParseExact(row.FinishTime.Trim(), TimeFormats, CultureInfo.InvariantCulture, out var ts)
                || ts <= TimeSpan.Zero)
            {
                ModelState.AddModelError($"Rows[{i}].FinishTime", "Use the format hh:mm:ss, e.g. 01:23:45");
                continue;
            }
            if (row.Position is <= 0 or > 100000)
            {
                ModelState.AddModelError($"Rows[{i}].Position", "Position must be between 1 and 100000");
                continue;
            }
            entries.Add((row, ts));
        }

        if (!ModelState.IsValid) return View(model);

        if (entries.Count == 0)
        {
            ModelState.AddModelError("", "Enter at least one finish time before publishing.");
            return View(model);
        }

        // ---- 2. Positions are per category. If any position in a category is blank, rank that whole category by time. ----
        foreach (var group in entries.GroupBy(x => x.Row.CategoryID))
        {
            if (group.Any(x => x.Row.Position == null))
            {
                var rank = 1;
                foreach (var item in group.OrderBy(x => x.Time)) item.Row.Position = rank++;
            }
            else if (group.Select(x => x.Row.Position).Distinct().Count() != group.Count())
            {
                ModelState.AddModelError("", $"Two finishers in '{group.First().Row.CategoryName}' have the same position.");
            }
        }
        if (!ModelState.IsValid) return View(model);

        // ---- 3. Only send rows that are new or changed ----
        var changed = entries.Where(x =>
            x.Row.ResultID == 0 ||
            x.Row.Position != x.Row.OriginalPosition ||
            x.Row.FinishTime!.Trim() != x.Row.OriginalFinishTime).ToList();

        if (changed.Count == 0)
        {
            TempData["Success"] = "Results are already up to date.";
            return RedirectToAction("Index", "ManageEvents");
        }

        var errors = new List<string>();

        // Phase 1: the API refuses duplicate positions inside a category, so existing results that are moving
        // are parked on temporary positions first. This lets positions swap safely.
        var temp = 90000;
        foreach (var item in changed.Where(x => x.Row.ResultID > 0 && x.Row.Position != x.Row.OriginalPosition))
        {
            var body = new { finishTime = TimeSpan.Parse(item.Row.OriginalFinishTime ?? "00:00:01"), position = temp++ };
            var park = await SendAsync<object>(HttpMethod.Put, ApiRoutes.ResultById(item.Row.ResultID), body);
            if (!park.Ok) errors.Add($"{item.Row.ParticipantName}: {park.Error}");
        }

        // Phase 2: write the final values.
        foreach (var item in changed)
        {
            ApiResult<object> saved;
            if (item.Row.ResultID > 0)
            {
                saved = await SendAsync<object>(HttpMethod.Put, ApiRoutes.ResultById(item.Row.ResultID),
                    new { finishTime = item.Time, position = item.Row.Position });
            }
            else
            {
                saved = await SendAsync<object>(HttpMethod.Post, ApiRoutes.CreateResult,
                    new { enrolmentId = item.Row.EnrolmentID, finishTime = item.Time, position = item.Row.Position });
            }
            if (!saved.Ok) errors.Add($"{item.Row.ParticipantName}: {saved.Error}");
        }

        if (errors.Count > 0)
        {
            // Reload from the API so the page shows exactly what was saved.
            TempData["Error"] = "Some results could not be saved. " + string.Join(" ", errors);
            return RedirectToAction(nameof(Entry), new { eventId = model.EventID });
        }

        TempData["Success"] = "Results published.";
        return RedirectToAction("Index", "ManageEvents");
    }

    // ================= Participant: personal race history =================

    [SessionAuthorize(Roles = Roles.Participant)]
    public async Task<IActionResult> Mine()
    {
        var result = await GetAsync<List<ResultDto>>(ApiRoutes.ResultsForParticipant(CurrentUserId));
        if (!result.Ok) ViewBag.Error = result.Error;
        var list = result.Data ?? new List<ResultDto>();

        // Event dates (the results endpoint does not include them)
        var events = await GetAsync<List<EventDto>>(ApiRoutes.AllEvents);
        var dates = (events.Data ?? new List<EventDto>()).ToDictionary(e => e.EventID, e => e.EventDate);

        // Position is inside a category, so "out of N finishers" = results published for that event + category
        var totals = new Dictionary<int, List<ResultDto>>();
        foreach (var eventId in list.Select(r => r.EventID).Distinct())
        {
            var all = await GetAsync<List<ResultDto>>(ApiRoutes.ResultsForEvent(eventId));
            totals[eventId] = all.Data ?? new List<ResultDto>();
        }

        foreach (var r in list)
        {
            r.EventDate = dates.TryGetValue(r.EventID, out var d) ? d : default;
            r.TotalFinishers = totals.TryGetValue(r.EventID, out var all)
                ? all.Count(x => x.CategoryID == r.CategoryID)
                : 0;
        }

        return View(list.OrderByDescending(r => r.EventDate).ToList());
    }
}
