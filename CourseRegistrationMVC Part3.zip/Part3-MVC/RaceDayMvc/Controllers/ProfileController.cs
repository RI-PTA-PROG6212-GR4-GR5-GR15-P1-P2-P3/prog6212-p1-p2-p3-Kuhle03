using Microsoft.AspNetCore.Mvc;
using RaceDayMvc.Infrastructure;
using RaceDayMvc.Models;

namespace RaceDayMvc.Controllers;

[SessionAuthorize]
public class ProfileController : ApiControllerBase
{
    public ProfileController(IHttpClientFactory factory) : base(factory) { }

    [HttpGet]
    public async Task<IActionResult> Index()
    {
        var result = await GetAsync<ProfileDto>(ApiRoutes.Profile);
        if (!result.Ok || result.Data == null)
        {
            TempData["Error"] = result.Error ?? "Your profile could not be loaded.";
            return RedirectToAction("Index", "Dashboard");
        }

        return View(new ProfileFormModel
        {
            FullName = result.Data.FullName,
            Email = result.Data.Email,
            ContactNumber = result.Data.ContactNumber,
            Role = result.Data.Role,
            HasPicture = !string.IsNullOrWhiteSpace(result.Data.ProfilePictureBlobName)
        });
    }

    [HttpPost, ValidateAntiForgeryToken]
    public async Task<IActionResult> Index(ProfileFormModel model)
    {
        if (!ModelState.IsValid) return View(model);

        var dto = new { fullName = model.FullName, email = model.Email, contactNumber = model.ContactNumber };
        var result = await SendAsync<object>(HttpMethod.Put, ApiRoutes.Profile, dto);

        if (!result.Ok)
        {
            ModelState.AddModelError("", result.Error!);
            return View(model);
        }

        HttpContext.Session.SetString(SessionKeys.Name, model.FullName);
        TempData["Success"] = "Profile updated.";
        return RedirectToAction(nameof(Index));
    }

    [HttpPost, ValidateAntiForgeryToken]
    public async Task<IActionResult> UploadPicture(IFormFile? file)
    {
        if (file == null || file.Length == 0)
        {
            TempData["Error"] = "Please choose an image to upload.";
            return RedirectToAction(nameof(Index));
        }

        var error = ValidateImage(file);
        if (error != null)
        {
            TempData["Error"] = error;
            return RedirectToAction(nameof(Index));
        }

        var result = await UploadAsync(ApiRoutes.ProfilePicture, file);
        if (result.Ok) TempData["Success"] = "Profile picture updated.";
        else TempData["Error"] = result.Error;

        return RedirectToAction(nameof(Index));
    }

    /// <summary>Returns the logged-in user's profile picture (read from Blob Storage by the API).</summary>
    public Task<IActionResult> Picture() =>
        ProxyImageAsync(ApiRoutes.ProfilePicture, "~/images/avatar-placeholder.svg");
}
