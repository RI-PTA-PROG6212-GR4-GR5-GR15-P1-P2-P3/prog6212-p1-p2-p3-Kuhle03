using System.Net;
using System.Net.Http.Headers;
using System.Net.Http.Json;
using System.Text.Json;
using Microsoft.AspNetCore.Mvc;
using RaceDayMvc.Infrastructure;
using RaceDayMvc.Models;

namespace RaceDayMvc.Controllers;

/// <summary>
/// Shared helpers for every controller that talks to the Part 2 API.
/// MVC never touches a database or Azure directly; everything goes through HTTP.
/// </summary>
public abstract class ApiControllerBase : Controller
{
    private readonly IHttpClientFactory _factory;

    protected const string Unavailable = "The RaceDay service is currently unavailable. Please try again shortly.";

    protected ApiControllerBase(IHttpClientFactory factory)
    {
        _factory = factory;
    }

    protected string? CurrentRole => HttpContext.Session.GetString(SessionKeys.Role);
    protected int CurrentUserId => HttpContext.Session.GetInt32(SessionKeys.UserId) ?? 0;

    /// <summary>
    /// Creates the named "Api" client and sends THIS user's API session cookie with the request.
    /// (The Part 2 API identifies the user through its own server-side session cookie.)
    /// </summary>
    protected HttpClient Api()
    {
        var client = _factory.CreateClient("Api");
        var cookie = HttpContext.Session.GetString(SessionKeys.ApiCookie);
        if (!string.IsNullOrWhiteSpace(cookie))
            client.DefaultRequestHeaders.TryAddWithoutValidation("Cookie", cookie);
        return client;
    }

    // ---------------------------------------------------------------- JSON helpers

    /// <summary>GET a JSON resource from the API.</summary>
    protected async Task<ApiResult<T>> GetAsync<T>(string url)
    {
        try
        {
            var response = await Api().GetAsync(url);
            if (!response.IsSuccessStatusCode)
                return ApiResult<T>.Fail(await ErrorMessageAsync(response));

            var data = await response.Content.ReadFromJsonAsync<T>();
            return ApiResult<T>.Success(data);
        }
        catch (HttpRequestException) { return ApiResult<T>.Fail(Unavailable); }
        catch (TaskCanceledException) { return ApiResult<T>.Fail(Unavailable); }
        catch (JsonException) { return ApiResult<T>.Fail("The server sent an unexpected response."); }
    }

    /// <summary>POST / PUT / DELETE with an optional JSON body. Returns the JSON body (if any) as T.</summary>
    protected async Task<ApiResult<T>> SendAsync<T>(HttpMethod method, string url, object? body = null)
    {
        try
        {
            using var request = new HttpRequestMessage(method, url);
            if (body != null) request.Content = JsonContent.Create(body);

            var response = await Api().SendAsync(request);
            if (!response.IsSuccessStatusCode)
                return ApiResult<T>.Fail(await ErrorMessageAsync(response));

            T? data = default;
            try
            {
                if (response.Content.Headers.ContentLength != 0)
                    data = await response.Content.ReadFromJsonAsync<T>();
            }
            catch (JsonException) { /* body was not the expected JSON; success is still success */ }

            return ApiResult<T>.Success(data);
        }
        catch (HttpRequestException) { return ApiResult<T>.Fail(Unavailable); }
        catch (TaskCanceledException) { return ApiResult<T>.Fail(Unavailable); }
    }

    // ---------------------------------------------------------------- Images (Blob Storage via the API)

    /// <summary>Uploads an image to the API as multipart/form-data (field name "file").</summary>
    protected async Task<ApiResult<bool>> UploadAsync(string url, IFormFile file)
    {
        try
        {
            using var content = new MultipartFormDataContent();
            using var stream = new StreamContent(file.OpenReadStream());
            stream.Headers.ContentType = new MediaTypeHeaderValue(file.ContentType);
            content.Add(stream, "file", file.FileName);

            var response = await Api().PostAsync(url, content);
            if (!response.IsSuccessStatusCode)
                return ApiResult<bool>.Fail(await ErrorMessageAsync(response));

            return ApiResult<bool>.Success(true);
        }
        catch (HttpRequestException) { return ApiResult<bool>.Fail(Unavailable); }
        catch (TaskCanceledException) { return ApiResult<bool>.Fail(Unavailable); }
    }

    /// <summary>Fetches an image through the API and returns it to the browser. Falls back to a placeholder.</summary>
    protected async Task<IActionResult> ProxyImageAsync(string url, string fallbackPath)
    {
        try
        {
            var response = await Api().GetAsync(url);
            if (!response.IsSuccessStatusCode)
                return Redirect(Url.Content(fallbackPath));

            var bytes = await response.Content.ReadAsByteArrayAsync();
            var type = response.Content.Headers.ContentType?.MediaType ?? "image/jpeg";
            return File(bytes, type);
        }
        catch (HttpRequestException) { return Redirect(Url.Content(fallbackPath)); }
        catch (TaskCanceledException) { return Redirect(Url.Content(fallbackPath)); }
    }

    protected static string? ValidateImage(IFormFile? file)
    {
        if (file == null || file.Length == 0) return null;
        if (file.Length > 5 * 1024 * 1024) return "Images must be 5 MB or smaller.";
        var allowed = new[] { "image/jpeg", "image/png" };
        if (!allowed.Contains(file.ContentType)) return "Only JPEG or PNG images are allowed.";
        return null;
    }

    // ---------------------------------------------------------------- Shared data loaders

    /// <summary>The logged-in Organiser's own events (past and upcoming) with the number of enrolments for each.</summary>
    protected async Task<ApiResult<List<EventDto>>> GetMyEventsAsync()
    {
        var all = await GetAsync<List<EventDto>>(ApiRoutes.AllEvents);
        if (!all.Ok) return ApiResult<List<EventDto>>.Fail(all.Error!);

        var mine = (all.Data ?? new List<EventDto>())
            .Where(e => e.OrganiserID == CurrentUserId)
            .OrderBy(e => e.EventDate)
            .ToList();

        foreach (var ev in mine)
        {
            var cats = await GetAsync<List<CategoryDto>>(ApiRoutes.EventCategories(ev.EventID));
            ev.EnrolmentCount = cats.Data?.Sum(c => c.EnrolledCount) ?? 0;
        }

        return ApiResult<List<EventDto>>.Success(mine);
    }

    // ---------------------------------------------------------------- Errors

    /// <summary>Turns an HTTP failure into a friendly message. Raw errors are never shown to the user.</summary>
    private async Task<string> ErrorMessageAsync(HttpResponseMessage response)
    {
        // The Part 2 API sends curated messages as {"message": "..."} (for example "You are already enrolled in this category.")
        string? apiMessage = null;
        try
        {
            var text = await response.Content.ReadAsStringAsync();
            if (!string.IsNullOrWhiteSpace(text) && text.TrimStart().StartsWith('{'))
            {
                using var doc = JsonDocument.Parse(text);
                if (doc.RootElement.TryGetProperty("message", out var m) && m.ValueKind == JsonValueKind.String)
                    apiMessage = m.GetString();
            }
        }
        catch { /* fall through to the generic messages */ }

        if (response.StatusCode == HttpStatusCode.Unauthorized)
        {
            // The API session ended (it expires after 30 idle minutes). Clear MVC's copy so the user logs in again.
            HttpContext.Session.Clear();
            return "Your session has expired. Please log in again.";
        }

        if (!string.IsNullOrWhiteSpace(apiMessage) && apiMessage.Length <= 200)
            return apiMessage;

        return response.StatusCode switch
        {
            HttpStatusCode.Forbidden => "You do not have permission to do that.",
            HttpStatusCode.NotFound => "That item could not be found.",
            HttpStatusCode.BadRequest => "Some of the information was not valid. Please check and try again.",
            HttpStatusCode.Conflict => "That conflicts with existing information.",
            _ => "Something went wrong. Please try again."
        };
    }
}
