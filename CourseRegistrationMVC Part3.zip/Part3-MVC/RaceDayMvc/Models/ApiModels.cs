namespace RaceDayMvc.Models;

// These classes mirror the JSON returned by the Part 2 API (property names match case-insensitively).

public class AuthResponse
{
    public int UserId { get; set; }
    public string FullName { get; set; } = "";
    public string Email { get; set; } = "";
    public string Role { get; set; } = "";
}

public class EventDto
{
    public int EventID { get; set; }
    public int OrganiserID { get; set; }
    public string OrganiserName { get; set; } = "";
    public string Name { get; set; } = "";
    public string Description { get; set; } = "";
    public DateTime EventDate { get; set; }
    public string Location { get; set; } = "";
    public decimal Distance { get; set; }
    public string EventType { get; set; } = "";
    public string? RouteInfo { get; set; }
    public string? BannerBlobName { get; set; }      // added to the API in Part 3

    // Filled in by MVC (not part of the API JSON)
    public int EnrolmentCount { get; set; }
}

public class CategoryDto
{
    public int CategoryID { get; set; }
    public int EventID { get; set; }
    public string Name { get; set; } = "";
    public decimal? Distance { get; set; }
    public int MaxParticipants { get; set; }
    public int EnrolledCount { get; set; }

    public bool IsFull => EnrolledCount >= MaxParticipants;
}

public class EnrolmentDto
{
    public int EnrolmentID { get; set; }
    public int ParticipantID { get; set; }
    public string ParticipantName { get; set; } = "";
    public int CategoryID { get; set; }
    public string CategoryName { get; set; } = "";
    public int EventID { get; set; }
    public string EventName { get; set; } = "";
    public DateTime EventDate { get; set; }
    public DateTime EnrolmentDate { get; set; }

    // Worked out by MVC: Confirmed / Pending / Completed (see EnrolmentStatus)
    public string Status { get; set; } = "Confirmed";
}

public class ResultDto
{
    public int ResultID { get; set; }
    public int EnrolmentID { get; set; }
    public int ParticipantID { get; set; }
    public string ParticipantName { get; set; } = "";
    public int EventID { get; set; }
    public string EventName { get; set; } = "";
    public int CategoryID { get; set; }
    public string CategoryName { get; set; } = "";
    public TimeSpan FinishTime { get; set; }
    public int Position { get; set; }

    // Filled in by MVC for the My Results page
    public DateTime EventDate { get; set; }
    public int TotalFinishers { get; set; }
}

public class ProfileDto
{
    public int UserId { get; set; }
    public string Role { get; set; } = "";
    public string FullName { get; set; } = "";
    public string Email { get; set; } = "";
    public string? ContactNumber { get; set; }
    public string? ProfilePictureBlobName { get; set; }   // added to the API in Part 3
}

public static class EventTypes
{
    // The Part 2 API only accepts these three.
    public static readonly string[] All = { "Run", "Walk", "Cycle" };
}

public static class EnrolmentStatus
{
    public const string Confirmed = "Confirmed";   // enrolled, event still to come
    public const string Pending = "Pending";       // event has taken place, results not published yet
    public const string Completed = "Completed";   // result has been published

    public static string For(DateTime eventDate, bool hasResult) =>
        hasResult ? Completed
        : eventDate.Date >= DateTime.Today ? Confirmed
        : Pending;
}
