using System.ComponentModel.DataAnnotations;

namespace RaceDayMvc.Models;

public class LoginViewModel
{
    [Required(ErrorMessage = "Email is required"), EmailAddress(ErrorMessage = "Enter a valid email address")]
    public string Email { get; set; } = "";

    [Required(ErrorMessage = "Password is required"), DataType(DataType.Password)]
    public string Password { get; set; } = "";
}

public class RegisterViewModel
{
    [Required(ErrorMessage = "Full name is required"), StringLength(100)]
    [Display(Name = "Full name")]
    public string FullName { get; set; } = "";

    [Required(ErrorMessage = "Email is required"), EmailAddress(ErrorMessage = "Enter a valid email address"), StringLength(150)]
    public string Email { get; set; } = "";

    [StringLength(20), Phone(ErrorMessage = "Enter a valid contact number")]
    [Display(Name = "Contact number (optional)")]
    public string? ContactNumber { get; set; }

    [Required(ErrorMessage = "Password is required"), StringLength(100, MinimumLength = 8, ErrorMessage = "Password must be at least 8 characters")]
    [DataType(DataType.Password)]
    public string Password { get; set; } = "";

    [Required(ErrorMessage = "Please confirm your password"), DataType(DataType.Password)]
    [Compare(nameof(Password), ErrorMessage = "Passwords do not match")]
    [Display(Name = "Confirm password")]
    public string ConfirmPassword { get; set; } = "";

    [Required(ErrorMessage = "Choose a role")]
    [Display(Name = "I am registering as")]
    public string Role { get; set; } = "Participant";
}

public class EventFormModel
{
    public int EventID { get; set; }

    [Required(ErrorMessage = "Event name is required"), StringLength(150)]
    public string Name { get; set; } = "";

    [Required(ErrorMessage = "Description is required"), StringLength(2000)]
    public string Description { get; set; } = "";

    [Required(ErrorMessage = "Event date is required"), DataType(DataType.Date)]
    [Display(Name = "Event date")]
    public DateTime EventDate { get; set; } = DateTime.Today.AddDays(30);

    [Required(ErrorMessage = "Location is required"), StringLength(150)]
    public string Location { get; set; } = "";

    [Range(0.1, 1000, ErrorMessage = "Distance must be between 0.1 and 1000 km")]
    [Display(Name = "Distance (km)")]
    public decimal Distance { get; set; }

    [Required(ErrorMessage = "Event type is required")]
    [Display(Name = "Event type")]
    public string EventType { get; set; } = "";

    [StringLength(2000)]
    [Display(Name = "Route information (optional)")]
    public string? RouteInfo { get; set; }

    [Display(Name = "Banner image")]
    public IFormFile? Banner { get; set; }

    public bool HasBanner { get; set; }
}

public class CategoryFormModel
{
    public int EventID { get; set; }

    [Required(ErrorMessage = "Category name is required"), StringLength(50)]
    [Display(Name = "Category name")]
    public string Name { get; set; } = "";

    [Range(0.1, 1000, ErrorMessage = "Distance must be between 0.1 and 1000 km")]
    [Display(Name = "Distance in km (leave empty for age categories)")]
    public decimal? Distance { get; set; }

    [Range(1, 100000, ErrorMessage = "Enter a limit between 1 and 100000")]
    [Display(Name = "Maximum participants")]
    public int MaxParticipants { get; set; } = 100;
}

public class CategoriesPageViewModel
{
    public EventDto Event { get; set; } = new();
    public List<CategoryDto> Categories { get; set; } = new();
    public CategoryFormModel Form { get; set; } = new();
}

public class EventFilter
{
    public string? Search { get; set; }
    public string? EventType { get; set; }
    public DateTime? From { get; set; }
    public decimal? MaxDistance { get; set; }
}

public class EventsIndexViewModel
{
    public EventFilter Filter { get; set; } = new();
    public List<EventDto> Events { get; set; } = new();
}

public class EventDetailsViewModel
{
    public EventDto Event { get; set; } = new();
    public List<CategoryDto> Categories { get; set; } = new();
}

public class OrganiserDashboardViewModel
{
    public int TotalEvents { get; set; }
    public int TotalEnrolments { get; set; }
    public List<EventDto> Upcoming { get; set; } = new();
    public List<EventDto> AllEvents { get; set; } = new();
}

public class ResultRowModel
{
    public int EnrolmentID { get; set; }
    public int CategoryID { get; set; }
    public string ParticipantName { get; set; } = "";
    public string CategoryName { get; set; } = "";

    // Existing result (0 = none captured yet)
    public int ResultID { get; set; }
    public string? OriginalFinishTime { get; set; }
    public int? OriginalPosition { get; set; }

    [Display(Name = "Finish time (hh:mm:ss)")]
    public string? FinishTime { get; set; }

    public int? Position { get; set; }
}

public class ResultsEntryViewModel
{
    public int EventID { get; set; }
    public string EventName { get; set; } = "";
    public List<ResultRowModel> Rows { get; set; } = new();
}

public class ProfileFormModel
{
    [Required(ErrorMessage = "Name is required"), StringLength(100)]
    [Display(Name = "Full name")]
    public string FullName { get; set; } = "";

    [Required(ErrorMessage = "Email is required"), EmailAddress(ErrorMessage = "Enter a valid email address"), StringLength(150)]
    public string Email { get; set; } = "";

    [Phone(ErrorMessage = "Enter a valid contact number"), StringLength(20)]
    [Display(Name = "Contact number")]
    public string? ContactNumber { get; set; }

    public string Role { get; set; } = "";
    public bool HasPicture { get; set; }
}

public class EnrolmentsByEventViewModel
{
    public EventDto Event { get; set; } = new();
    public List<EnrolmentDto> Enrolments { get; set; } = new();
}
