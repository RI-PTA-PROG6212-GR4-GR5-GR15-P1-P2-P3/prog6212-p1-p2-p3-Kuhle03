namespace RaceDayMvc.Models;

/// <summary>Wraps an API call outcome so controllers never deal with raw errors.</summary>
public class ApiResult<T>
{
    public T? Data { get; private set; }
    public string? Error { get; private set; }
    public bool Ok => Error == null;

    public static ApiResult<T> Success(T? data) => new() { Data = data };
    public static ApiResult<T> Fail(string error) => new() { Error = error };
}
