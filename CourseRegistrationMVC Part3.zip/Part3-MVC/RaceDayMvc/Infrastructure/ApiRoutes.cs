namespace RaceDayMvc.Infrastructure;

/// <summary>Every Part 2 API route used by the MVC app. These match the Part 2 controllers exactly.</summary>
public static class ApiRoutes
{
    // Auth
    public const string Register = "api/auth/register";
    public const string Login = "api/auth/login";
    public const string Logout = "api/auth/logout";

    // Events
    public const string UpcomingEvents = "api/events";
    public const string AllEvents = "api/events?includePast=true";
    public static string EventById(int id) => $"api/events/{id}";
    public static string EventBanner(int id) => $"api/events/{id}/banner";      // added in Part 3 (Blob Storage)

    // Categories
    public static string EventCategories(int eventId) => $"api/events/{eventId}/categories";
    public static string CategoryById(int id) => $"api/categories/{id}";

    // Enrolments
    public const string Enrol = "api/enrolments";
    public const string MyEnrolments = "api/enrolments/my";
    public static string EnrolmentsForEvent(int eventId) => $"api/events/{eventId}/enrolments";

    // Results
    public const string CreateResult = "api/results";
    public static string ResultById(int id) => $"api/results/{id}";
    public static string ResultsForEvent(int eventId) => $"api/events/{eventId}/results";
    public static string ResultsForParticipant(int participantId) => $"api/participants/{participantId}/results";

    // Profile
    public const string Profile = "api/profile";
    public const string ProfilePicture = "api/profile/picture";                // added in Part 3 (Blob Storage)
}
