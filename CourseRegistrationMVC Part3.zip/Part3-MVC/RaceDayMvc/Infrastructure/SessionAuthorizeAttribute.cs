using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Filters;

namespace RaceDayMvc.Infrastructure;

/// <summary>
/// Blocks a controller/action unless the MVC session shows a logged-in user and, optionally, an allowed role.
/// The API still enforces its own security on every call.
/// Usage: [SessionAuthorize] or [SessionAuthorize(Roles = "Organiser")]
/// </summary>
[AttributeUsage(AttributeTargets.Class | AttributeTargets.Method)]
public class SessionAuthorizeAttribute : ActionFilterAttribute
{
    public string? Roles { get; set; }

    public override void OnActionExecuting(ActionExecutingContext context)
    {
        var session = context.HttpContext.Session;
        var cookie = session.GetString(SessionKeys.ApiCookie);
        var role = session.GetString(SessionKeys.Role);

        if (string.IsNullOrWhiteSpace(cookie) || string.IsNullOrWhiteSpace(role))
        {
            context.Result = new RedirectToActionResult("Login", "Account", null);
            return;
        }

        if (!string.IsNullOrWhiteSpace(Roles))
        {
            var allowed = Roles.Split(',', StringSplitOptions.RemoveEmptyEntries | StringSplitOptions.TrimEntries);
            if (!allowed.Contains(role, StringComparer.OrdinalIgnoreCase))
                context.Result = new RedirectToActionResult("AccessDenied", "Account", null);
        }
    }
}
