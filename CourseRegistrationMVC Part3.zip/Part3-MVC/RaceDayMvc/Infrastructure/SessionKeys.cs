namespace RaceDayMvc.Infrastructure;

/// <summary>Keys used in the MVC session. The API's own session cookie is kept server-side here, never in the browser.</summary>
public static class SessionKeys
{
    public const string ApiCookie = "ApiCookie";   // ".RaceDay.Session=xxxx" issued by the Part 2 API at login
    public const string UserId = "UserId";
    public const string Role = "Role";
    public const string Name = "Name";
}

public static class Roles
{
    public const string Organiser = "Organiser";
    public const string Participant = "Participant";
}
