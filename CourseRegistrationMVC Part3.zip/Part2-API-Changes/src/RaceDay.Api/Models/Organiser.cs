namespace RaceDay.Api.Models;

public class Organiser
{
    public int OrganiserID { get; set; }
    public string FullName { get; set; } = string.Empty;
    public string Email { get; set; } = string.Empty;
    public string PasswordHash { get; set; } = string.Empty;
    public string? ContactNumber { get; set; }
    public string? ProfilePictureBlobName { get; set; }   // name of the picture in Azure Blob Storage
    public DateTime CreatedAt { get; set; } = DateTime.UtcNow;

    public List<RaceEvent> Events { get; set; } = new();
}
