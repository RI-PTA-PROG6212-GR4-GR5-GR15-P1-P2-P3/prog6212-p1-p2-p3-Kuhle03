using System.ComponentModel.DataAnnotations;

namespace RaceDay.Api.Models.DTOs;

public record ErrorResponse(string Message);

// ---------- Auth & profile ----------
public class RegisterDto
{
    [Required, StringLength(100)] public string FullName { get; set; } = string.Empty;
    [Required, EmailAddress, StringLength(150)] public string Email { get; set; } = string.Empty;
    [Required, StringLength(100, MinimumLength = 8)] public string Password { get; set; } = string.Empty;
    [StringLength(20)] public string? ContactNumber { get; set; }
    /// <summary>Either "Organiser" or "Participant".</summary>
    [Required] public string Role { get; set; } = string.Empty;
}

public class LoginDto
{
    [Required, EmailAddress] public string Email { get; set; } = string.Empty;
    [Required] public string Password { get; set; } = string.Empty;
}

public class AuthResponse
{
    public int UserId { get; set; }
    public string FullName { get; set; } = string.Empty;
    public string Email { get; set; } = string.Empty;
    public string Role { get; set; } = string.Empty;
}

public class UpdateProfileDto
{
    [Required, StringLength(100)] public string FullName { get; set; } = string.Empty;
    [Required, EmailAddress, StringLength(150)] public string Email { get; set; } = string.Empty;
    [StringLength(20)] public string? ContactNumber { get; set; }
}

public class ProfileResponse
{
    public int UserId { get; set; }
    public string Role { get; set; } = string.Empty;
    public string FullName { get; set; } = string.Empty;
    public string Email { get; set; } = string.Empty;
    public string? ContactNumber { get; set; }
    public string? ProfilePictureBlobName { get; set; }
}

// ---------- Events ----------
public class EventDto
{
    [Required, StringLength(150)] public string Name { get; set; } = string.Empty;
    [Required, StringLength(2000)] public string Description { get; set; } = string.Empty;
    [Range(typeof(DateTime), "2000-01-01", "2100-12-31", ErrorMessage = "A valid event date is required.")]
    public DateTime EventDate { get; set; }
    [Required, StringLength(150)] public string Location { get; set; } = string.Empty;
    /// <summary>Total distance in kilometres.</summary>
    [Range(0.1, 1000.0, ErrorMessage = "Distance must be between 0.1 and 1000 km.")]
    public decimal Distance { get; set; }
    /// <summary>Run, Walk or Cycle.</summary>
    [Required, RegularExpression("^(?i:run|walk|cycle)$", ErrorMessage = "EventType must be Run, Walk or Cycle.")]
    public string EventType { get; set; } = string.Empty;
    [StringLength(2000)] public string? RouteInfo { get; set; }
}

public class EventResponse
{
    public int EventID { get; set; }
    public int OrganiserID { get; set; }
    public string OrganiserName { get; set; } = string.Empty;
    public string Name { get; set; } = string.Empty;
    public string Description { get; set; } = string.Empty;
    public DateTime EventDate { get; set; }
    public string Location { get; set; } = string.Empty;
    public decimal Distance { get; set; }
    public string EventType { get; set; } = string.Empty;
    public string? RouteInfo { get; set; }
    public string? BannerBlobName { get; set; }
}

// ---------- Categories ----------
public class CategoryDto
{
    /// <summary>For example "Under 20", "Senior", "10km" or "21km".</summary>
    [Required, StringLength(50)] public string Name { get; set; } = string.Empty;
    /// <summary>Optional. Leave empty for age-based categories.</summary>
    [Range(0.1, 1000.0)] public decimal? Distance { get; set; }
    [Range(1, 100000)] public int MaxParticipants { get; set; } = 100;
}

public class CategoryResponse
{
    public int CategoryID { get; set; }
    public int EventID { get; set; }
    public string Name { get; set; } = string.Empty;
    public decimal? Distance { get; set; }
    public int MaxParticipants { get; set; }
    public int EnrolledCount { get; set; }
}

// ---------- Enrolments ----------
public class EnrolDto
{
    [Range(1, int.MaxValue, ErrorMessage = "A valid categoryId is required.")]
    public int CategoryId { get; set; }
}

public class EnrolmentResponse
{
    public int EnrolmentID { get; set; }
    public int ParticipantID { get; set; }
    public string ParticipantName { get; set; } = string.Empty;
    public int CategoryID { get; set; }
    public string CategoryName { get; set; } = string.Empty;
    public int EventID { get; set; }
    public string EventName { get; set; } = string.Empty;
    public DateTime EventDate { get; set; }
    public DateTime EnrolmentDate { get; set; }
}

// ---------- Results ----------
public class CreateResultDto
{
    [Range(1, int.MaxValue, ErrorMessage = "A valid enrolmentId is required.")]
    public int EnrolmentId { get; set; }
    /// <summary>Format hh:mm:ss, for example 00:45:10.</summary>
    public TimeSpan FinishTime { get; set; }
    /// <summary>Finishing position inside the category (1 = winner).</summary>
    [Range(1, 100000)] public int Position { get; set; }
}

public class UpdateResultDto
{
    /// <summary>Format hh:mm:ss, for example 00:45:10.</summary>
    public TimeSpan FinishTime { get; set; }
    [Range(1, 100000)] public int Position { get; set; }
}

public class ResultResponse
{
    public int ResultID { get; set; }
    public int EnrolmentID { get; set; }
    public int ParticipantID { get; set; }
    public string ParticipantName { get; set; } = string.Empty;
    public int EventID { get; set; }
    public string EventName { get; set; } = string.Empty;
    public int CategoryID { get; set; }
    public string CategoryName { get; set; } = string.Empty;
    public TimeSpan FinishTime { get; set; }
    public int Position { get; set; }
}
