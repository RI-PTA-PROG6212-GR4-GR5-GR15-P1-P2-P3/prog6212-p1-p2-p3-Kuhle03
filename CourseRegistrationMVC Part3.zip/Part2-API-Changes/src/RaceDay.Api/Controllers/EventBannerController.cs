using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using RaceDay.Api.Data;
using RaceDay.Api.Helpers;
using RaceDay.Api.Models.DTOs;
using RaceDay.Api.Services;

namespace RaceDay.Api.Controllers;

/// <summary>Event banner images, stored in Azure Blob Storage.</summary>
[Route("api/events/{eventId:int}/banner")]
public class EventBannerController : ApiControllerBase
{
    private readonly AppDbContext _db;
    private readonly BlobStorageService _blobs;

    public EventBannerController(AppDbContext db, BlobStorageService blobs)
    {
        _db = db;
        _blobs = blobs;
    }

    /// <summary>Upload (or replace) the banner image of an event you own.</summary>
    /// <remarks>Send multipart/form-data with a file field called "file". JPEG or PNG, maximum 5 MB.</remarks>
    /// <response code="200">Banner saved.</response>
    /// <response code="400">The file is missing, too large or not a JPEG/PNG image.</response>
    /// <response code="401">Not logged in.</response>
    /// <response code="403">Not an Organiser, or not the owner of this event.</response>
    /// <response code="404">Event not found.</response>
    [HttpPost]
    [SessionAuthorize(Roles.Organiser)]
    [Consumes("multipart/form-data")]
    [ProducesResponseType(typeof(ErrorResponse), StatusCodes.Status200OK)]
    [ProducesResponseType(typeof(ErrorResponse), StatusCodes.Status400BadRequest)]
    [ProducesResponseType(typeof(ErrorResponse), StatusCodes.Status401Unauthorized)]
    [ProducesResponseType(typeof(ErrorResponse), StatusCodes.Status403Forbidden)]
    [ProducesResponseType(typeof(ErrorResponse), StatusCodes.Status404NotFound)]
    public async Task<IActionResult> Upload(int eventId, IFormFile file)
    {
        var ev = await _db.Events.FirstOrDefaultAsync(e => e.EventID == eventId);
        if (ev == null) return NotFound(new ErrorResponse("Event not found."));
        if (ev.OrganiserID != CurrentUserId) return ForbiddenResult("You can only change the banner of your own events.");

        var problem = BlobStorageService.Validate(file);
        if (problem != null) return BadRequest(new ErrorResponse(problem));

        var oldBlob = ev.BannerBlobName;

        // 1) image bytes -> Azure Blob Storage, 2) blob name -> SQL Server
        ev.BannerBlobName = await _blobs.UploadImageAsync(BlobStorageService.EventBanners, file);
        await _db.SaveChangesAsync();

        await _blobs.DeleteAsync(BlobStorageService.EventBanners, oldBlob);   // tidy up the replaced image
        return Ok(new ErrorResponse("Banner saved."));
    }

    /// <summary>Download the banner image of an event.</summary>
    /// <response code="200">The image.</response>
    /// <response code="404">The event has no banner.</response>
    [HttpGet]
    [ProducesResponseType(typeof(FileResult), StatusCodes.Status200OK)]
    [ProducesResponseType(typeof(ErrorResponse), StatusCodes.Status404NotFound)]
    public async Task<IActionResult> Download(int eventId)
    {
        var blobName = await _db.Events.Where(e => e.EventID == eventId).Select(e => e.BannerBlobName).FirstOrDefaultAsync();
        if (string.IsNullOrWhiteSpace(blobName)) return NotFound(new ErrorResponse("This event has no banner."));

        var image = await _blobs.DownloadImageAsync(BlobStorageService.EventBanners, blobName);
        if (image == null) return NotFound(new ErrorResponse("This event has no banner."));

        return File(image.Value.Content, image.Value.ContentType);
    }
}
