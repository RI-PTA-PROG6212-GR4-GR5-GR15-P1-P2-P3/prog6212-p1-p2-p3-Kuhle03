using RaceDay.Api.Models.DTOs;
using RaceDay.Api.Models;

namespace RaceDay.Api.Controllers;

/// <summary>Turns database models into the objects the API sends back.</summary>
internal static class Mapping
{
    public static EventResponse ToEventResponse(RaceEvent e) => new()
    {
        EventID = e.EventID,
        OrganiserID = e.OrganiserID,
        OrganiserName = e.Organiser?.FullName ?? string.Empty,
        Name = e.Name,
        Description = e.Description,
        EventDate = e.EventDate,
        Location = e.Location,
        Distance = e.Distance,
        EventType = e.EventType,
        RouteInfo = e.RouteInfo,
        BannerBlobName = e.BannerBlobName
    };

    public static CategoryResponse ToCategoryResponse(Category c, int enrolledCount) => new()
    {
        CategoryID = c.CategoryID,
        EventID = c.EventID,
        Name = c.Name,
        Distance = c.Distance,
        MaxParticipants = c.MaxParticipants,
        EnrolledCount = enrolledCount
    };

    // Needs Participant and Category.Event to be loaded.
    public static EnrolmentResponse ToEnrolmentResponse(EventEnrolment en) => new()
    {
        EnrolmentID = en.EnrolmentID,
        ParticipantID = en.ParticipantID,
        ParticipantName = en.Participant?.FullName ?? string.Empty,
        CategoryID = en.CategoryID,
        CategoryName = en.Category.Name,
        EventID = en.Category.EventID,
        EventName = en.Category.Event?.Name ?? string.Empty,
        EventDate = en.Category.Event?.EventDate ?? default,
        EnrolmentDate = en.EnrolmentDate
    };

    // Needs Enrolment.Participant and Enrolment.Category.Event to be loaded.
    public static ResultResponse ToResultResponse(RaceResult r) => new()
    {
        ResultID = r.ResultID,
        EnrolmentID = r.EnrolmentID,
        ParticipantID = r.Enrolment.ParticipantID,
        ParticipantName = r.Enrolment.Participant?.FullName ?? string.Empty,
        EventID = r.Enrolment.Category.EventID,
        EventName = r.Enrolment.Category.Event?.Name ?? string.Empty,
        CategoryID = r.Enrolment.CategoryID,
        CategoryName = r.Enrolment.Category.Name,
        FinishTime = r.FinishTime,
        Position = r.Position
    };
}
