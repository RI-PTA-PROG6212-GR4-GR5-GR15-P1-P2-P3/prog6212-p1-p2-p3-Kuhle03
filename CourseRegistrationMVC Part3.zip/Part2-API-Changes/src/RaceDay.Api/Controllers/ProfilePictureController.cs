using Microsoft.AspNetCore.Mvc;
using RaceDay.Api.Data;
using RaceDay.Api.Helpers;
using RaceDay.Api.Models.DTOs;
using RaceDay.Api.Services;

namespace RaceDay.Api.Controllers;

/// <summary>The logged-in user's profile picture, stored in Azure Blob Storage.</summary>
[Route("api/profile/picture")]
[SessionAuthorize]
public class ProfilePictureController : ApiControllerBase
{
    private readonly AppDbContext _db;
    private readonly BlobStorageService _blobs;

    public ProfilePictureController(AppDbContext db, BlobStorageService blobs)
    {
        _db = db;
        _blobs = blobs;
    }

    /// <summary>Upload (or replace) your profile picture.</summary>
    /// <remarks>Send multipart/form-data with a file field called "file". JPEG or PNG, maximum 5 MB.</remarks>
    /// <response code="200">Picture saved.</response>
    /// <response code="400">The file is missing, too large or not a JPEG/PNG image.</response>
    /// <response code="401">Not logged in.</response>
    /// <response code="404">Account not found.</response>
    [HttpPost]
    [Consumes("multipart/form-data")]
    [ProducesResponseType(typeof(ErrorResponse), StatusCodes.Status200OK)]
    [ProducesResponseType(typeof(ErrorResponse), StatusCodes.Status400BadRequest)]
    [ProducesResponseType(typeof(ErrorResponse), StatusCodes.Status401Unauthorized)]
    [ProducesResponseType(typeof(ErrorResponse), StatusCodes.Status404NotFound)]
    public async Task<IActionResult> Upload(IFormFile file)
    {
        var problem = BlobStorageService.Validate(file);
        if (problem != null) return BadRequest(new ErrorResponse(problem));

        string? oldBlob;
        string newBlob;

        if (CurrentRole == Roles.Organiser)
        {
            var o = await _db.Organisers.FindAsync(CurrentUserId);
            if (o == null) return NotFound(new ErrorResponse("Account not found."));
            oldBlob = o.ProfilePictureBlobName;
            newBlob = await _blobs.UploadImageAsync(BlobStorageService.ProfilePictures, file);
            o.ProfilePictureBlobName = newBlob;
        }
        else
        {
            var p = await _db.Participants.FindAsync(CurrentUserId);
            if (p == null) return NotFound(new ErrorResponse("Account not found."));
            oldBlob = p.ProfilePictureBlobName;
            newBlob = await _blobs.UploadImageAsync(BlobStorageService.ProfilePictures, file);
            p.ProfilePictureBlobName = newBlob;
        }

        await _db.SaveChangesAsync();
        await _blobs.DeleteAsync(BlobStorageService.ProfilePictures, oldBlob);
        return Ok(new ErrorResponse("Profile picture saved."));
    }

    /// <summary>Download your profile picture.</summary>
    /// <response code="200">The image.</response>
    /// <response code="404">No picture uploaded yet.</response>
    [HttpGet]
    [ProducesResponseType(typeof(FileResult), StatusCodes.Status200OK)]
    [ProducesResponseType(typeof(ErrorResponse), StatusCodes.Status401Unauthorized)]
    [ProducesResponseType(typeof(ErrorResponse), StatusCodes.Status404NotFound)]
    public async Task<IActionResult> Download()
    {
        string? blobName = CurrentRole == Roles.Organiser
            ? (await _db.Organisers.FindAsync(CurrentUserId))?.ProfilePictureBlobName
            : (await _db.Participants.FindAsync(CurrentUserId))?.ProfilePictureBlobName;

        if (string.IsNullOrWhiteSpace(blobName)) return NotFound(new ErrorResponse("No profile picture yet."));

        var image = await _blobs.DownloadImageAsync(BlobStorageService.ProfilePictures, blobName);
        if (image == null) return NotFound(new ErrorResponse("No profile picture yet."));

        return File(image.Value.Content, image.Value.ContentType);
    }
}
