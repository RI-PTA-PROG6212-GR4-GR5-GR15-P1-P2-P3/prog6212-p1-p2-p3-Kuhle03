using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using RaceDay.Api.Data;
using RaceDay.Api.Models.DTOs;
using RaceDay.Api.Helpers;

namespace RaceDay.Api.Controllers;

[Route("api/profile")]
[SessionAuthorize]
public class ProfileController : ApiControllerBase
{
    private readonly AppDbContext _db;

    public ProfileController(AppDbContext db) => _db = db;

    /// <summary>View the profile of the logged-in user (Organiser or Participant).</summary>
    /// <response code="200">Returns the user's own profile.</response>
    /// <response code="401">Not logged in.</response>
    /// <response code="404">The account no longer exists.</response>
    [HttpGet]
    [ProducesResponseType(typeof(ProfileResponse), StatusCodes.Status200OK)]
    [ProducesResponseType(typeof(ErrorResponse), StatusCodes.Status401Unauthorized)]
    [ProducesResponseType(typeof(ErrorResponse), StatusCodes.Status404NotFound)]
    public async Task<ActionResult<ProfileResponse>> GetProfile()
    {
        if (CurrentRole == Roles.Organiser)
        {
            var o = await _db.Organisers.FindAsync(CurrentUserId);
            if (o == null) return NotFound(new ErrorResponse("Account not found."));
            return Ok(new ProfileResponse { UserId = o.OrganiserID, Role = Roles.Organiser, FullName = o.FullName, Email = o.Email, ContactNumber = o.ContactNumber, ProfilePictureBlobName = o.ProfilePictureBlobName });
        }

        var p = await _db.Participants.FindAsync(CurrentUserId);
        if (p == null) return NotFound(new ErrorResponse("Account not found."));
        return Ok(new ProfileResponse { UserId = p.ParticipantID, Role = Roles.Participant, FullName = p.FullName, Email = p.Email, ContactNumber = p.ContactNumber, ProfilePictureBlobName = p.ProfilePictureBlobName });
    }

    /// <summary>Update the profile of the logged-in user.</summary>
    /// <remarks>Expects: fullName, email and an optional contactNumber. You can only change your own profile.</remarks>
    /// <response code="200">Profile updated. Returns the new profile.</response>
    /// <response code="400">A field is missing or invalid.</response>
    /// <response code="401">Not logged in.</response>
    /// <response code="404">The account no longer exists.</response>
    /// <response code="409">That email belongs to another account.</response>
    [HttpPut]
    [ProducesResponseType(typeof(ProfileResponse), StatusCodes.Status200OK)]
    [ProducesResponseType(typeof(ErrorResponse), StatusCodes.Status400BadRequest)]
    [ProducesResponseType(typeof(ErrorResponse), StatusCodes.Status401Unauthorized)]
    [ProducesResponseType(typeof(ErrorResponse), StatusCodes.Status404NotFound)]
    [ProducesResponseType(typeof(ErrorResponse), StatusCodes.Status409Conflict)]
    public async Task<ActionResult<ProfileResponse>> UpdateProfile(UpdateProfileDto request)
    {
        var email = request.Email.Trim().ToLowerInvariant();
        var id = CurrentUserId;
        var isOrganiser = CurrentRole == Roles.Organiser;

        // The email may stay the same, but it cannot match any other account.
        var taken = await _db.Organisers.AnyAsync(o => o.Email == email && !(isOrganiser && o.OrganiserID == id))
                    || await _db.Participants.AnyAsync(p => p.Email == email && !(!isOrganiser && p.ParticipantID == id));
        if (taken) return Conflict(new ErrorResponse("That email address belongs to another account."));

        if (isOrganiser)
        {
            var o = await _db.Organisers.FindAsync(id);
            if (o == null) return NotFound(new ErrorResponse("Account not found."));
            o.FullName = request.FullName.Trim();
            o.Email = email;
            o.ContactNumber = request.ContactNumber?.Trim();
            await _db.SaveChangesAsync();
            return Ok(new ProfileResponse { UserId = o.OrganiserID, Role = Roles.Organiser, FullName = o.FullName, Email = o.Email, ContactNumber = o.ContactNumber, ProfilePictureBlobName = o.ProfilePictureBlobName });
        }

        var p = await _db.Participants.FindAsync(id);
        if (p == null) return NotFound(new ErrorResponse("Account not found."));
        p.FullName = request.FullName.Trim();
        p.Email = email;
        p.ContactNumber = request.ContactNumber?.Trim();
        await _db.SaveChangesAsync();
        return Ok(new ProfileResponse { UserId = p.ParticipantID, Role = Roles.Participant, FullName = p.FullName, Email = p.Email, ContactNumber = p.ContactNumber, ProfilePictureBlobName = p.ProfilePictureBlobName });
    }
}
