using System.Reflection;
using Azure.Storage.Blobs;
using Microsoft.EntityFrameworkCore;
using Microsoft.OpenApi.Models;
using RaceDay.Api.Data;
using RaceDay.Api.Services;

var builder = WebApplication.CreateBuilder(args);

// Database (SQL Server through Entity Framework Core, Code-First)
builder.Services.AddDbContext<AppDbContext>(options =>
    options.UseSqlServer(builder.Configuration.GetConnectionString("DefaultConnection")));

builder.Services.AddScoped<IPasswordService, PasswordService>();

// Azure Blob Storage (event banners and profile pictures). The MVC project never talks to Azure: it uploads through this API.
// Falls back to the local Azurite emulator so the tests and local runs still work without an Azure account.
var storageConnection = builder.Configuration.GetConnectionString("StorageConnectionString") ?? "UseDevelopmentStorage=true";
builder.Services.AddSingleton(new BlobServiceClient(storageConnection));
builder.Services.AddScoped<BlobStorageService>();

// Server-side session: the server keeps UserId + Role, the browser only holds a session cookie.
builder.Services.AddDistributedMemoryCache();
builder.Services.AddSession(options =>
{
    options.IdleTimeout = TimeSpan.FromMinutes(30);
    options.Cookie.Name = ".RaceDay.Session";
    options.Cookie.HttpOnly = true;
    options.Cookie.IsEssential = true;
});

builder.Services.AddControllers();
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen(options =>
{
    options.SwaggerDoc("v1", new OpenApiInfo
    {
        Title = "RaceDay API",
        Version = "v1",
        Description = "Event management API for the South African road running, walking and cycling community. " +
                      "Log in through POST /api/auth/login first: Swagger UI then sends your session cookie automatically."
    });

    var xmlFile = $"{Assembly.GetExecutingAssembly().GetName().Name}.xml";
    var xmlPath = Path.Combine(AppContext.BaseDirectory, xmlFile);
    if (File.Exists(xmlPath)) options.IncludeXmlComments(xmlPath);
});

var app = builder.Build();

// Create/upgrade the database on start-up (SQL Server) or just create it (in-memory database used by the tests).
using (var scope = app.Services.CreateScope())
{
    var db = scope.ServiceProvider.GetRequiredService<AppDbContext>();
    if (db.Database.IsRelational())
    {
        // Normal route: apply the migration made with Add-Migration. Safety net: if no migration exists yet, create the tables directly.
        if (db.Database.GetMigrations().Any()) db.Database.Migrate();
        else db.Database.EnsureCreated();
        DbSeeder.Seed(db, scope.ServiceProvider.GetRequiredService<IPasswordService>());
    }
    else
    {
        db.Database.EnsureCreated();
    }
}

app.UseSwagger();
app.UseSwaggerUI(options => options.DocumentTitle = "RaceDay API");

app.UseSession();
app.MapControllers();
app.MapGet("/", () => Results.Redirect("/swagger")).ExcludeFromDescription();

app.Run();

// Makes the Program class visible to the test project (WebApplicationFactory<Program>).
public partial class Program { }
