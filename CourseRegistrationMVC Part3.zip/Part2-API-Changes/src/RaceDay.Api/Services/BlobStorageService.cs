using Azure.Storage.Blobs;
using Azure.Storage.Blobs.Models;

namespace RaceDay.Api.Services;

/// <summary>All Azure Blob Storage access lives in the API. Images are stored in Blob Storage; SQL Server only keeps the blob name.</summary>
public class BlobStorageService
{
    public const string EventBanners = "event-banners";
    public const string ProfilePictures = "profile-pictures";

    private static readonly string[] AllowedTypes = { "image/jpeg", "image/png" };
    private const long MaxBytes = 5 * 1024 * 1024;

    private readonly BlobServiceClient _blobService;

    public BlobStorageService(BlobServiceClient blobService)
    {
        _blobService = blobService;
    }

    /// <summary>Returns an error message when the file is not an acceptable image, otherwise null.</summary>
    public static string? Validate(IFormFile? file)
    {
        if (file == null || file.Length == 0) return "Choose an image to upload.";
        if (file.Length > MaxBytes) return "The image must be 5 MB or smaller.";
        if (!AllowedTypes.Contains(file.ContentType)) return "Only JPEG or PNG images are allowed.";
        return null;
    }

    /// <summary>Uploads the file and returns the unique blob name to save in SQL Server.</summary>
    public async Task<string> UploadImageAsync(string containerName, IFormFile file)
    {
        var container = _blobService.GetBlobContainerClient(containerName);
        await container.CreateIfNotExistsAsync();

        var extension = file.ContentType == "image/png" ? ".png" : ".jpg";
        var blobName = $"{Guid.NewGuid():N}{extension}";

        await using var stream = file.OpenReadStream();
        await container.GetBlobClient(blobName).UploadAsync(stream, new BlobUploadOptions
        {
            HttpHeaders = new BlobHttpHeaders { ContentType = file.ContentType }
        });

        return blobName;
    }

    /// <summary>Returns the blob content, or null when it does not exist.</summary>
    public async Task<(Stream Content, string ContentType)?> DownloadImageAsync(string containerName, string blobName)
    {
        var container = _blobService.GetBlobContainerClient(containerName);
        var blob = container.GetBlobClient(blobName);
        if (!await blob.ExistsAsync()) return null;

        var download = await blob.DownloadStreamingAsync();
        return (download.Value.Content, download.Value.Details.ContentType ?? "image/jpeg");
    }

    public async Task DeleteAsync(string containerName, string? blobName)
    {
        if (string.IsNullOrWhiteSpace(blobName)) return;
        await _blobService.GetBlobContainerClient(containerName).DeleteBlobIfExistsAsync(blobName);
    }
}
