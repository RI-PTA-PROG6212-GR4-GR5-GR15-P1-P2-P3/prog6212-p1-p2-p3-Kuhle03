-- Run ONCE against your existing RaceDayApiDb (SSMS / Azure Data Studio), then restart the API.
-- Alternative: drop the RaceDayApiDb database and let the API recreate and re-seed it on start-up.
USE RaceDayApiDb;
GO
IF COL_LENGTH('Events', 'BannerBlobName') IS NULL
    ALTER TABLE Events ADD BannerBlobName NVARCHAR(MAX) NULL;
IF COL_LENGTH('Organisers', 'ProfilePictureBlobName') IS NULL
    ALTER TABLE Organisers ADD ProfilePictureBlobName NVARCHAR(MAX) NULL;
IF COL_LENGTH('Participants', 'ProfilePictureBlobName') IS NULL
    ALTER TABLE Participants ADD ProfilePictureBlobName NVARCHAR(MAX) NULL;
GO
